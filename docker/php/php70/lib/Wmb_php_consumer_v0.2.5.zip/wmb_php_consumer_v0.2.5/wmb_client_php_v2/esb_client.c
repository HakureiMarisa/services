/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2016 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <string.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_esb_client.h"

#include "esbclient_v2/esbclient.h"
#include "esbclient_v2/esbcli_msg.h"

/* If you declare any globals in php_esb_client.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(esb_client)
*/
ZEND_DECLARE_MODULE_GLOBALS(esb_client);

/* True global resources - no need for thread safety here */
static int le_esb_client;
int esb_client_globals_id;

ZEND_BEGIN_ARG_INFO_EX(arginf_ESBClient__constr, 0, 0, 1)
ZEND_ARG_INFO(0, key_path)
ZEND_END_ARG_INFO()
ZEND_BEGIN_ARG_INFO_EX(arginf_ESBClient__addconsumesbj, 0, 0, 3)
ZEND_ARG_INFO(0, subject_id)
ZEND_ARG_INFO(0, client_id)
ZEND_ARG_INFO(0, sub_mode)
ZEND_END_ARG_INFO()
ZEND_BEGIN_ARG_INFO_EX(arginf_ESBClient__consumer, 0, 0, 1)
ZEND_ARG_INFO(0, callback)
ZEND_ARG_INFO(0, flag)
ZEND_END_ARG_INFO()

/* decalre the class entries */
zend_class_entry *ESBClient_ce;

const zend_function_entry ESBClient_functions[] = {
  PHP_ME(ESBClient, __construct, arginf_ESBClient__constr, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, __destruct, NULL, ZEND_ACC_DTOR | ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, add_consume_subject, arginf_ESBClient__addconsumesbj, ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, consumer, arginf_ESBClient__consumer, ZEND_ACC_PUBLIC)
  PHP_MALIAS(ESBClient, comsumer, consumer, arginf_ESBClient__consumer, ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, backend_consumer_start, NULL, ZEND_ACC_PUBLIC)
  PHP_MALIAS(ESBClient, backend_comsumer_start, backend_consumer_start, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, fetch_message, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, backend_consumer_stop, NULL, ZEND_ACC_PUBLIC)
  PHP_MALIAS(ESBClient, backend_comsumer_stop, backend_consumer_stop, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(ESBClient, close_callback, NULL, ZEND_ACC_PUBLIC)
  {NULL, NULL, NULL} /* Marks the end of function entries */
};


#if (PHP_MAJOR_VERSION < 7)
void free_esb_object(void *object TSRMLS_DC) {
  efree(object);
}

zend_object_value create_esb_object(zend_class_entry *class_type TSRMLS_DC) {
  zend_object_value retval;
  esb_object  *eobj;
  zval *tmp;

  eobj = (esb_object*)emalloc(sizeof(esb_object));
  memset(eobj, 0, sizeof(esb_object));

  zend_object_std_init(&eobj->std, class_type TSRMLS_CC);
#if PHP_VERSION_ID < 50399
  zend_hash_copy(
    eobj->std.properties, &class_type->default_properties,
    (copy_ctor_func_t)zval_add_ref,
    (void *)&tmp,
    sizeof tmp
  );
#else
  object_properties_init(&eobj->std, class_type);
#endif

  retval.handle = zend_objects_store_put(
                    eobj,
                    (zend_objects_store_dtor_t) zend_objects_destroy_object,
                    free_esb_object,
                    NULL TSRMLS_CC);
  retval.handlers = zend_get_std_object_handlers();

  return retval;
}

#else

zend_object_handlers esb_object_handlers;

void free_esb_object(zend_object *object) {
  zend_object_std_dtor(object TSRMLS_CC);
}

zend_object * create_esb_object(zend_class_entry *ce TSRMLS_DC) {
  esb_object *eobj = ecalloc(1, sizeof(esb_object) + zend_object_properties_size(ce));

  zend_object_std_init(&eobj->std, ce TSRMLS_CC);
  object_properties_init(&eobj->std, ce);

  memcpy(&esb_object_handlers, zend_get_std_object_handlers(), sizeof(esb_object_handlers));
  esb_object_handlers.offset = XtOffsetOf(esb_object, std);
  esb_object_handlers.free_obj = free_esb_object;
  eobj->std.handlers = &esb_object_handlers;

  return &eobj->std;
}

#endif


esb_object * esb_object_get_instance(zval *id TSRMLS_DC) {
  esb_object *eobj = NULL;
  if (Z_TYPE_P(id) == IS_OBJECT) {
#if (PHP_MAJOR_VERSION < 7)
    eobj = (esb_object *)zend_object_store_get_object(id TSRMLS_CC);
#else
    eobj = (esb_object *)((char *)Z_OBJ_P(id) - XtOffsetOf(esb_object, std));
#endif
    return eobj;
  }
  return NULL;
}


/**
 *
 */
PHP_METHOD(ESBClient, __construct) {
  char *key_path;
  int   key_path_len;
  esb_object  *eobj;
  char *keyPathFinal;

#if (PHP_MAJOR_VERSION < 7)
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &key_path, &key_path_len) == FAILURE) {
    RETURN_FALSE;
  }
#else
  zval *val;
  zend_string *str;
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "z", &val) == FAILURE) {
    RETURN_FALSE;
    return;
  }
  if (Z_TYPE_P(val) == IS_NULL || Z_TYPE_P(val) != IS_STRING) {
    RETURN_FALSE;
    return;
  }
  str = Z_STR_P(val);
  key_path = ZSTR_VAL(str);
  key_path_len = ZSTR_LEN(str);
#endif
  if (key_path == NULL || key_path_len <= 0) {
    RETURN_FALSE;
  }
  //php_printf("~~~~~~~~key_path:%x, len:%d\n", key_path, key_path_len);

  keyPathFinal = (char*)malloc(key_path_len + 1);
  memcpy(keyPathFinal, key_path, key_path_len);
  keyPathFinal[key_path_len] = '\0';

//zval *val;
//zend_string *str;
//val = ZEND_CALL_ARG(EG(current_execute_data), 1);
//str = Z_STR_P(val);
//key_path = ZSTR_VAL(str);
//key_path_len = ZSTR_LEN(str);
//php_printf("~~~~~~~~key_path:%x, len:%d\n", key_path, key_path_len);
//
  eobj = esb_object_get_instance(getThis() TSRMLS_CC);

  eobj->esbcli = esb_client_new(keyPathFinal);
  free(keyPathFinal);
}

/**
 *
 */
PHP_METHOD(ESBClient, __destruct) {
  esb_object  *eobj;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);
  if (eobj->esbcli != NULL) {
    esb_client_destroy(eobj->esbcli);
  }
}

/**
 *
 */
PHP_METHOD(ESBClient, add_consume_subject) {
  long subject_id, client_id, sub_mode = ESB_SBJ_CMD_TYPE_PULL, ret_n;
  esb_object  *eobj;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);

  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ll|l", &subject_id, &client_id, &sub_mode) == FAILURE) {
    RETURN_LONG(-1);
  }
  if (eobj->esbcli == NULL) {
    RETURN_LONG(-1);
  }
  if (sub_mode != ESB_SBJ_CMD_TYPE_PUSH) {
    sub_mode = ESB_SBJ_CMD_TYPE_PULL;
  }

  ret_n = esb_add_consume_subject(eobj->esbcli, subject_id, client_id, sub_mode);
  if (ret_n < 0) {
    RETURN_LONG(ret_n);
  }
  RETURN_LONG(0);
}

/**
 *
 */
PHP_METHOD(ESBClient, consumer) {
  char *cb;
  long flag = 0, cb_len, ret_n;
  zval *callback_name;
  ESB_callback_ext_arg_t extArgStruct;
  esb_object  *eobj;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);

  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "z|l", &callback_name, &flag) == FAILURE) {
    RETURN_LONG(-1);
  }
  if (eobj->esbcli == NULL) {
    RETURN_LONG(-1);
  }

  extArgStruct.php_callback_name = callback_name;
  TSRMLS_SET_CTX(extArgStruct.tsrmls_ctx);
  /** 设置callback附加参数，用于传递php回调方法名 */
  esb_client_set_cbExtArg(eobj->esbcli, &extArgStruct);

  sprintf(eobj->esbcli->u_conf.external_lang_str, "PHP");
  sprintf(eobj->esbcli->u_conf.external_lang_version, PHP_ESB_CLIENT_VERSION);
  eobj->esbcli->u_conf.local_msg_queue_len = 600;
  eobj->esbcli->u_conf.each_pull_max_msg_cnt = 1;
  ret_n = esb_client_comsumer_zts(eobj->esbcli, &ESB_consume_msg_callback, flag);
  wmb_zval_ptr_dtor(&callback_name);
  if (ret_n < 0) {
    RETURN_LONG(ret_n);
  }
  RETURN_LONG(0);
}

void ESB_consume_msg_callback(esb_msg_t *msg, void *ext_arg)
{
  int re_call_cnt=0,reconsume_res;
  zval *callback_name, cb_ret_value;
  zval *msg_info;
  ESB_callback_ext_arg_t * extArgStruct;

  extArgStruct = (ESB_callback_ext_arg_t *)ext_arg;

  TSRMLS_FETCH_FROM_CTX(extArgStruct->tsrmls_ctx);

  callback_name = extArgStruct->php_callback_name;

  if (msg == NULL || msg->em_payload == NULL) {
    return;
  }

#if (PHP_MAJOR_VERSION < 7)
  MAKE_STD_ZVAL(msg_info);
  array_init(msg_info);
  add_assoc_stringl(msg_info, "msg_body", (char*)(msg->em_payload), (uint)(msg->payload_len), 1);
#else
  zval msg_info_val;
  msg_info = &msg_info_val;
  array_init(msg_info);
  add_assoc_stringl(msg_info, "msg_body", (char*)(msg->em_payload), (uint)(msg->payload_len));
#endif

  add_assoc_long(msg_info, "subject", (long)(msg->subject) );
  add_assoc_long(msg_info, "msg_id", (long)(msg->message_id) );
  add_assoc_long(msg_info, "client_id", (long)(msg->client_id) );
  add_assoc_long(msg_info, "cli_ip", (long)(msg->ip) );
  add_assoc_long(msg_info, "timestamp", (long)(msg->timestamp) );

RE_CALL:
#if (PHP_MAJOR_VERSION < 7)
  if (call_user_function(EG(function_table), NULL, callback_name, &cb_ret_value, 1, &msg_info TSRMLS_CC) == FAILURE ) {
#else
  if (call_user_function(EG(function_table), NULL, callback_name, &cb_ret_value, 1, msg_info TSRMLS_CC) == FAILURE ) {
#endif
    php_printf("\n[WARNING] call_user_function failed; Unable to call %s() function, is it defined? or belong to a namespace/class?\n\n", Z_STRVAL_P(callback_name));
    php_error_docref(NULL TSRMLS_CC, E_WARNING, "Unable to call %s() function, is it defined? or belong to a namespace/class? is_callable=%d EG-status: %d/%d", Z_STRVAL_P(callback_name), zend_is_callable(callback_name, 0, NULL TSRMLS_CC), !EG(active), EG(exception));
    if (EG(exception)) {
      zend_exception_error(EG(exception), E_WARNING TSRMLS_CC);
      // 尝试1次 重新执行 callback
      if (re_call_cnt == 0) {
        re_call_cnt += 1;
        goto RE_CALL;
      }
    }
  }

  if (Z_TYPE(cb_ret_value) == IS_LONG && Z_LVAL(cb_ret_value) == -110) {
    reconsume_res = esb_client_reConsume(msg);
    if (reconsume_res < 0)
    {
      php_error_docref(NULL TSRMLS_CC, E_WARNING, "call ESB reConsume API failed! msg_id:%d, reconsume_res:%d", (long)(msg->message_id), reconsume_res);
    }
  }

  wmb_zval_ptr_dtor(&msg_info);
  return;
}

/**
 * log输出级别控制
 */
PHP_FUNCTION(ESBclient_set_logPrintLevel)
{
  long level;

  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "l", &level) == FAILURE) {
    return;
  }
  esb_client_set_logPrintLevel(level);
  return;
}

int Split_key_clientid(char *key_path_in, char **key_path, long *clientid) {
  char equal[] = "=";
  char question[] = "?";
  char *f_path, *cli_id, *cli_k, *cli_v;
  int ret;

  /** 截取key文件路径 */
  f_path = strtok(key_path_in, question);
  if (f_path == NULL)
    return -1;
  *key_path = f_path;
  /** 截取client_id */
  cli_id = strtok(NULL, question);
  if (cli_id == NULL)
    return -1;
  cli_k = strtok(cli_id, equal);
  if (cli_k == NULL)
    return -1;
  cli_v = strtok(NULL, equal);
  if (cli_v == NULL)
    return -1;
  ret = atoi(cli_v);
  if (ret == 0)
    return -1;

  *clientid = ret;
  return 0;
}

/**
 * V1版客户端接口，向下兼容
 */
PHP_FUNCTION(ESBclient_consumer_loop)
{
  char *key_path, *key_path_real;
  int ret_n, key_path_len;
  long subject, flag = 0, pull_cnt = 0, client_id;
  zval *callback_name;
  esb_client_t *esbcli;
  ESB_callback_ext_arg_t extArgStruct;

#if (PHP_MAJOR_VERSION < 7)
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "zsl|ll", &callback_name, &key_path, &key_path_len, &subject, &flag, &pull_cnt) == FAILURE) {
    RETURN_FALSE;
  }
#else
  zval *kval;
  zend_string *kstr;
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "zzl|ll", &callback_name, &kval, &subject, &flag, &pull_cnt) == FAILURE) {
    RETURN_FALSE;
  }
  if (Z_TYPE_P(kval) == IS_NULL || Z_TYPE_P(kval) != IS_STRING) {
    RETURN_FALSE;
    return;
  }
  kstr = Z_STR_P(kval);
  key_path = ZSTR_VAL(kstr);
  key_path_len = ZSTR_LEN(kstr);
#endif

  ret_n = Split_key_clientid(key_path, &key_path_real, &client_id);
  if (ret_n < 0) {
    php_printf("key path illegal; str:%s\n", key_path);
    RETURN_FALSE;
  }

  esbcli = esb_client_new(key_path_real);
  if (esbcli == NULL) {
    php_printf("new esb client failed\n");
    RETURN_FALSE;
  }
  ret_n = esb_add_consume_subject(esbcli, subject, client_id, ESB_SBJ_CMD_TYPE_PULL);
  if (ret_n < 0) {
    RETURN_FALSE;
  }
  sprintf(esbcli->u_conf.external_lang_str, "PHP");
  sprintf(esbcli->u_conf.external_lang_version, PHP_ESB_CLIENT_VERSION);
  esbcli->u_conf.local_msg_queue_len = 600;
  esbcli->u_conf.each_pull_max_msg_cnt = 1;
  if (pull_cnt > 0 && pull_cnt <= 3) {
    esbcli->u_conf.each_pull_max_msg_cnt = pull_cnt;
  }

  extArgStruct.php_callback_name = callback_name;
  TSRMLS_SET_CTX(extArgStruct.tsrmls_ctx);
  esb_client_set_cbExtArg(esbcli, &extArgStruct);

  ret_n = esb_client_comsumer_zts(esbcli, &ESB_consume_msg_callback, flag);
  wmb_zval_ptr_dtor(&callback_name);
  esb_client_destroy(esbcli);
  if (ret_n < 0) {
    RETURN_FALSE;
  }
  RETURN_TRUE;
}

/**
 * “主动消费”模式；启动后台消费者
 */
PHP_METHOD(ESBClient, backend_consumer_start) {
  long ret_n;
  esb_object  *eobj;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);

  if (eobj->esbcli == NULL) {
    RETURN_LONG(-1);
  }

  sprintf(eobj->esbcli->u_conf.external_lang_str, "PHP");
  sprintf(eobj->esbcli->u_conf.external_lang_version, PHP_ESB_CLIENT_VERSION);
  eobj->esbcli->u_conf.local_msg_queue_len = 600;
  eobj->esbcli->u_conf.each_pull_max_msg_cnt = 1;
  ret_n = esb_client_consume_autonomy_start(eobj->esbcli, 0);
  if (ret_n < 0) {
    RETURN_LONG(ret_n);
  }

  RETURN_LONG(0);
}

/**
 * “主动消费”模式；主动获取一条消息
 */
PHP_METHOD(ESBClient, fetch_message) {
  esb_object  *eobj;
  esb_msg_t  my_msg;
  long result;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);
  if (eobj->esbcli == NULL) {
    RETURN_LONG(-1);
  }

  memset(&my_msg, 0, sizeof(esb_msg_t));
  result = esb_localQueue_consume_autonomy(eobj->esbcli, &my_msg);
  if (result == ESB_RET_QUEUE_EMPTY) {
    RETURN_LONG(ESB_RET_QUEUE_EMPTY);
  }
  if (result < 0) {
    RETURN_LONG(result);
  }

  array_init(return_value);
#if (PHP_MAJOR_VERSION < 7)
  add_assoc_stringl(return_value, "msg_body", (char*)(my_msg.em_payload), (uint)(my_msg.payload_len), 1);
#else
  add_assoc_stringl(return_value, "msg_body", (char*)(my_msg.em_payload), (uint)(my_msg.payload_len));
#endif
  add_assoc_long(return_value, "subject", (long)(my_msg.subject) );
  add_assoc_long(return_value, "msg_id", (long)(my_msg.message_id) );
  add_assoc_long(return_value, "client_id", (long)(my_msg.client_id) );
  add_assoc_long(return_value, "cli_ip", (long)(my_msg.ip) );
  add_assoc_long(return_value, "timestamp", (long)(my_msg.timestamp) );
  return;
}

/**
 * “主动消费”模式；准备关闭后台消费者
 */
PHP_METHOD(ESBClient, backend_consumer_stop) {
  esb_object  *eobj;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);
  if (eobj->esbcli == NULL) {
    RETURN_LONG(-1);
  }

  esb_client_prepare_to_close(eobj->esbcli);

  RETURN_LONG(0);
}

/**
 * “主动消费”模式；清理消费者相关资源
 */
PHP_METHOD(ESBClient, close_callback) {
  esb_object  *eobj;

  eobj = esb_object_get_instance(getThis() TSRMLS_CC);
  if (eobj->esbcli == NULL) {
    RETURN_LONG(-1);
  }

  esb_client_close_callback(eobj->esbcli);
  eobj->esbcli = NULL;
  RETURN_LONG(0);
}



/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(esb_client)
{
  zend_class_entry esbclient;
  INIT_CLASS_ENTRY(esbclient, "ESBClient", ESBClient_functions);
  ESBClient_ce = zend_register_internal_class(&esbclient TSRMLS_CC);
  ESBClient_ce->create_object = create_esb_object;

  REGISTER_LONG_CONSTANT("ESB_PRINT_CLOSE", 0, CONST_CS | CONST_PERSISTENT);
  REGISTER_LONG_CONSTANT("ESB_PRINT_ERROR", 1, CONST_CS | CONST_PERSISTENT);
  REGISTER_LONG_CONSTANT("ESB_PRINT_WARNING", 2, CONST_CS | CONST_PERSISTENT);
  REGISTER_LONG_CONSTANT("ESB_PRINT_NOTICE", 3, CONST_CS | CONST_PERSISTENT);
  REGISTER_LONG_CONSTANT("ESB_PRINT_DEBUG", 4, CONST_CS | CONST_PERSISTENT);

  REGISTER_LONG_CONSTANT("ESB_SBJ_CMD_TYPE_PULL", 1, CONST_CS | CONST_PERSISTENT);
  REGISTER_LONG_CONSTANT("ESB_SBJ_CMD_TYPE_PUSH", -1, CONST_CS | CONST_PERSISTENT);

  REGISTER_LONG_CONSTANT("ESB_RETVAL_RECONSUME_MSG", -110, CONST_CS | CONST_PERSISTENT);

  REGISTER_LONG_CONSTANT("ESB_RETVAL_QUEUE_EMPTY", ESB_RET_QUEUE_EMPTY, CONST_CS | CONST_PERSISTENT);

#ifdef ZTS
  ts_allocate_id(&esb_client_globals_id,
                 sizeof(zend_esb_client_globals),
                 NULL, NULL);
#endif
  return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(esb_client)
{
  /* uncomment this line if you have INI entries
  UNREGISTER_INI_ENTRIES();
  */
  return SUCCESS;
}
/* }} } */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(esb_client)
{
  return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(esb_client)
{
  return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(esb_client)
{
  php_info_print_table_start();
  php_info_print_table_header(2, "esb_client support", "enabled");
  php_info_print_table_end();

  /* Remove comments if you have entries in php.ini
  DISPLAY_INI_ENTRIES();
  */
}
/* }}} */

/* {{{ esb_client_functions[]
 *
 * Every user visible function must have an entry in esb_client_functions[].
 */
const zend_function_entry esb_client_functions[] = {
  PHP_FE(ESBclient_set_logPrintLevel, NULL)
  PHP_FE(ESBclient_consumer_loop, NULL)
  {NULL, NULL, NULL} /* Must be the last line in esb_client_functions[] */
};
/* }}} */

/* {{{ esb_client_module_entry
 */
zend_module_entry esb_client_module_entry = {
  STANDARD_MODULE_HEADER,
  "esb_client",
  esb_client_functions,
  PHP_MINIT(esb_client),
  PHP_MSHUTDOWN(esb_client),
  NULL,
  NULL,
  PHP_MINFO(esb_client),
  PHP_ESB_CLIENT_VERSION,
  STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_ESB_CLIENT
ZEND_GET_MODULE(esb_client)
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
