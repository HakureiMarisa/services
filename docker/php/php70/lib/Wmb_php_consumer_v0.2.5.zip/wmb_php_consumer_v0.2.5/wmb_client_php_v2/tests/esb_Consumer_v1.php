<?php
/**
 * @brief  WMB(esb)消息总线php客户端，V1版消费者兼容API，使用 “范例”
 *         
 * @auth   58ganji - Chen Peng - 
 * @mail   chenpeng12@58ganji.com
 */

/** 用户自己定义的处理消息的入口，callback函数 */
class Foo {
    static public function my_callback($msg) {
        /** 此方法需要能接收一个参数，这是一个array,
         *  var_dump一次看一看，你就知道你的消息body在哪里了,
         *  另外，array里还提供了一些消息的元数据.
         */
        var_dump($msg);
    }
}

/** 此方法可以设置printf日志输出级别（输出到“标准输出”,请自行“重定向”到文件）， 
 *  默认 ESB_PRINT_WARNING    可选：ESB_PRINT_NOTICE、ESB_PRINT_DEBUG  */
//ESBclient_set_logPrintLevel(ESB_PRINT_DEBUG);
//ESBclient_set_logPrintLevel(ESB_PRINT_NOTICE);

/** keyPath参数,客户端id, 形如："秘钥文件路径?clientid=x" */
/** 通常，需要自行申请好 秘钥，以及clientid，才能运行 */
$keyPath_and_clientid = "./testkey.key?clientid=2";

/**
 * [ESBclient_consumer_loop 消费者启动入口方法，将会阻塞执行，接收到消息，会调起callback]
 * 参数  callback              [回调函数名]
 * 参数  keyPath_and_clientid  [key路径及client]
 * 参数  subject_id            [主题id]
 * 返回值 [返回整数，<0代表异常退出，>=0代表正常平滑退出]
 */
$ret = ESBclient_consumer_loop("Foo::my_callback", $keyPath_and_clientid, 131313);
/** callback 可以是“某个类的静态方法”（如上所示），当然也可以是“普通函数”（如下所示） */
//$ret = ESBclient_consumer_loop("my_callback", $keyPath_and_clientid, 123456);


echo "\n Consumer exit status:$ret \n";

?>
