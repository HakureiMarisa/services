<?php
/**
 * @brief  WMB(esb)消息总线php客户端，消费者使用 “范例”
 *         
 * @auth   58ganji - Chen Peng - 
 * @mail   chenpeng12@58ganji.com
 */

/** 用户自己定义的处理消息的入口，callback函数 */
class Foo {
    static public function my_callback($msg) {
        /** 此方法需要能接收一个参数，这是一个array,
         *  var_dump一下，就知道你的消息body在哪里了,
         *  另外，array里还提供了一些消息的元数据.
         */
        var_export($msg, false);

        /** 
         *  另外WMB目前支持了“重复消费”功能，可以把消费逻辑执行失败的msg发回到server，
         *  一段时间之后再下发到消费端重新消费。
         *  如果需要使用此功能，就return ESB_RETVAL_RECONSUME_MSG 这个常量即可。
         */
        //if ($execute_msg_failed === true) {
        //	return ESB_RETVAL_RECONSUME_MSG;
        //}
    }
}

/** 可以设置printf日志输出级别（输出到“标准输出”,请自行“重定向”到文件）， 
 *  默认 ESB_PRINT_WARNING    可选：ESB_PRINT_NOTICE、ESB_PRINT_DEBUG  */
//ESBclient_set_logPrintLevel(ESB_PRINT_DEBUG);

/**
 * 新建ESBClient对象
 */
$keyPath = "./testkey.key";
$esbcli = new ESBClient($keyPath);

/** 添加需要消费的主题
 *  参数：主题id、client_id
 *  注意：可以通过多次调用add_consume_subject，实现同时消费多个主题的功能
 */
$ret = $esbcli->add_consume_subject(131313, 2);
if($ret < 0) {
    exit("add consume subject failed! ret:$ret \n");
}

/**
 * 启动消费者（阻塞执行）
 * 参数：
 *     callback函数名（可以是类的静态方法，也可以是普通的函数）
 * 注意：
 *     此方法会一直阻塞，当有消息到达时，调起callback。
 *     进程会自动捕获信号（包括SIGINT、SIGQUIT、SIGABRT、SIGTERM），平滑关闭消费者，此方法返回。
 * 重要：
 *     非平滑的关闭（如：kill -9），会引起消息丢失！
 */
$ret = $esbcli->consumer("Foo::my_callback");

echo "\n Consumer exit status:$ret \n";


?>
