<?php
/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

/** 仅用于测试扩展是否被成功安装、加载 */

$br = (php_sapi_name() == "cli")? "":"<br>";

if(!extension_loaded('esb_client')) {
	dl('esb_client.' . PHP_SHLIB_SUFFIX);
}
$module = 'esb_client';
$functions = get_extension_funcs($module);
echo "Functions available in the test extension:$br\n";

/** 打印扩展所提供的所有方法 */
foreach($functions as $func) {
    echo $func."$br\n";
}
echo "$br\n";


?>
