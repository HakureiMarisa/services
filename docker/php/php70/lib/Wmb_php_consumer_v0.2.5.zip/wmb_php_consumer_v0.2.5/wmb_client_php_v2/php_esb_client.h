/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2016 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#include "esbclient_v2/esbclient.h"

#ifndef PHP_ESB_CLIENT_H
#define PHP_ESB_CLIENT_H

extern zend_module_entry esb_client_module_entry;
#define phpext_esb_client_ptr &esb_client_module_entry

#define PHP_ESB_CLIENT_VERSION "0.2.5" /* Replace with version number for your extension */

#ifdef PHP_WIN32
# define PHP_ESB_CLIENT_API __declspec(dllexport)
#elif defined(__GNUC__) && __GNUC__ >= 4
# define PHP_ESB_CLIENT_API __attribute__ ((visibility("default")))
#else
# define PHP_ESB_CLIENT_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

/*
    Declare any global variables you may need between the BEGIN
  and END macros here:

*/
ZEND_BEGIN_MODULE_GLOBALS(esb_client)
//long  global_value;
//char *global_string;
ZEND_END_MODULE_GLOBALS(esb_client)

/* In every utility function you add that needs to use variables
   in php_esb_client_globals, call TSRMLS_FETCH(); after declaring other
   variables used by that function, or better yet, pass in TSRMLS_CC
   after the last function argument and declare your utility function
   with TSRMLS_DC after the last declared argument.  Always refer to
   the globals in your function as ESB_CLIENT_G(variable).  You are
   encouraged to rename these macros something shorter, see
   examples in any other php module directory.
*/

#ifdef ZTS
#define ESB_CLIENT_G(v) TSRMG(esb_client_globals_id, zend_esb_client_globals *, v)
#else
#define ESB_CLIENT_G(v) (esb_client_globals.v)
#endif

#if PHP_MAJOR_VERSION < 7
#define wmb_zval_ptr_dtor               zval_ptr_dtor
#else
#define wmb_zval_ptr_dtor(p)            zval_ptr_dtor(*p) //用*操作把指针的指针变成指针（好绕口）
#endif

typedef struct ESB_callback_ext_arg_s {
  zval * php_callback_name;
  void * tsrmls_ctx;
} ESB_callback_ext_arg_t;

void ESB_consume_msg_callback(esb_msg_t *msg, void *ext_arg);

/** esb object define  */
#if (PHP_MAJOR_VERSION < 7)
typedef struct _esb_object {
  zend_object   std;
  esb_client_t  *esbcli;
} esb_object;
#else
typedef struct _esb_object {
  esb_client_t  *esbcli;
  zend_object   std;
} esb_object;
#endif

/* ESBClient class */
static PHP_METHOD(ESBClient, __construct);
static PHP_METHOD(ESBClient, __destruct);
static PHP_METHOD(ESBClient, add_consume_subject);
static PHP_METHOD(ESBClient, consumer);
static PHP_METHOD(ESBClient, backend_consumer_start);
static PHP_METHOD(ESBClient, fetch_message);
static PHP_METHOD(ESBClient, backend_consumer_stop);
static PHP_METHOD(ESBClient, close_callback);

#endif  /* PHP_ESB_CLIENT_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
