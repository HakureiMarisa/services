/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_REGISTRY_JSON_H
#define _ESBCLI_REGISTRY_JSON_H


#include "cJSON.h"

/**
 *
 */
typedef struct ClusterConf_json_s {
	long     hashCode;
	int      type;
	long     version;
	char   **nodes;     // 节点ip:port 数组
	int      node_cnt;
} ClusterConf_json_t;

/**  */
typedef struct esb_SubjectConf_json_s {
	int     clientId;
	int     name;
	int     type;
	//char   *ext;
	long   *clusters;  // 集群id 数组
	int     clu_cnt;
} SubjectConf_json_t;

/**  */
typedef struct esb_StoreConf_json_s {
	char	*clusterId;
	int		storeId;
	int		weight;
	int		type;
	char   **nodes;
	int     node_cnt;
} StoreConf_json_t;

/**  */
typedef struct regConf_Json_s {
	/** 集群配置 数组 */
	ClusterConf_json_t  *cluConf_array;
	int                  clu_array_cnt;

	/** 主题配置 数组 */
	SubjectConf_json_t  *sbjConf_array;
	int                  sbj_array_cnt;

	/** store配置 数组 */
	StoreConf_json_t	*storeConf_array;
	int					 store_array_cnt;

	char                *key;
} regConf_json_t;

regConf_json_t *new_regConf_json_t();
void free_regConf_json_t(regConf_json_t *conf_obj);

int parse_regConf_from_json(regConf_json_t *conf_obj, cJSON *js_root);

void reset_ClusterConf_json_t(ClusterConf_json_t *cluConf);
void reset_SubjectConf_json_t(SubjectConf_json_t *sbjConf);

#endif
