/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <assert.h>

#include "esbclient.h"
#include "esbcli_util.h"
#include "esbcli_subject.h"
#include "esbcli_cluster.h"
#include "esbcli_crontab.h"

/**
 * 全局退出标记
 * 用于指示所有的 ESBclient 执行“平滑关闭”操作
 */
int GlobleExitFlag = 0;

/**
 * 全局关闭信号处理标记
 * 确保所有线程，不注册信号处理函数
 *（应用在Golang环境中，避免CGO模式下的信号冲突）
 */
int GlobleNoSigHandleFlag = 0;


/**
 * [sig_handler_func 信号处理函数]
 * @param signum [信号]
 */
static void sig_handler_func(int signum) {
	long int tid;
	pthread_t pth_id;
	tid = (long int)ESB_gettid();
	pth_id = pthread_self();
	/** 处理各种“退出”信号 */
	if (signum == SIGINT || signum == SIGQUIT || signum == SIGABRT || signum == SIGTERM)
	{
		/** 设置“全局退出标记” */
		GlobleExitFlag = 1;
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> close signal received, i am closing; signum:%d]\n", __FUNCTION__, __LINE__, signum);
	}
	if (signum == SIGPIPE) {
		/** 忽略SIGPIPE信号，避免死链接导致进程退出 */
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> SIGPIPE received,Do nothing; signum:%d]\n", __FUNCTION__, __LINE__, signum);
	}
}

/**
 * [esb_set_sig_action 信号初始化]
 */
void esb_set_signal_action() {
	struct sigaction sig_act;

	if (GlobleNoSigHandleFlag == 1) {
		return;  // 不注册信号处理函数（应用在Golang环境中，避免CGO模式下的信号冲突）
	}

	sigemptyset(&sig_act.sa_mask);
	//sig_act.sa_flags = SA_RESTART;  // “自动重新发起被信号打断的系统调用”
	sig_act.sa_handler = sig_handler_func;
	sigaction(SIGINT, &sig_act, NULL);
	sigaction(SIGQUIT, &sig_act, NULL);
	sigaction(SIGABRT, &sig_act, NULL);
	sigaction(SIGTERM, &sig_act, NULL);
	sigaction(SIGPIPE, &sig_act, NULL);
}

void esb_set_signal_action_sigpipe() {
	struct sigaction sig_act;

	if (GlobleNoSigHandleFlag == 1) {
		return;  // 不注册信号处理函数（应用在Golang环境中，避免CGO模式下的信号冲突）
	}

	sigemptyset(&sig_act.sa_mask);
	sig_act.sa_handler = sig_handler_func;
	sigaction(SIGPIPE, &sig_act, NULL);
}

void esb_client_set_noSigHandle() {
	GlobleNoSigHandleFlag = 1;
}

/**
 * [esb_set_sig_action 信号初始化]
 */
void esb_set_signal_handler(esb_sig_handler sig_handler) {
	struct sigaction sig_act;

	sigemptyset(&sig_act.sa_mask);
	//sig_act.sa_flags = SA_RESTART;  // “自动重新发起被信号打断的系统调用”
	sig_act.sa_handler = sig_handler;
	sigaction(SIGINT, &sig_act, NULL);
	sigaction(SIGQUIT, &sig_act, NULL);
	sigaction(SIGABRT, &sig_act, NULL);
	sigaction(SIGTERM, &sig_act, NULL);
	sigaction(SIGPIPE, &sig_act, NULL);
}

/**
 * [esb_client_new  新建esbclient对象]
 * @param  key_path         [key文件路径]
 * @return esb_client_t*    [对象指针]
 */
esb_client_t * esb_client_new(char *key_path) {
	esb_client_t *ecli;
	int ret = 0;

	if (key_path == NULL) {
		esb_set_error(ESB_ERR_KPATH_ILLEGAL);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: key_path is NULL]\n", __FUNCTION__, __LINE__);
		return NULL;
	}

	ecli = (esb_client_t *)calloc(1, sizeof(esb_client_t));
	assert(ecli);

	/** 反向指针赋值 */
	ecli->reg.esbcli = (void*)ecli;

	/** key读取 */
	ret = registrykeyInit(&ecli->reg, key_path);
	if (ret < 0) {
		// error,what to do?
		esb_set_error(ret);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registrykeyInit ret] %d\n", __FUNCTION__, __LINE__, ret);
		free_esb_client(ecli);
		return NULL;
	}
	if (ecli->reg.registry_ip == NULL || ecli->reg.registry_port == 0) {
		esb_set_error(ESB_ERR_KPATH_ADDR);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registrykeyInit registry addr error]\n", __FUNCTION__, __LINE__);
		// error,what to do?
		free_esb_client(ecli);
		return NULL;
	}

	/** 连接 注册中心 */
	ret = registryConnectServer(&ecli->reg);
	if (ret < 0) {
		esb_set_error(ESB_ERR_REG_CONN);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registryConnectServer ret] %d\n", __FUNCTION__, __LINE__, ret);
		// error,what to do?
		free_esb_client(ecli);
		return NULL;
	}

	/** 从注册中心请求 broker配置 */
	ret = registryGetBrokerConf(&ecli->reg);
	if (ret < 0)
	{
		esb_set_error(ESB_ERR_REG_CONF);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registryGetBrokerConf ret] %d\n", __FUNCTION__, __LINE__, ret);
		// error,what to do?
		free_esb_client(ecli);
		return NULL;
	}

	/** opaque_counter 初始化 */
	ecli->opaque_counter = 0;
	ESB_mutex_init(&ecli->opaque_mutex, NULL);
	/** in_callback_worker_cnt 初始化 */
	ecli->in_callback_worker_cnt = 0;
	ESB_mutex_init(&ecli->in_callback_mutex, NULL);

	ecli->queue_global_index = hash_new();
	ecli->cli_sbj_map = hash_new();
	ecli->cli_cluster_map = hash_new();
	ecli->cli_store_map = hash_new();
	ecli->cli_store_weight_map = hash_new();

	esb_client_set_store_conf(ecli);

	/** u_conf配置参数，设定默认值 */
	ecli->u_conf.local_msg_queue_len = 8100;
	ecli->u_conf.each_pull_max_msg_cnt = 10;
	ecli->u_conf.pull_request_timeout_sec = 3;
	ecli->u_conf.worker_thread_count = sysconf(_SC_NPROCESSORS_ONLN);
	ecli->send_hd = NULL;
	ecli->is_start_dispatch = 0;
	ESB_mutex_init(&ecli->start_send_mutex, NULL);
	ESB_mutex_init(&ecli->start_dispatch_mutex, NULL);

	ecli->sbj_send_info = hash_new();

	ecli->abondan_queue = hash_new();
//	printf("zsj 测试 ecli->abondan_queue 初始化完成！！！！");
	ecli->wait_windows = hash_new();

	ecli->esbcli_send_close_flag = 0;
	return ecli;
}

void esb_client_destroy(esb_client_t *esbcli) {
	free_esb_client(esbcli);
	return;
}

void esb_client_prepare_to_close(esb_client_t *esbcli) {
	/** 设置“全局退出标记” */
	GlobleExitFlag = 1;
	/**  */
	esbcli->esbcli_close_flag = 1;
}

/**
 * [free_esb_client description]
 * @param esbcli [description]
 */
void free_esb_client(esb_client_t *esbcli) {
	esb_subject_t *sbj;
	esb_cluster_t *clu;
	esb_store_t *store;
	window_data_t *wd;

	if (esbcli == NULL)
		return;
	registry_reset(&esbcli->reg);
	if (esbcli->esb_evbase != NULL)
		{ESB_event_base_free(esbcli->esb_evbase); esbcli->esb_evbase = NULL;}
	if (esbcli->reg.reg_sock_fd > 0)
		{close(esbcli->reg.reg_sock_fd); esbcli->reg.reg_sock_fd = NULL;}
	if (esbcli->queue_global_index != NULL) {
		hash_free(esbcli->queue_global_index);
	}
	if(esbcli->send_hd != NULL){
		free_esb_send_hd(esbcli->send_hd);
	}
	if (esbcli->cli_sbj_map != NULL) {
		hash_each(esbcli->cli_sbj_map, {
			sbj = (esb_subject_t*)val;
			free_esb_subject(sbj);
		});
		hash_free(esbcli->cli_sbj_map);
		esbcli->cli_sbj_map = NULL;
	}
	if (esbcli->cli_cluster_map != NULL) {
		hash_each(esbcli->cli_cluster_map, {
			clu = (esb_cluster_t*)val;
			free_esb_cluster(clu);
		});
		hash_free(esbcli->cli_cluster_map);
		esbcli->cli_cluster_map = NULL;
	}
	if (esbcli->cli_store_map != NULL) {
		hash_each(esbcli->cli_store_map, {
			store = (esb_store_t*)val;
			free_esb_store(store);
		});
		hash_free(esbcli->cli_store_map);
		esbcli->cli_store_map = NULL;
	}
	if (esbcli->cli_store_weight_map != NULL) {
		hash_free(esbcli->cli_store_weight_map);
		esbcli->cli_store_weight_map = NULL;
	}
	if (esbcli->all_thrd_handles != NULL)
		{free(esbcli->all_thrd_handles); esbcli->all_thrd_handles = NULL;}
	if (esbcli->esb_cron_thrd != NULL) {
		{free(esbcli->esb_cron_thrd); esbcli->esb_cron_thrd = NULL;}
	}
	if (esbcli->esb_dispatch_loop_thrd != NULL) {
		{free(esbcli->esb_dispatch_loop_thrd); esbcli->esb_dispatch_loop_thrd = NULL;}
	}
	if (esbcli->GLB_msg_array != NULL) {
		/** 释放本地消息msg对象队列 */
		free_Local_msg_queue(esbcli);
	}
//	if (esbcli->send_hd != NULL) {
//		free_esb_send_hd(esbcli->send_hd);
//	}
	if (esbcli->wait_windows != NULL) {
		hash_each(esbcli->wait_windows, {
			wd = (window_data_t*)val;
			free_window_data(wd);
		});
		hash_free(esbcli->wait_windows);
		esbcli->wait_windows = NULL;
	}
	if (esbcli->sbj_send_info != NULL) {
		hash_each(esbcli->sbj_send_info, {
			free((char *)key);
		});
		hash_free(esbcli->sbj_send_info);
		esbcli->sbj_send_info = NULL;
	}
	ESB_mutex_destory(&esbcli->start_send_mutex);
	ESB_mutex_destory(&esbcli->start_dispatch_mutex);
	ESB_mutex_destory(&esbcli->in_callback_mutex);
//	printf("调用销毁锁~！~！~！~！~！~！\n");
	ESB_mutex_destory(&esbcli->opaque_mutex);

	free(esbcli);
}

void esb_client_set_store_conf(esb_client_t *esbcli) {
	char *store_key, *store_val, *cluster_id;
	regConf_json_t *regConf_obj;
	StoreConf_json_t *storeConf;
	esb_store_t *esb_store;
	int i;
	char *weightPtr;

	regConf_obj = esbcli->reg.reg_conf_obj;

	hash_t *new_store_weight_map = hash_new();

	for (i = 0; i < regConf_obj->store_array_cnt; ++i) {
		storeConf = &regConf_obj->storeConf_array[i];

		/** 查找，必要时，新建 store 对象 */
		store_key = (char*)calloc(1, 64);
		sprintf(store_key, "%s&%d", storeConf->clusterId, storeConf->storeId);
		esb_store = new_esb_store(store_key, storeConf->weight, esbcli);

		hash_set(new_store_weight_map, store_key, esb_store);
		free(store_key);
	}

	hash_t *old_store_weight_map = esbcli->cli_store_weight_map;
	esbcli->cli_store_weight_map = new_store_weight_map;

	hash_free(old_store_weight_map);
}

/**
 * [esb_client_add_subject description]
 * @param  esbcli     [description]
 * @param  subject_id [description]
 * @param  client_id  [description]
 * @param  sub_mode   [description]
 * @return            [description]
 */
int esb_add_consume_subject(esb_client_t *esbcli, int subject_id,
                            int client_id, int sub_mode) {
	int ret;
	esb_subject_t *sbj;

	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}
	if (esbcli->client_type == ESB_CLI_TYPE_COMSUMER && esbcli->esb_evbase != NULL) {
		esb_set_error(ESB_ERR_ECLI_ISRUNING);
		return ESB_ERR_ECLI_ISRUNING;
	}
	sbj = new_esb_subject(subject_id, client_id, sub_mode);

	/** 初始化订阅主题相关的“配置”、“集群”、“broker” */
	ret = find_sbj_and_init_cluster(esbcli, sbj, ESB_CLI_TYPE_COMSUMER);
	if (ret < 0) {
		/** 初始化失败，退出，报错 */
		free_esb_subject(sbj);
		return ret;
	}

	/** 插入hash map */
	hash_set(esbcli->cli_sbj_map, get_sbj_map_key(sbj), sbj);
	return 1;
}

void esb_client_set_logPrintLevel(int level) {
	GlobleLogPrintLevel = level;
}

int esb_client_set_cbExtArg(esb_client_t *esbcli, void * ext_arg) {
	if (esbcli == NULL)
		return -1;
	esbcli->cb_ext_arg = ext_arg;
	return 0;
}

int esb_client_comsumer_zts(esb_client_t *esbcli, esb_consume_msg_cb comsume_cb, int flag) {
	char *map_key;
	int ret, status, i;
	esb_cluster_t *clu;

	esbcli->client_type = ESB_CLI_TYPE_COMSUMER;
	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}
	if (hash_size(esbcli->cli_cluster_map) <= 0 || hash_size(esbcli->cli_sbj_map) <= 0)
	{
		esb_set_error(ESB_ERR_ECLI_NOBRK);
		return ESB_ERR_ECLI_NOBRK;
	}

	/** 初始化各种 “退出信号”处理方法 */
	esb_set_signal_action();

	status = ESB_evthread_use_pthreads();
	if (status < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_evthread_use_pthreads status < 0]\n", __FUNCTION__, __LINE__);
		return -1;
	}

	/** 全局 event 句柄，初始化  */
	esbcli->esb_evbase = ESB_event_base_new();
	/** 初始化一定数量的 msg对象，插入空闲链表备用 */
	status = init_Local_msg_queue(esbcli, esbcli->u_conf.local_msg_queue_len);
	if (status < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: init_Local_msg_queue status] %d\n", __FUNCTION__, __LINE__, status);
		return -1;
	}

	/** 设置callback函数 */
	esbcli->msg_callback = comsume_cb;
	/** 启动每个cluster“集群”，以及所属的每个broker */
	hash_each(esbcli->cli_cluster_map, {
		map_key = key;
		clu = (esb_cluster_t*)val;
		/** 仅启动用于 “消费” 的集群 type=1 */
		if (clu->type != ESB_CLI_TYPE_COMSUMER)
			continue;
		status = cluster_start_each_broker(clu);
		if (status < 0) {
			esb_set_error(status);
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: cluster_start_each_broker,clu:%s status] %d\n", __FUNCTION__, __LINE__, map_key, status);
			esbcli->esbcli_close_flag = 1;
		}
	});

	esbcli->esb_cron_thrd = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
	/** 启动 cron定时任务 线程 */
	ESB_thread_create(esbcli->esb_cron_thrd, NULL, (void*)&esb_cron_thread, &esbcli->reg);

	/** 持续消费local queue,并调起callback,（阻塞）*/
	esb_localQueue_consume_thread((void*)esbcli);

	/** 等待事件循环退出 */
	ret = ESB_thread_join(*esbcli->esb_dispatch_loop_thrd, NULL);
	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> Thread dispatch_loop ended smoothed]%d\n", __FUNCTION__, __LINE__, ret);

	/** 等待crontab线程退出 */
	ESB_thread_join(*esbcli->esb_cron_thrd, NULL);
	return status;
}

/**
 * [esb_client_comsumer_loop description]
 * @param  esbcli     [description]
 * @param  comsume_cb [description]
 * @param  flag       [description]
 * @return            [description]
 */
int esb_client_comsumer_loop(esb_client_t *esbcli, esb_consume_msg_cb comsume_cb, int flag) {
	char *map_key;
	int ret, status, i;
	esb_cluster_t *clu;

	esbcli->client_type = ESB_CLI_TYPE_COMSUMER;
	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}
	if (hash_size(esbcli->cli_cluster_map) <= 0 || hash_size(esbcli->cli_sbj_map) <= 0)
	{
		esb_set_error(ESB_ERR_ECLI_NOBRK);
		return ESB_ERR_ECLI_NOBRK;
	}

	/** 初始化各种 “退出信号”处理方法 */
	esb_set_signal_action();

	status = ESB_evthread_use_pthreads();
	if (status < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_evthread_use_pthreads status < 0]\n", __FUNCTION__, __LINE__);
		return -1;
	}

	/** 全局 event 句柄，初始化  */
	esbcli->esb_evbase = ESB_event_base_new();

	/** 初始化一定数量的 msg对象，插入空闲链表备用 */
	status = init_Local_msg_queue(esbcli, esbcli->u_conf.local_msg_queue_len);
	if (status < 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: init_Local_msg_queue status] %d\n", __FUNCTION__, __LINE__, status);
		// error, what to do?
		return -1;
	}

	/** 设置callback函数 */
	esbcli->msg_callback = comsume_cb;

	/** 启动每个cluster“集群”，以及所属的每个broker */
	hash_each(esbcli->cli_cluster_map, {
		map_key = key;
		clu = (esb_cluster_t*)val;
		/** 仅启动用于 “消费” 的集群 type=1 */
		if (clu->type != ESB_CLI_TYPE_COMSUMER)
			continue;
		status = cluster_start_each_broker(clu);
		if (status < 0)
		{
			esb_set_error(status);
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: cluster_start_each_broker,clu:%s status] %d\n", __FUNCTION__, __LINE__, map_key, status);
			// error, what to do?
			//return status;
			esbcli->esbcli_close_flag = 1;
		}
	});

	/** 默认启动1个worker线程，除非flag设置了“多线程”标记，则按cpu核数启动多个线程 */
	if ((ESB_ENABLE_MULTI_THREAD_CONSUME & flag) == 0 || esbcli->u_conf.worker_thread_count <= 0)
	{
		esbcli->u_conf.worker_thread_count = 1;
	}
	if (esbcli->u_conf.worker_thread_count > 100) {
		esbcli->u_conf.worker_thread_count = 100;
	}
	esbcli->all_thrd_handles = (ESB_thread_t *)calloc(esbcli->u_conf.worker_thread_count, sizeof(ESB_thread_t));
	/** 启动若干个 msg本地队列消费 线程 */
	for (i = 0; i < esbcli->u_conf.worker_thread_count; ++i)
	{
		ret = ESB_thread_create(&esbcli->all_thrd_handles[i], NULL, (void*)&esb_localQueue_consume_thread, esbcli);
	}
	esbcli->esb_cron_thrd = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
	/** 启动 cron定时任务 线程 */
	ret = ESB_thread_create(esbcli->esb_cron_thrd, NULL, (void*)&esb_cron_thread, &esbcli->reg);

	/** 等待事件循环退出 (阻塞) */
	ret = ESB_thread_join(*esbcli->esb_dispatch_loop_thrd, NULL);
	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> Thread dispatch_loop ended smoothed]%d\n", __FUNCTION__, __LINE__, ret);

	/** 设置worker线程退出标志，关闭工作线程 */
	esbcli->Flag_ThreadExit_OnEmpty = 1;
	/** 触发条件变量，唤醒因“msg队列为空”而等待的所有worker线程 */
	ESB_thread_cond_broadcast(&esbcli->local_msgq.emp_cond);

	for (i = 0; i < esbcli->u_conf.worker_thread_count; ++i) {
		ret = ESB_thread_join(esbcli->all_thrd_handles[i], NULL);
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> Thread %d ended smoothed]%d\n", __FUNCTION__, __LINE__, i, ret);
	}
	ret = ESB_thread_join(*esbcli->esb_cron_thrd, NULL);

	/** 释放esbclient对象，及其附属对象、资源 */
	//free_esb_client(esbcli);
	return status;
}

void * esb_client_event_loop(void * arg) {
	int i, status, ret;

	//esb_set_signal_action();
	esb_set_signal_action_sigpipe();

	esb_client_t *esbcli = (esb_client_t *)arg;
	/** 开始事件循环 (阻塞) */
	status = ESB_event_base_dispatch(esbcli->esb_evbase);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_event_base_dispatch status] %d\n", __FUNCTION__, __LINE__, status);
		// error, what to do?
	} else if (status == 1) {
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: ESB_event_base_dispatch status] %d\n", __FUNCTION__, __LINE__, status);
		// no more pending or active events
	} else if (status == 0) {
		// exited normally
	}
	/** 设置worker线程退出标志，关闭工作线程 */
	esbcli->Flag_ThreadExit_OnEmpty = 1;
	/** 触发条件变量，唤醒因“msg队列为空”而等待的所有worker线程 */
	ESB_thread_cond_broadcast(&esbcli->local_msgq.emp_cond);

	ESB_mutex_lock(&esbcli->start_dispatch_mutex);
	esbcli->is_start_dispatch = 0;
	ESB_mutex_unlock(&esbcli->start_dispatch_mutex);
	esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_event_loop exit, status] %d\n", __FUNCTION__, __LINE__, status);

	return NULL;
}

int esb_client_consume_start(esb_client_t *esbcli, esb_consume_msg_cb comsume_cb, int flag) {
	char *map_key;
	int ret, status, i;
	esb_cluster_t *clu;

	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}
	esbcli->client_type = ESB_CLI_TYPE_COMSUMER;
	if (hash_size(esbcli->cli_cluster_map) <= 0 || hash_size(esbcli->cli_sbj_map) <= 0)
	{
		esb_set_error(ESB_ERR_ECLI_NOBRK);
		return ESB_ERR_ECLI_NOBRK;
	}

//	/** 初始化各种 “退出信号”处理方法 */
//	esb_set_signal_action();

	status = ESB_evthread_use_pthreads();
	if (status < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_evthread_use_pthreads status < 0]\n", __FUNCTION__, __LINE__);
		return -1;
	}

	/** 全局 event 句柄，初始化  */
	esbcli->esb_evbase = ESB_event_base_new();

	/** 初始化一定数量的 msg对象，插入空闲链表备用 */
	status = init_Local_msg_queue(esbcli, esbcli->u_conf.local_msg_queue_len);
	if (status < 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: init_Local_msg_queue status] %d\n", __FUNCTION__, __LINE__, status);
		// error, what to do?
		return -1;
	}

	/** 设置callback函数 */
	esbcli->msg_callback = comsume_cb;

	/** 启动每个cluster“集群”，以及所属的每个broker */
	hash_each(esbcli->cli_cluster_map, {
		map_key = key;
		clu = (esb_cluster_t*)val;
		/** 仅启动用于 “消费” 的集群 type=1 */
		if (clu->type != ESB_CLI_TYPE_COMSUMER)
			continue;
		status = cluster_start_each_broker(clu);
		if (status < 0)
		{
			esb_set_error(status);
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: cluster_start_each_broker,clu:%s status] %d\n", __FUNCTION__, __LINE__, map_key, status);
			// error, what to do?
			//return status;
			/**  */
			esbcli->esbcli_close_flag = 1;
		}
	});

	/** 默认启动1个worker线程，除非flag设置了“多线程”标记，则按cpu核数启动多个线程 */
	if ((ESB_ENABLE_MULTI_THREAD_CONSUME & flag) == 0)
	{
		esbcli->u_conf.worker_thread_count = 1;
	}

	esbcli->all_thrd_handles = (ESB_thread_t *)calloc(esbcli->u_conf.worker_thread_count, sizeof(ESB_thread_t));
	/** 启动若干个 msg本地队列消费 线程 */
	for (i = 0; i < esbcli->u_conf.worker_thread_count; ++i)
	{
		ESB_thread_create(&esbcli->all_thrd_handles[i], NULL, (void*)&esb_localQueue_consume_thread, esbcli);
	}

	esbcli->esb_cron_thrd = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
	/** 启动 cron定时任务 线程 */
	ESB_thread_create(esbcli->esb_cron_thrd, NULL, (void*)&esb_cron_thread, &esbcli->reg);

	/** 启动 定时任务 线程 */
//	esb_client_dispatch_start(esbcli);

	return status;
}

int esb_client_produce_init(esb_client_t *esbcli, int flag) {
	int ret, status, i;
	esb_cluster_t *clu;

	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}

	esbcli->client_type = ESB_CLI_TYPE_PRODUCER;

	status = ESB_evthread_use_pthreads();
	if (status < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_evthread_use_pthreads status < 0]\n", __FUNCTION__, __LINE__);
		return -1;
	}

	/** 全局 event 句柄，初始化  */
	esbcli->esb_evbase = ESB_event_base_new();

	esbcli->send_hd = new_esb_send_hd();

	esbcli->esb_cron_thrd = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
	/** 启动 cron定时任务 线程 */
	status = ESB_thread_create(esbcli->esb_cron_thrd, NULL, (void*)&esb_cron_thread, &esbcli->reg);
	if (status != 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_produce_init, esb_cron_thrd start failed, status] %d\n", __FUNCTION__, __LINE__, status);
		return -1;
	}

	/** 启动 异步发送 线程 */
	status = ESB_thread_create(esbcli->send_hd->async_send_thread, NULL, (void*)&asyncSend_cb, esbcli);
	if (status != 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_produce_init, async send thread start failed, status] %d\n", __FUNCTION__, __LINE__, status);
		return -1;
	}

	/** 启动 异步顺序发送 线程 */
	status = ESB_thread_create(esbcli->send_hd->async_sendq_thread, NULL, (void*)&asyncSend_queue_cb, esbcli);
	if (status != 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_produce_init, async send queue thread start failed, status] %d\n", __FUNCTION__, __LINE__, status);
		return -1;
	}

	return status;
}

int esb_add_produce_subject(esb_client_t *esbcli, int subject_id) {
	int ret, i, status = 1;
	char * clu_key;
	char *map_key;
	char *sbj_key = get_sbj_map_key_byArg(subject_id);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		ESB_mutex_lock(&esbcli->start_send_mutex);
		if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
			esb_cluster_t *clu;
			esb_subject_t *sbj;
			int client_id = 1;
			int sub_mode = -127;
			sbj = new_esb_subject(subject_id, client_id, sub_mode);

			/** 初始化订阅主题相关的“配置”、“集群”、“broker” */
			ret = find_sbj_and_init_cluster(esbcli, sbj, ESB_CLI_TYPE_PRODUCER);

			if (ret < 0) {
				/** 初始化失败，退出，报错 */
				free_esb_subject(sbj);
				free(sbj_key);
				ESB_mutex_unlock(&esbcli->start_send_mutex);
				return ret;
			}

			/** 启动每个cluster“集群”，以及所属的每个broker */
			hash_each(sbj->sbj_pro_cluster_map, {
				clu_key = (char *)key;
				clu = (esb_cluster_t *)val;
				//clu = (esb_cluster_t *)hash_get(esbcli->cli_cluster_map, clu_key);
				/** 仅启动用于 “消费” 的集群 type=1 */
				if (clu->type != ESB_CLI_TYPE_PRODUCER)
					continue;
				status = cluster_start_each_broker(clu);
				if (status < 0)
				{
					esb_set_error(status);
					esb_printf(ESB_PRINT_ERROR, "[%s,%d:: cluster_start_each_broker,clu:%s status] %d\n", __FUNCTION__, __LINE__, clu_key, status);
					free_esb_subject(sbj);
					free(sbj_key);
					ESB_mutex_unlock(&esbcli->start_send_mutex);
					// error, what to do?
					return status;
				}

			});
			hash_set(esbcli->sbj_send_info, sbj_key, sbj_key);

			/** 插入hash map */
			hash_set(esbcli->cli_sbj_map, get_sbj_map_key(sbj), sbj);
		} else {
			free(sbj_key);
		}

		ESB_mutex_unlock(&esbcli->start_send_mutex);
	} else {
		free(sbj_key);
	}

	return status;
}

int num=0;
int esb_client_dispatch_start(esb_client_t *esbcli) {
	int status;

	esbcli->esb_dispatch_loop_thrd = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
	num++;
	esb_printf(ESB_PRINT_DEBUG,"!~!~!~!~!~!~!~!~!~!创建线程数量：%d",num);
	/** 启动 事件循环 线程 */
	status = ESB_thread_create(esbcli->esb_dispatch_loop_thrd, NULL, (void*)&esb_client_event_loop, esbcli);
	if (status != 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_produce_start, dispatch loop thread start failed, status] %d\n", __FUNCTION__, __LINE__, status);
		return -1;
	}
	return 1;
}

esb_broker_t * get_broker(esb_client_t *esbcli, int subjectId) {
	char *clu_key, *clu_idx_s, *sbj_key;
	esb_subject_t *sbj = NULL;
	esb_cluster_t *clu = NULL;
	esb_broker_t *broker = NULL;
	int seq, idx, clu_idx;

	sbj_key = get_sbj_map_key_byArg(subjectId);

	sbj = hash_get(esbcli->cli_sbj_map, sbj_key);
	if (sbj == NULL || sbj->cluster_count <= 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: getBroker:: subject illegal : %d]\n", __FUNCTION__, __LINE__, subjectId);
		free(sbj_key);
		return NULL;
	}

	clu_idx_s = (char*)calloc(1, 32);
	ESB_mutex_lock(&sbj->clu_mutex);
	if (sbj->cluster_count == 1) {
		memset(clu_idx_s, 0, 32);
		sprintf(clu_idx_s, "0");
		if (hash_has(sbj->sbj_clu_idx_map, clu_idx_s)) {
			clu_key = (char*)hash_get(sbj->sbj_clu_idx_map, clu_idx_s);
			//clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key);
			clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
		}
		if (clu != NULL) {
			// seq = getNextSendSeq(esbcli->send_hd);
			broker = get_send_broker(clu, 1);
		}
	} else {
		seq = getNextSendSeq(esbcli->send_hd);
		clu_idx = seq % (sbj->cluster_count);
		idx = clu_idx;
		memset(clu_idx_s, 0, 32);
		sprintf(clu_idx_s, "%d", idx);
		if (hash_has(sbj->sbj_clu_idx_map, clu_idx_s)) {
			clu_key = hash_get(sbj->sbj_clu_idx_map, clu_idx_s);
			//clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key);
			clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
		}
		if (clu != NULL) {
			broker = get_send_broker(clu, 1);
		}
		if (broker == NULL || broker->state != NORMAL || UNWRITABLE == broker->writable) {
			idx = (clu_idx + 1) % (sbj->cluster_count);
			while (idx != clu_idx) {
				if (idx > (sbj->cluster_count - 1)) {
					idx = 0;
				}

				memset(clu_idx_s, 0, 32);
				sprintf(clu_idx_s, "%d", idx);
				if (hash_has(sbj->sbj_clu_idx_map, clu_idx_s)) {
					clu_key = hash_get(sbj->sbj_clu_idx_map, clu_idx_s);
					//clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key);
					clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
				}
				if (clu != NULL) {
					broker = get_send_broker(clu, 1);
					if (broker != NULL && broker->state == NORMAL && WRITABLE == broker->writable) {
						break;
					}
				}
				idx = (idx + 1) % sbj->cluster_count;
			}
		}
	}

	if (broker != NULL && (NORMAL != broker->state || UNWRITABLE == broker->writable)) {
		broker = NULL;
	}

	if (broker != NULL) {
		broker->closable = UNCLOSABLE;
	}
	ESB_mutex_unlock(&sbj->clu_mutex);
	free(sbj_key);
	free(clu_idx_s);

	return broker;
}

esb_broker_t * get_broker_with_seq(esb_client_t *esbcli, int subjectId, int seq) {
	char *clu_key, *clu_idx_s, *sbj_key;
	esb_subject_t *sbj = NULL;
	esb_cluster_t *clu = NULL;
	esb_broker_t *broker = NULL;
	int idx, clu_idx;

	sbj_key = get_sbj_map_key_byArg(subjectId);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		esb_add_produce_subject(esbcli, subjectId);
	}

	sbj = hash_get(esbcli->cli_sbj_map, sbj_key);
	if (sbj == NULL || sbj->cluster_count <= 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: getBroker:: subject illegal : %d]\n", __FUNCTION__, __LINE__, subjectId);
		free(sbj_key);
		return NULL;
	}

	clu_idx_s = (char*)calloc(1, 32);
	ESB_mutex_lock(&sbj->clu_mutex);
	if (sbj->cluster_count == 1) {
		memset(clu_idx_s, 0, 32);
		sprintf(clu_idx_s, "0");
		if (hash_has(sbj->sbj_clu_idx_map, clu_idx_s)) {
			clu_key = (char*)hash_get(sbj->sbj_clu_idx_map, clu_idx_s);
			//clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key);
			clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
		}
		if (clu != NULL) {
			broker = get_send_broker_with_seq(clu, seq, 1);
		}
	} else {
		clu_idx = seq % (sbj->cluster_count);
		idx = clu_idx;
		memset(clu_idx_s, 0, 32);
		sprintf(clu_idx_s, "%d", idx);
		if (hash_has(sbj->sbj_clu_idx_map, clu_idx_s)) {
			clu_key = hash_get(sbj->sbj_clu_idx_map, clu_idx_s);
			//clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key);
			clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
		}

		if (clu != NULL) {
			broker = get_send_broker_with_seq(clu, seq, 1);
		}
		if (broker == NULL || broker->state != NORMAL || UNWRITABLE == broker->writable) {
			idx = (clu_idx + 1) % (sbj->cluster_count);
			while (idx != clu_idx) {
				if (idx > (sbj->cluster_count - 1)) {
					idx = 0;
				}

				memset(clu_idx_s, 0, 32);
				sprintf(clu_idx_s, "%d", idx);
				if (hash_has(sbj->sbj_clu_idx_map, clu_idx_s)) {
					clu_key = hash_get(sbj->sbj_clu_idx_map, clu_idx_s);
					//clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key);
					clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
				}
				if (clu != NULL) {
					broker = get_send_broker_with_seq(clu, seq, 1);
					if (broker != NULL && broker->state == NORMAL && WRITABLE == broker->writable) {
						break;
					}
				}
				idx = (idx + 1) % sbj->cluster_count;
			}
		}
	}

	if (broker != NULL && (NORMAL != broker->state || UNWRITABLE == broker->writable)) {
		broker = NULL;
	}

	if (broker != NULL) {
		broker->closable = UNCLOSABLE;
	}

	ESB_mutex_unlock(&sbj->clu_mutex);
	free(sbj_key);
	free(clu_idx_s);
	return broker;
}

esb_broker_t * get_sole_broker(esb_client_t *esbcli, int subjectId) {
	char *clu_key, *sbj_key;
	esb_subject_t *sbj = NULL;
	esb_cluster_t *clu = NULL;
	esb_broker_t *broker = NULL;
	int seq, idx, clu_idx;

	sbj_key = get_sbj_map_key_byArg(subjectId);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		esb_add_produce_subject(esbcli, subjectId);
	}

	sbj = hash_get(esbcli->cli_sbj_map, sbj_key);
	if (sbj == NULL || sbj->cluster_count <= 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: getBroker:: subject illegal : %d]\n", __FUNCTION__, __LINE__, subjectId);
		free(sbj_key);
		return NULL;
	}
	ESB_mutex_lock(&sbj->clu_mutex);
	clu_key = sbj->current_cluster_key;
	if (clu_key != NULL) {
		//clu = hash_get(esbcli->cli_cluster_map, clu_key);
		clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
		broker = get_send_sole_broker(clu);
	}

	if (broker == NULL || NORMAL != broker->state || UNWRITABLE == broker->writable) {
		if (sbj->cluster_count >= 1) {
			hash_each(sbj->sbj_cluster_map, {
				clu_key = (char*)val;
				//clu = (esb_cluster_t *)hash_get(esbcli->cli_cluster_map, clu_key);
				clu = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, clu_key);
				broker = get_send_sole_broker(clu);
				if (broker != NULL && NORMAL == broker->state && WRITABLE == broker->writable) {
					sbj->current_cluster_key = clu_key;
					break;
				}
			});
		}
	}

	if (broker != NULL && (NORMAL != broker->state || UNWRITABLE == broker->writable)) {
		broker = NULL;
	}

	if (broker != NULL) {
		broker->closable = UNCLOSABLE;
	}

	ESB_mutex_unlock(&sbj->clu_mutex);
	free(sbj_key);
	return broker;
}

void * asyncSend_cb(void * args) {
	esb_client_t *esbcli = (esb_client_t *) args;
	int subjectID;
	esb_send_hd_t* send_hd;
	send_hd = esbcli->send_hd;
	esb_broker_t *brk;
	int ret = SEND_SUCCESS;

	while (1) {
		if (GlobleExitFlag == 1 || esbcli->esbcli_close_flag == 1) {
			break;
		}

		if (esbcli->esbcli_send_close_flag == 1 && send_hd->send_list_size == 0 && send_hd->sendq_list_size == 0) {
			esbcli->esbcli_send_close_flag = 2;
			break;
		}

		ESB_mutex_lock(&send_hd->send_mutex);

		if (TAILQ_EMPTY(&send_hd->send_op_list)) {
			ESB_mutex_unlock(&send_hd->send_mutex);
			usleep(10 * 1000);
			continue;
		}
//		while(TAILQ_EMPTY(&send_hd->send_op_list)) {
//			ESB_thread_cond_wait(&send_hd->send_cond, &send_hd->send_mutex);
//		}
		esb_send_op_t * send_op = TAILQ_FIRST(&send_hd->send_op_list);
		TAILQ_REMOVE(&send_hd->send_op_list, send_op, send_msg_link);
		send_hd->send_list_size--;
		ESB_mutex_unlock(&send_hd->send_mutex);

		if (send_op != NULL) {
			esb_msg_t * msg_t = send_op->msg;
			if (msg_t != NULL) {
				subjectID = send_op->msg->subject;
			} else {
				if (send_op->send_cb != NULL) {
					ret = SEND_FAILED;
					send_op->send_cb(send_op->msg, &ret, esbcli->cb_ext_arg);
				}
				free_send_op_tolist(esbcli, send_op);
				continue;
			}

			if (msg_t->sequence_id == -1) {
				brk = get_broker(esbcli, subjectID);
			} else {
				brk = get_broker_with_seq(esbcli, subjectID, msg_t->sequence_id);
			}

			if (brk == NULL) {
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: asyncSend_callback:: get broker is null  : %d]\n", __FUNCTION__, __LINE__, subjectID);
				if (send_op->send_cb != NULL) {
					ret = SEND_FAILED;
					send_op->send_cb(send_op->msg, &ret, esbcli->cb_ext_arg);
				}
				free_send_op_tolist(esbcli, send_op);
				continue;
			}

			esb_printf(ESB_PRINT_DEBUG, "[%s,%d:: asyncSend_callback:: getBroker : %s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);

			if (asyncSendMsg(brk, send_op) < 0) {
				if (send_op->send_cb != NULL) {
					ret = SEND_FAILED;
					send_op->send_cb(send_op->msg, &ret, esbcli->cb_ext_arg);
				}
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: asyncSend_callback:: send msg failed  : %d]\n", __FUNCTION__, __LINE__, subjectID);
			}
			brk->closable = CLOSABLE;

			if (send_op->send_cb != NULL) {
				ret = SEND_SUCCESS;
				send_op->send_cb(send_op->msg, &ret, esbcli->cb_ext_arg);
			}
			free_send_op_tolist(esbcli, send_op);
		}
	}
	return NULL;
}

void * asyncSend_queue_cb(void * args) {
	esb_client_t *esbcli = (esb_client_t *) args;
	int subjectID;
	esb_send_hd_t* send_hd;
	send_hd = esbcli->send_hd;
	int ret = SEND_SUCCESS;

	while (1) {
		if (GlobleExitFlag == 1 || esbcli->esbcli_close_flag == 1) {
			break;
		}

		if (esbcli->esbcli_send_close_flag == 1 && send_hd->send_list_size == 0 && send_hd->sendq_list_size == 0) {
			esbcli->esbcli_send_close_flag = 2;
			break;
		}

		ESB_mutex_lock(&send_hd->sendq_mutex);
		if (TAILQ_EMPTY(&send_hd->sendq_op_list)) {
			ESB_mutex_unlock(&send_hd->sendq_mutex);
			usleep(10 * 1000);
			continue;
		}
//		while (TAILQ_EMPTY(&send_hd->sendq_op_list)) {
//			ESB_thread_cond_wait(&send_hd->sendq_cond, &send_hd->sendq_mutex);
//		}

		esb_send_op_t * sendq_op = TAILQ_FIRST(&send_hd->sendq_op_list);
		TAILQ_REMOVE(&send_hd->sendq_op_list, sendq_op, send_msg_link);
		send_hd->sendq_list_size--;
		ESB_mutex_unlock(&send_hd->sendq_mutex);

		if (sendq_op != NULL) {
			esb_msg_t * msg_t = sendq_op->msg;
			if (msg_t != NULL) {
				subjectID = sendq_op->msg->subject;
			} else {
				if (sendq_op->send_cb != NULL) {
					ret = SEND_FAILED;
					sendq_op->send_cb(sendq_op->msg, &ret, esbcli->cb_ext_arg);
				}
				free_send_op_tolist(esbcli, sendq_op);
				continue;
			}
			esb_broker_t *brk = get_sole_broker(esbcli, subjectID);
			if (brk == NULL) {
				//回调完成
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: asyncSend_queue_callback:: get broker is null  : %d]\n", __FUNCTION__, __LINE__, subjectID);
				if (sendq_op->send_cb != NULL) {
					ret = SEND_FAILED;
					sendq_op->send_cb(sendq_op->msg, &ret, esbcli->cb_ext_arg);
				}
				free_send_op_tolist(esbcli, sendq_op);
				continue;
			}
			if (asyncSendMsg(brk, sendq_op) < 0) {
				if (sendq_op->send_cb != NULL) {
					ret = SEND_FAILED;
					sendq_op->send_cb(sendq_op->msg, &ret, esbcli->cb_ext_arg);
				}
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: asyncSend_queue_callback:: get broker is null  : %d]\n", __FUNCTION__, __LINE__, subjectID);
			}
			brk->closable = CLOSABLE;
			if (sendq_op->send_cb != NULL) {
				ret = SEND_SUCCESS;
				sendq_op->send_cb(sendq_op->msg, &ret, esbcli->cb_ext_arg);
			}
			free_send_op_tolist(esbcli, sendq_op);
		}
	}
	return NULL;
}

void esb_client_asyncSend(esb_client_t *esbcli, esb_msg_t *msg) {
	esb_client_asyncSend_with_cb(esbcli, msg, NULL);
}

void esb_client_asyncSend_with_cb(esb_client_t *esbcli, esb_msg_t *msg, esb_send_msg_cb send_cb) {
	int status, ret;
	char *sbj_key;
	esb_send_op_t* send_op;
	esb_send_hd_t* send_hd;

	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return;
	}
	//send_op = (esb_send_op_t *)calloc(1, sizeof(esb_send_op_t));
	send_op = get_free_sendop(esbcli->send_hd);
	send_op->msg = msg;
	send_op->send_cb = send_cb;

	if (esbcli->esbcli_send_close_flag == 1) {
		ret = SEND_FAILED;
		if (send_cb != NULL) {
			send_cb(msg, &ret, esbcli->cb_ext_arg);
		}
		free_send_op_tolist(esbcli, send_op);
		return;
	}

	int subjectId = msg->subject;
	sbj_key = get_sbj_map_key_byArg(subjectId);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		status = esb_add_produce_subject(esbcli, subjectId);
		if (status < 0 ) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_asyncSend_with_cb:: esb_add_produce_subject failed : %d]\n", __FUNCTION__, __LINE__, subjectId);
		}
	}

	send_hd = esbcli->send_hd;
	ESB_mutex_lock(&send_hd->send_mutex);
	if (&send_hd->send_op_list != NULL) {
		if (send_hd->send_list_size > 100000) {
			esb_send_op_t * sendOp = TAILQ_FIRST(&send_hd->send_op_list);
			TAILQ_REMOVE(&send_hd->send_op_list, sendOp, send_msg_link);
			send_hd->send_list_size--;
			if (sendOp->send_cb != NULL) {
				ret = SEND_FAILED;
				sendOp->send_cb(sendOp->msg, &ret, esbcli->cb_ext_arg);
			}
			free_send_op_tolist(esbcli, sendOp);
		}
		/** 插入send msg链表 */
		TAILQ_INSERT_TAIL(&send_hd->send_op_list, send_op, send_msg_link);
		send_hd->send_list_size++;
		ESB_thread_cond_signal(&send_hd->send_cond);
		if ((send_hd->send_list_size > 0) && (send_hd->send_list_size % 4096 == 0)) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_asyncSend_with_cb:: send_list_size  : %d]\n", __FUNCTION__, __LINE__, send_hd->send_list_size);
		}
	}
	ESB_mutex_unlock(&send_hd->send_mutex);
	free(sbj_key);
}

int esb_client_syncSend_with_tm(esb_client_t *esbcli, esb_msg_t *msg, int timeout) {
	int i = 0, status, flag = 0;
	char *sbj_key;
	esb_send_op_t *send_op;
	esb_broker_t *broker;

	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}
	//send_op = (esb_send_op_t *)calloc(1, sizeof(esb_send_op_t));
	send_op = get_free_sendop(esbcli->send_hd);

	msg->command_type = 0;
	msg->need_replay = 1;
	send_op->msg = msg;
	send_op->send_cb = NULL;
	send_op->timeout = timeout;

	int subjectId = msg->subject;
	sbj_key = get_sbj_map_key_byArg(subjectId);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		status = esb_add_produce_subject(esbcli, subjectId);
		if (status < 0 ) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_syncSend_with_tm:: esb_add_produce_subject failed : %d]\n", __FUNCTION__, __LINE__, subjectId);
		}
	}

	if (msg->sequence_id == -1) {
		broker = get_broker(esbcli, subjectId);
	} else {
		broker = get_broker_with_seq(esbcli, subjectId, msg->sequence_id);
	}

	if ( NULL == broker) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_syncSend:: get broker is null  : %d]\n", __FUNCTION__, __LINE__, subjectId);
		free_send_op_tolist(esbcli, send_op);
		free(sbj_key);
		return -1;
	}
	status = syncSendMsg(broker, send_op);
	broker->closable = CLOSABLE;
	free_send_op_tolist(esbcli, send_op);
	free(sbj_key);
	if (status == STATUS_PUT_OK) {
		return SEND_SUCCESS;
	}
	return SEND_FAILED;
}

int esb_client_syncSend(esb_client_t *esbcli, esb_msg_t *msg) {
	return esb_client_syncSend_with_tm(esbcli, msg, ESB_DEFAULT_TIMEOUT);
}

void esb_client_asyncSend_queue(esb_client_t *esbcli, esb_msg_t *msg) {
	esb_client_asyncSend_queue_with_cb(esbcli, msg, NULL);
	return;
}

void esb_client_asyncSend_queue_with_cb(esb_client_t *esbcli, esb_msg_t *msg, esb_send_msg_cb send_cb) {
	int status, ret;
	esb_send_op_t* sendq_op;
	esb_send_hd_t* send_hd;
	char *sbj_key;
	//sendq_op = (esb_send_op_t *)calloc(1, sizeof(esb_send_op_t));
	sendq_op = get_free_sendop(esbcli->send_hd);

	sendq_op->msg = msg;
	sendq_op->send_cb = send_cb;

	if (esbcli->esbcli_send_close_flag == 1) {
		ret = SEND_FAILED;
		if (send_cb != NULL) {
			send_cb(msg, &ret, esbcli->cb_ext_arg);
		}
		free_send_op_tolist(esbcli, sendq_op);
		return;
	}

	int subjectId = msg->subject;
	sbj_key = get_sbj_map_key_byArg(subjectId);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		status = esb_add_produce_subject(esbcli, subjectId);
		if (status < 0 ) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_asyncSend_queue_with_cb:: esb_add_produce_subject failed : %d]\n", __FUNCTION__, __LINE__, subjectId);
		}
	}

	send_hd = esbcli->send_hd;
	ESB_mutex_lock(&send_hd->sendq_mutex);
	if (&send_hd->sendq_op_list != NULL) {
		if (send_hd->sendq_list_size > 100000) {
			esb_send_op_t * sendOp = TAILQ_FIRST(&send_hd->sendq_op_list);
			TAILQ_REMOVE(&send_hd->sendq_op_list, sendOp, send_msg_link);
			send_hd->sendq_list_size--;
			if (sendOp->send_cb != NULL) {
				ret = SEND_FAILED;
				sendOp->send_cb(sendOp->msg, &ret, esbcli->cb_ext_arg);
			}
			free_send_op_tolist(esbcli, sendOp);
		}
		/** 插入send msg链表 */
		TAILQ_INSERT_TAIL(&send_hd->sendq_op_list, sendq_op, send_msg_link);
		send_hd->sendq_list_size++;
		ESB_thread_cond_signal(&send_hd->sendq_cond);
		if ((send_hd->sendq_list_size > 0) && (send_hd->sendq_list_size % 4096 == 0)) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_asyncSend_queue_with_cb:: sendq_list_size  : %d]\n", __FUNCTION__, __LINE__, send_hd->sendq_list_size);
		}
	}
	ESB_mutex_unlock(&send_hd->sendq_mutex);
	free(sbj_key);
}

int esb_client_syncSendQueue_with_tm(esb_client_t *esbcli, esb_msg_t *msg, int timeout) {
	int i = 0, status, flag = 0;
	char *sbj_key;
	esb_send_op_t *send_op;
	//send_op = (esb_send_op_t *)calloc(1, sizeof(esb_send_op_t));
	send_op = get_free_sendop(esbcli->send_hd);
	msg->need_replay = 1;
	send_op->msg = msg;
	send_op->send_cb = NULL;
	send_op->timeout = timeout;

	int subjectId = msg->subject;
	sbj_key = get_sbj_map_key_byArg(subjectId);
	if (!hash_has(esbcli->sbj_send_info, sbj_key)) {
		status = esb_add_produce_subject(esbcli, subjectId);
		if (status < 0 ) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_syncSend_with_tm:: esb_add_produce_subject failed : %d]\n", __FUNCTION__, __LINE__, subjectId);
		}
	}
	esb_broker_t *brk = get_sole_broker(esbcli, subjectId);

	if ( NULL == brk) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_syncSend:: get broker is null  : %d]\n", __FUNCTION__, __LINE__, subjectId);
		free_send_op_tolist(esbcli, send_op);
		return -1;
	}
	status = syncSendMsg(brk, send_op);
	brk->closable = CLOSABLE;
	free_send_op_tolist(esbcli, send_op);
	free(sbj_key);
	if (status == STATUS_PUT_OK) {
		return SEND_SUCCESS;
	}

	return SEND_FAILED;
}

int esb_client_syncSendQueue(esb_client_t *esbcli, esb_msg_t *msg) {
	return esb_client_syncSendQueue_with_tm(esbcli, msg, ESB_DEFAULT_TIMEOUT);
}

int commitMsgWithReconsume(esb_msg_t *msg,DelayLevel delayTimeLevel){
	if(msg->qid==-1){
		//说明是推模式
		return ESB_ERR_CMTOFSET_ILLEGEL;
	}
	esb_broker_t *broker = msg->queue->broker;
	esb_client_t *esbcli = (esb_client_t*)(broker->esbcli);
	uint32_t clientID = esbcli->sbj->client_id;
	msg->client_id = clientID;

	if (msg->pull_version >= msg->queue->max_pull_version) {
		msg->queue->consume_offset = msg->logic_offset + 1;
		return esb_client_reConsumeByCustomDelay(msg,delayTimeLevel);
	} else {
		//zsj未完成：考虑优化 不new空间
		char *msg_body = (char*)malloc(msg->payload_len + 1);
		msg_body[msg->payload_len] = '\0';
		memcpy(msg_body, msg->em_payload, msg->payload_len);
		esb_printf(ESB_PRINT_DEBUG,"msg pullVersion is old, so abondon the commit offset request, msg: %s \n",msg_body);
		free(msg_body);
		return ESB_ERR_CMTOFFSET_UNVALIABLE;
	}
}

int commitConsumeOffset(esb_msg_t *msg) {

	if(msg->qid==-1){
		//说明是推模式
		return ESB_ERR_CMTOFSET_ILLEGEL;
	}
	if (msg->pull_version >= msg->queue->max_pull_version) {
		msg->queue->consume_offset = msg->logic_offset + 1;
	} else {
		//zsj未完成：考虑优化 不new空间
		char *msg_body = (char*) malloc(msg->payload_len + 1);
		msg_body[msg->payload_len] = '\0';
		memcpy(msg_body, msg->em_payload, msg->payload_len);
		esb_printf(ESB_PRINT_DEBUG,
				"msg pullVersion is old, so abondon the commit offset request, msg: %s \n",
				msg_body);
		free(msg_body);
		return ESB_ERR_CMTOFFSET_UNVALIABLE;
	}
	return ESB_ERR_CMTOFSET_SUCCESS;
}

int esb_client_reConsume(esb_msg_t *msg) {
	return esb_client_reConsumeByCustomDelay(msg, 0);
}

int esb_client_reConsumeByCustomDelay(esb_msg_t *msg,DelayLevel delayTimeLevel) {
	esb_broker_t *broker = msg->queue->broker;
	esb_client_t *esbcli = (esb_client_t*)(broker->esbcli);

	if(esbcli->send_hd==NULL){
		esbcli->send_hd = new_esb_send_hd();
//		esb_client_produce_init(esbcli,1);
	}
	int reConsumeTimes = msg->reConsume_times;
	if (reConsumeTimes >= MAX_RECONSUME_TIMES) {
		//zsj未完成：考虑优化 不new空间
		char *msg_body = (char*)malloc(msg->payload_len + 1);
		msg_body[msg->payload_len] = '\0';
		memcpy(msg_body, msg->em_payload, msg->payload_len);
		esb_printf(ESB_PRINT_WARNING, "reConsumeTime %d is too max  %d, abondoned, msg : %s \n",reConsumeTimes,MAX_RECONSUME_TIMES,msg_body);
		free(msg_body);
		return ESB_ERR_RECSM_MAXTIME;
	}  else {
		reConsumeTimes++;
		msg->reConsume_times = (uint8_t) (reConsumeTimes);

		if (delayTimeLevel == 0) {
			setDelayLevel(msg,msg->reConsume_times);
		} else {
			setDelayLevel_enum(msg,delayTimeLevel);
		}

		/*		char* msg_body = (char *) calloc(1, msg->payload_len);
		memcpy(msg_body, msg->em_payload, msg->payload_len);
		//msg_body 在new_msg中会被释放
		esb_msg_t* msg_temp = new_msg(esbcli, msg->subject,msg_body, strlen(msg_body),NULL, 0);
		if (delayTimeLevel == 0) {
			setDelayLevel(msg_temp,msg->reConsume_times);
		} else {
			setDelayLevel_enum(msg_temp,delayTimeLevel);
		}
		//代表消息重试
		msg_temp->queue = msg->queue;
		msg_temp->command_type = MSG_CMD_TYPE_RECONSUME;
		msg_temp->client_id = msg->client_id;
		msg_temp->reConsume_times = msg->reConsume_times;
		msg_temp->message_id = msg->message_id;*/

		int res = esb_client_reConsume_sendBack(esbcli,msg);
		/**
		 * zsj未完成：这里进行了msg回收，建议考虑是否直接释放，或者在上面的代码中取消new_msg，复用sebcli的free_msg
		 */
//		free_esb_msg_tolist(esbcli,msg_temp);
		return res;
	}
}


/**
 * 重试消费接口专用，非生产者发送流程
 */
int esb_client_reConsume_sendBack(esb_client_t *esbcli, esb_msg_t *msg){

	esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: esb_client_reConsume_sendBack]\n", __FUNCTION__, __LINE__);

	if(msg==NULL||msg->queue==NULL||(esb_broker_t*)msg->queue->broker==NULL){
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESBMSG reConsume failed, error: nullptr exception]\n", __FUNCTION__, __LINE__);
		return 0;
	}
	esb_broker_t* brk=(esb_broker_t*)msg->queue->broker;

	int status;
	struct timeval tv;
	esb_string_t *sendBytes;
	gettimeofday(&tv, NULL);
	//表示需要回复，魔数需要改，1代表master_receive_ok，先置为0，表示不进行存根
	msg->need_replay =0;
	sendBytes = esb_msg_toBytes(msg);
//	free_esb_msg(msg);

	if (ESB_bufferevent_get_outputbuf_length(brk->bev) > ESB_BRK_WRITE_HIGH_WATER) {
		setBrkUnwritable(brk);
	}
	status = ESB_bufferevent_write(brk->bev, sendBytes->str, sendBytes->len);
	free_esb_string_t(sendBytes);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_write failed, error: %s]\n", __FUNCTION__, __LINE__, strerror(errno));
//		连接探测处理
		brokerStateCheck(brk);
		return ESB_ERR_RECSM_FAILED;
	}
	return ESB_ERR_RECSM_SUCCESS;
}
void esb_client_close_callback(esb_client_t *esbcli) {
	int tt = 0;

	if (esbcli == NULL) {
		return;
	}

	int ret, i;
	if (esbcli->client_type == ESB_CLI_TYPE_PRODUCER) {
		esbcli->esbcli_send_close_flag = 1;
		/** 发送队列剩余消息发送等待*/
		while (esbcli->esbcli_send_close_flag == 1 && tt < 5) {
			sleep(1);
			tt++;
			continue;
		}
	}

	esbcli->esbcli_close_flag = 1;
	if (esbcli->esb_dispatch_loop_thrd != NULL) {
		ret = ESB_thread_join(*esbcli->esb_dispatch_loop_thrd, NULL);
		esb_printf(ESB_PRINT_DEBUG, "[Thread esb_dispatch_loop_thrd ended exit smoothed]\n");
	}
	
	if (esbcli->client_type == ESB_CLI_TYPE_COMSUMER) {
		/** 设置worker线程退出标志，关闭工作线程 */
		esbcli->Flag_ThreadExit_OnEmpty = 1;
		/** 触发条件变量，唤醒因“msg队列为空”而等待的所有worker线程 */
		ESB_thread_cond_broadcast(&esbcli->local_msgq.emp_cond);

		for (i = 0; i < esbcli->u_conf.worker_thread_count; ++i) {
			ret = ESB_thread_join(esbcli->all_thrd_handles[i], NULL);
			esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> Thread %d ended smoothed]\n", __FUNCTION__, __LINE__, i);
		}
	} else if (esbcli->client_type == ESB_CLI_TYPE_PRODUCER) {
		ret = ESB_thread_join(*(esbcli->send_hd->async_send_thread), NULL);
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> async_send_thread ended smoothed]\n", __FUNCTION__, __LINE__);
		ret = ESB_thread_join(*(esbcli->send_hd->async_sendq_thread), NULL);
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> async_sendq_thread ended smoothed]\n", __FUNCTION__, __LINE__);
	}

	ret = ESB_thread_join(*(esbcli->esb_cron_thrd), NULL);
	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> esb_cron_thrd ended smoothed]\n", __FUNCTION__, __LINE__);
	esb_client_destroy(esbcli);
	esbcli = NULL;
	esb_printf(ESB_PRINT_DEBUG, "[client exit smoothed]\n");
}
