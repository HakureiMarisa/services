/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include "esbclient.h"
#include "esbcli_crontab.h"
#include "esbcli_cluster.h"
#include "esbcli_broker.h"
#include "esbcli_registry.h"
#include "esbcli_thread.h"
#include "esbcli_util.h"
#include "hash.h"

void cleanUp_closing_broker(esb_client_t *esbcli);
void update_cluster_from_conf(esb_client_t *esbcli);
void update_sbj_and_cluster_consume(esb_client_t *esbcli, esb_subject_t *sbj, int cliType);
void update_cluster_and_broker_consume(esb_client_t *esbcli, esb_cluster_t *clu, int cliType);
void update_sbj_and_cluster_produce(esb_client_t *esbcli, esb_subject_t *sbj, int cliType);
void update_cluster_and_broker_produce(esb_client_t *esbcli, esb_cluster_t *clu, int cliType);
void reduce_single_broker(esb_broker_t *brk);
void close_broker_when_shutdown(esb_client_t *esbcli);
void check_brokers_request_timeout(esb_client_t *esbcli);
void check_worker_thread_alive(esb_client_t *esbcli);
void commitOffsetAll(esb_client_t *esbcli);

/**
 * [esb_cron_thread description]
 * @param arg [description]
 */
void esb_cron_thread(void * arg) {
	esb_client_t *esbcli;
	int ret;
	uint64_t tick_count = 0;

	esbcli = (esb_client_t*)arg;

	//esb_set_signal_action();
	esb_set_signal_action_sigpipe();

	while (1) {
		/** 周期循环，每秒一个节拍, 用于支持多个定时任务 */
		/** 下面的每个定时任务，各自计算节拍 (tick_count % n) */
		sleep(1);
		tick_count += 1;
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> local_msgq_free.cnt: %d    local_msgq.cnt: %d\n", __FUNCTION__, __LINE__, esbcli->local_msgq_free.cnt, esbcli->local_msgq.cnt);
		/** 每30分钟，打印一次本地内存队列的消息量，notice级别 */

		if ( tick_count>=1 ){
			commitOffsetAll(esbcli);
		}

		if ( (tick_count % 1800) == 1 )
                {
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> local_msgq_free.cnt: %d    local_msgq.cnt: %d\n", __FUNCTION__, __LINE__, esbcli->local_msgq_free.cnt, esbcli->local_msgq.cnt);
		}

		/** 清理已经关闭的broker */
		cleanUp_closing_broker(esbcli);

		/** 在准备关闭cli对象时，关闭每个cluster的每个broker对象 */
		close_broker_when_shutdown(esbcli);

		/** 每60秒，更新registry配置，并按需执行 “扩容” “缩容” */
		if ( (tick_count % 60) == 0 )
		{
			ret = registryGetBrokerConf(&esbcli->reg);
			if (ret < 0)
			{
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registryGetBrokerConf failed]%d\n", __FUNCTION__, __LINE__, ret);
			} else {
				/** 查询匹配所有 集群、主题、broker 是否需要扩容、缩容，并执行 */
				update_cluster_from_conf(esbcli);
				/** 更新store权重*/
				esb_client_set_store_conf(esbcli);
			}
		}

		/** 每小时（3600sec），检查worker线程是否存活 */
		if ( (tick_count % 3600) == 0 )
		{
			check_worker_thread_alive(esbcli);
		}

		/** 每小时（3600sec），上报client版本 */
		if ( (tick_count % 3600) == 1 )
		{
			registryReportVersion(&esbcli->reg);
		}

		/** 每秒，检查一遍所有broker的所有stub记录的请求是否超时 */
		check_brokers_request_timeout(esbcli);
	}
}


/**
 * [提交所有主题的offset]
 * @param esbcli [description]
 */
void  commitOffsetAll(esb_client_t *esbcli){

}

/**
 * [update_cluster_from_conf description]
 * @param esbcli [description]
 */
void update_cluster_from_conf(esb_client_t *esbcli) {
	esb_subject_t *sbj;
	esb_cluster_t *clu;
	int ret;

	/** 仅处理“消费者”扩容缩容 type=COMSUMER */
	if (esbcli->client_type == ESB_CLI_TYPE_COMSUMER) {

		hash_each(esbcli->cli_sbj_map , {
			sbj = (esb_subject_t*)val;
			/** 更新订阅主题相关的“配置”、“集群”、“broker” */
			update_sbj_and_cluster_consume(esbcli, sbj, ESB_CLI_TYPE_COMSUMER);
		});

		hash_each(esbcli->cli_cluster_map, {
			clu = (esb_cluster_t*)val;
			/** 更新每个“集群”下属的“broker” */
			update_cluster_and_broker_consume(esbcli, clu, ESB_CLI_TYPE_COMSUMER);
			/** 启动所有init状态的broker */
			cluster_start_each_broker(clu);
		});

	} else if (esbcli->client_type == ESB_CLI_TYPE_PRODUCER) {
		hash_each(esbcli->cli_sbj_map , {
			sbj = (esb_subject_t*)val;
			/** 更新订阅主题相关的“配置”、“集群”、“broker” */
			update_sbj_and_cluster_produce(esbcli, sbj, ESB_CLI_TYPE_PRODUCER);
		});

		hash_each(esbcli->cli_sbj_map, {
			sbj = (esb_subject_t *)val;
			hash_each(sbj->sbj_pro_cluster_map, {
				//cluster = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, key);
				clu = (esb_cluster_t*)val;
				update_cluster_and_broker_produce(esbcli, clu, ESB_CLI_TYPE_PRODUCER);
				/** 启动所有init状态的broker */
				cluster_start_each_broker(clu);
			});
		});
	}

}

/**
 * [update_sbj_and_cluster description]
 * @param esbcli  [description]
 * @param sbj     [description]
 * @param cliType [description]
 */
void update_sbj_and_cluster_consume(esb_client_t *esbcli, esb_subject_t *sbj, int cliType) {
	int i, j, ret, found;
	long cluster_id;
	esb_cluster_t *cluster;
	regConf_json_t *regConf_obj;
	SubjectConf_json_t *sbjConf;
	char *cluster_key;

	regConf_obj = esbcli->reg.reg_conf_obj;

	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> update_sbj_and_cluster sbj:%u]\n", __FUNCTION__, __LINE__, sbj->subject_id);

	for (i = 0; i < regConf_obj->sbj_array_cnt; ++i)
	{
		sbjConf = &regConf_obj->sbjConf_array[i];
		/** 匹配 主题id、clientid、type */
		if (sbjConf->name == sbj->subject_id && sbjConf->type == cliType &&
		        sbjConf->clientId == sbj->client_id) {
			break;
		}
	}

	for (j = 0; j < sbjConf->clu_cnt; ++j) {
		cluster_id = sbjConf->clusters[j];
		cluster_key = (char*)calloc(1, 32);
		sprintf(cluster_key, "%ld", cluster_id);

		ret = hash_has(sbj->sbj_cluster_map, cluster_key);
		/**  */
		if (ret == 1) {
			free(cluster_key);
			continue;
		}
		/** 主题扩容 */
		cluster = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, cluster_key);
		if (cluster == NULL || cluster->state == CLU_INIT)
		{
			/** 集群尚不存在或处于init状态，尝试新建对象及配置 */
			check_init_cluster(cluster_id, esbcli, sbj, cliType);
		} else {
			esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> crontab cluster_sub_single_sbj clu:%ld sbj:%u]\n", __FUNCTION__, __LINE__, cluster->hash_code, sbj->subject_id);
			/** 集群已经处于normal运行状态，发起订阅主题 */
			cluster_sub_single_sbj(cluster, sbj);
		}
		free(cluster_key);
	}

	hash_each(sbj->sbj_cluster_map, {
		cluster = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, key);
		found = 0;
		for (j = 0; j < sbjConf->clu_cnt; ++j) {
			cluster_id = sbjConf->clusters[j];
			if (cluster_id == cluster->hash_code) {
				found = 1;
				break;
			}
		}
		/** 主题缩容 */
		if (found == 0) {
			cluster_unSub_single_sbj(cluster, sbj);
		}
	});

}

/**
 * [update_cluster_and_broker description]
 * @param esbcli  [description]
 * @param clu     [description]
 * @param cliType [description]
 */
void update_cluster_and_broker_consume(esb_client_t *esbcli, esb_cluster_t *clu, int cliType) {
	regConf_json_t *regConf_obj;
	ClusterConf_json_t *cluConf;
	esb_broker_t  *brk;
	int i, j, found = 0;
	char *brk_addr;

	regConf_obj = esbcli->reg.reg_conf_obj;

	for (i = 0; i < regConf_obj->clu_array_cnt; ++i)
	{
		cluConf = &regConf_obj->cluConf_array[i];
		if (cluConf->hashCode == clu->hash_code && cluConf->type == cliType)
		{
			found = 1;
			break;
		}
	}
	if (found == 0) {
		return;
	}

	for (j = 0; j < cluConf->node_cnt; ++j)
	{
		brk = (esb_broker_t*)hash_get(clu->clu_brk_map, cluConf->nodes[j]);

		if (brk != NULL)
			continue;

		//brk_addr = cluConf->nodes[j];
		/** 集群节点 broker 扩容 */
		/** broker 对象目前不存在，新建，并插入cluster的 brk map */
		brk = new_esb_broker_t(cluConf->nodes[j], esbcli, clu);
		if (brk == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: brk NULL]\n", __FUNCTION__, __LINE__);
			continue;
		}
		//hash_set(clu->clu_brk_map, brk_addr, brk);
		cluster_brk_addToMap(clu, brk);
	}

	hash_each(clu->clu_brk_map, {
		brk = (esb_broker_t*)val;
		found = 0;
		for (j = 0; j < cluConf->node_cnt; ++j)
		{
			//brk_addr = cluConf->nodes[j];
			if (0 == strcmp(brk->brk_ip_port_str, cluConf->nodes[j])) {
				found = 1;
				break;
			}
		}
		if (found == 1)
			continue;
		/** 节点在新配置中不存在，集群节点 broker 缩容 */
		reduce_single_broker(brk);
	});

}

/**
 * [reduce_single_broker description]
 * @param brk [description]
 */
void reduce_single_broker(esb_broker_t *brk) {
	int ret;
	struct timeval tv;

	if (1 == brk->broker_close_flag)
		return;

	gettimeofday(&tv, NULL);

	/** 设置broker关闭 标志 */
	brk->broker_close_flag = 1;
	brk->close_timestamp = tv.tv_sec;
	esb_client_t * esbcli = (esb_client_t *)brk->esbcli;
	if (esbcli->client_type == ESB_CLI_TYPE_COMSUMER) {
		/** 发送unSub 取消订阅 请求 */

		/** 提交最后的offset **/
		if (brk->brk_queue_map != NULL) {
				hash_each(brk->brk_queue_map, {
				esb_queue_t* queue = (esb_queue_t*)val;
				//printf("提交offset----A\n");
				broken_commit_offset_for_queue(brk,queue, queue->sbj_obj,0);
			});
		}

		ret = broker_unSub_all_subject(brk);
		if (ret < 0)
		{
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker_unSub_all_subject failed, ret < 0]\n", __FUNCTION__, __LINE__);
			return;
		}
	} else if (esbcli->client_type == ESB_CLI_TYPE_PRODUCER) {
		brk->state = CLOSE;
	}
	esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> broker reduced, Addr] %s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
}

/**
 * [update_sbj_and_cluster_produce description]
 * @param esbcli  [description]
 * @param sbj     [description]
 * @param cliType [description]
 */
void update_sbj_and_cluster_produce(esb_client_t *esbcli, esb_subject_t *sbj, int cliType) {
	int i, j, ret, found;
	long cluster_id;
	esb_cluster_t *cluster;
	regConf_json_t *regConf_obj;
	SubjectConf_json_t *sbjConf;
	char *cluster_key;
	esb_broker_t  *brk;
	int changed = 0;

	regConf_obj = esbcli->reg.reg_conf_obj;

	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> update_sbj_and_cluster_produce sbj:%u]\n", __FUNCTION__, __LINE__, sbj->subject_id);

	for (i = 0; i < regConf_obj->sbj_array_cnt; ++i)
	{
		sbjConf = &regConf_obj->sbjConf_array[i];
		/** 匹配 主题id、clientid、type */
		if (sbjConf->name == sbj->subject_id && sbjConf->type == cliType &&
		        sbjConf->clientId == sbj->client_id) {
			break;
		}
	}

	for (j = 0; j < sbjConf->clu_cnt; ++j) {
		cluster_id = sbjConf->clusters[j];
		cluster_key = (char*)calloc(1, 32);
		sprintf(cluster_key, "%ld", cluster_id);

		ret = hash_has(sbj->sbj_cluster_map, cluster_key);
		/**  */
		if (ret == 1) {
			free(cluster_key);
			continue;
		}
		/** 主题扩容 */
		cluster = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, cluster_key);
		changed = 1;
		if (cluster == NULL || cluster->state == CLU_INIT)
		{
			/** 集群尚不存在或处于init状态，尝试新建对象及配置 */
			check_init_cluster_pro(cluster_id, esbcli, sbj, cliType);
			cluster = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, cluster_key);
			if (cluster != NULL) {
				cluster_start_each_broker(cluster);
			}
		} else {
			esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> crontab cluster_send_single_sbj clu:%ld sbj:%u]\n", __FUNCTION__, __LINE__, cluster->hash_code, sbj->subject_id);
			/** 集群已经处于normal运行状态，发起订阅主题 */
			//cluster_sub_single_sbj(cluster, sbj);
		}
		free(cluster_key);
	}

	hash_each(sbj->sbj_pro_cluster_map, {
		//cluster = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, key);
		cluster = (esb_cluster_t*)val;
		found = 0;
		for (j = 0; j < sbjConf->clu_cnt; ++j) {
			cluster_id = sbjConf->clusters[j];
			if (cluster_id == cluster->hash_code) {
				found = 1;
				break;
			}
		}
		/** 主题缩容 */
		if (found == 0) {
			changed = 1;
			cluster_key = (char *)key;
			if (hash_size(cluster->clu_brk_map) == 0) {
				del_cluster_fromsbj(sbj, cluster_key);
				free_esb_cluster(cluster);
				continue;
			}

			hash_each(cluster->clu_brk_map, {
				brk = (esb_broker_t*)val;
				//brk->broker_close_flag = 1;
				reduce_single_broker(brk);
			});
			//free_esb_cluster(cluster);
		}
	});

	if (changed == 1) {
		generate_sbj_clu_arr(sbj);
	}
}

/**
 * [update_cluster_and_broker_produce description]
 * @param esbcli  [description]
 * @param clu     [description]
 * @param cliType [description]
 */
void update_cluster_and_broker_produce(esb_client_t *esbcli, esb_cluster_t *clu, int cliType) {
	regConf_json_t *regConf_obj;
	ClusterConf_json_t *cluConf;
	esb_broker_t  *brk;
	int i, j, found = 0;
	char *brk_addr;
	int changed = 0;

	regConf_obj = esbcli->reg.reg_conf_obj;

	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> update_cluster_and_broker_produce cluster:%u]\n", __FUNCTION__, __LINE__, clu->hash_code);

	for (i = 0; i < regConf_obj->clu_array_cnt; ++i)
	{
		cluConf = &regConf_obj->cluConf_array[i];
		if (cluConf->hashCode == clu->hash_code && cluConf->type == cliType)
		{
			found = 1;
			break;
		}
	}
	if (found == 0) {
		return;
	}

	for (j = 0; j < cluConf->node_cnt; ++j)
	{
		brk = (esb_broker_t*)hash_get(clu->clu_brk_map, cluConf->nodes[j]);

		if (brk != NULL)
			continue;

		//brk_addr = cluConf->nodes[j];
		/** 集群节点 broker 扩容 */
		/** broker 对象目前不存在，新建，并插入cluster的 brk map */
		changed = 1;
		brk = new_esb_broker_t(cluConf->nodes[j], esbcli, clu);
		if (brk == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: brk NULL]\n", __FUNCTION__, __LINE__);
			continue;
		}
		//hash_set(clu->clu_brk_map, brk_addr, brk);
		cluster_brk_addToMap(clu, brk);
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> add broker to cluster:%s  %u]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, clu->hash_code);
	}

	hash_each(clu->clu_brk_map, {
		brk = (esb_broker_t*)val;
		found = 0;
		for (j = 0; j < cluConf->node_cnt; ++j)
		{
			//brk_addr = cluConf->nodes[j];
			if (0 == strcmp(brk->brk_ip_port_str, cluConf->nodes[j])) {
				found = 1;
				break;
			}
		}
		if (found == 1)
			continue;
		/** 节点在新配置中不存在，集群节点 broker 缩容 */
		changed = 1;
		reduce_single_broker(brk);
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> reduce broker from cluster:%s  %u]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, clu->hash_code);
	});

	if (changed == 1) {
		generate_clu_brk_arr(clu);
	}
}

/**
 * [close_broker_when_shutdown 关闭每个cluster的每个broker对象]
 * @param esbcli []
 */
void close_broker_when_shutdown(esb_client_t *esbcli) {
	esb_cluster_t *clu;
	esb_subject_t *sub;
	esb_broker_t *brk;
	int brk_remain_cnt = 0;

	/** 判断关闭开关 */
	if (GlobleExitFlag != 1 && esbcli->esbcli_close_flag != 1) {
		return;
	}
	/** 判断所有的worke都不再消费 */
	if (esbcli->in_callback_worker_cnt > 0) {
		return;
	}

	if (esbcli->client_type == ESB_CLI_TYPE_COMSUMER) {
		/** 先sleep 200毫秒，保证offset都已经提交 */
		usleep(1000 * 200);
		/** 关闭每个cluster的每个broker对象 */
		hash_each(esbcli->cli_cluster_map, {
			clu = (esb_cluster_t*)val;
			hash_each(clu->clu_brk_map, {
				brk = (esb_broker_t*)val;
				/** 对单个broker对象执行“缩容”操作，达到平滑关闭的效果 */
				reduce_single_broker(brk);
				brk_remain_cnt += 1;
			});

		});

	} else if (esbcli->client_type == ESB_CLI_TYPE_PRODUCER) {
		/** 关闭每个cluster的每个broker对象 */
		hash_each(esbcli->cli_sbj_map, {
			sub = (esb_subject_t*)val;
			hash_each(sub->sbj_pro_cluster_map, {
				clu = (esb_cluster_t*)val;
				hash_each(clu->clu_brk_map, {
					brk = (esb_broker_t*)val;
					/** 对单个broker对象执行“缩容”操作，达到平滑关闭的效果 */
					reduce_single_broker(brk);
					brk_remain_cnt += 1;
				});
			});
		});
	}

	if (brk_remain_cnt == 0) {
		ESB_thread_exit(NULL);
	}
}


void cleanUp_closing_broker(esb_client_t *esbcli) {
	int remove_flag;
	esb_cluster_t *clu;
	esb_subject_t *sub;
	esb_broker_t *brk;
	int cnt;

	if (esbcli->client_type == ESB_CLI_TYPE_COMSUMER) {
		/** 扫描 每个broker */
		hash_each(esbcli->cli_cluster_map, {
			remove_flag = 0;
			clu = (esb_cluster_t*)val;
			hash_each(clu->clu_brk_map, {
				brk = (esb_broker_t*)val;

				if (brk->broker_close_flag != 1)
					continue;
				/** 清理broker请求存根 */
				cnt = cleanUp_broker_req_stub(brk, 0);
				/** stub存根还有剩余，等待下次清理 */
				if (cnt > 0)
					continue;
				/** 摘除broker */
				//hash_del(clu->clu_brk_map, key);
				cluster_brk_removeMap(clu, brk);
				/** 延迟释放broker对象，其中会自动关闭bufferevent，并自动关闭相关socket连接 */
				esb_free_broker_later(brk);
				remove_flag = 1;
			});

			if (remove_flag == 1) {
				generate_clu_brk_arr(clu);
			}
		});
	} else if (esbcli->client_type == ESB_CLI_TYPE_PRODUCER) {
		/** 扫描每个cluster的每个broker对象 */
		hash_each(esbcli->cli_sbj_map, {
			sub = (esb_subject_t*)val;
			hash_each(sub->sbj_pro_cluster_map, {
				remove_flag = 0;
				clu = (esb_cluster_t*)val;
				hash_each(clu->clu_brk_map, {
					brk = (esb_broker_t*)val;

					if (brk->broker_close_flag != 1)
						continue;

					cluster_brk_removeMap(clu, brk);
					/** 释放broker对象，其中会自动关闭bufferevent，并自动关闭相关socket连接 */
					if (brk->closable != 1){
						continue;
					}
					free_esb_broker_t(brk);
					remove_flag = 1;
				});

				if (remove_flag == 1) {
					generate_clu_brk_arr(clu);
				}
			});
		});
	}
}


void check_brokers_request_timeout(esb_client_t *esbcli) {
	esb_cluster_t *clu;
	esb_broker_t *brk;

	/** 扫描 每个broker */
	hash_each(esbcli->cli_cluster_map, {
		clu = (esb_cluster_t*)val;
		hash_each(clu->clu_brk_map, {
			brk = (esb_broker_t*)val;
			/** 检查每个broker是否有超时 */
			check_broker_req_timeout(brk);
		});
	});
}

/**
 * [check_worker_thread_alive ]
 * @param esbcli []
 */
void check_worker_thread_alive(esb_client_t *esbcli) {
	int ret, i;
	if (esbcli->all_thrd_handles == NULL)
	{
		return;
	}
	for (i = 0; i < esbcli->u_conf.worker_thread_count; ++i)
	{
		ret = ESB_thread_kill(esbcli->all_thrd_handles[i], 0);
		if (ret == 0)
		{
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> worker thread is alive; index:%d thread_id:%lu]\n", __FUNCTION__, __LINE__, i, esbcli->all_thrd_handles[i]);
		} else {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d--> worker thread disaper; index:%d thread_id:%lu]\n", __FUNCTION__, __LINE__, i, esbcli->all_thrd_handles[i]);
		}
	}
}
