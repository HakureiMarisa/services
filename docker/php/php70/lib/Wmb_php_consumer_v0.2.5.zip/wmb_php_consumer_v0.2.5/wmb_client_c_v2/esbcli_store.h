/**
 * @file
 * @brief
 *
 * @auth 58ganji - Liu dan
 */

#include <inttypes.h>
#include "esbcli_thread.h"

#ifndef _ESBCLI_STORE_H
#define _ESBCLI_STORE_H

#include "hash.h"
#include "esbcli_broker.h"

typedef struct esb_store_s {
	// cluster集群ID
	char		*store_key;
	uint32_t	weight;

	/** 反向指针，指向 esb_client_t 对象 */
	void   *esbcli;
}esb_store_t;

esb_store_t * new_esb_store(char *store_key, uint32_t weight, void *ecli);
void free_esb_store(esb_store_t *store);

#endif
