/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <assert.h>

#include "esbclient.h"
#include "esbcli_util.h"
#include "esbcli_subject.h"
#include "esbcli_cluster.h"
#include "esbcli_registryJSON.h"
#include "esbcli_crontab.h"
#include "esbcli_thread.h"


int check_init_cluster(long cluster_id, esb_client_t *esbcli, esb_subject_t *sbj, int cliType);
int check_init_cluster_pro(long cluster_id, esb_client_t *esbcli, esb_subject_t *sbj, int cliType);


int find_sbj_and_init_cluster(esb_client_t *esbcli, esb_subject_t *sbj, int cliType) {
	int i, j, ret, subject_found_flag = 0;
	regConf_json_t *regConf_obj;
	SubjectConf_json_t *sbjConf;

	regConf_obj = esbcli->reg.reg_conf_obj;

	for (i = 0; i < regConf_obj->sbj_array_cnt; ++i)
	{
		sbjConf = &regConf_obj->sbjConf_array[i];
		/** 匹配 主题id、clientid、type */
		if (sbjConf->name != sbj->subject_id || sbjConf->type != cliType || sbjConf->clientId != sbj->client_id) {
			continue;
		}
		for (j = 0; j < sbjConf->clu_cnt; ++j) {
			if (cliType == ESB_CLI_TYPE_PRODUCER) {
				ret = check_init_cluster_pro(sbjConf->clusters[j], esbcli, sbj, cliType);
			} else {
				ret = check_init_cluster(sbjConf->clusters[j], esbcli, sbj, cliType);
			}

			if (ret < 0) {
				return ret;
			}
			subject_found_flag = 1;
		}
	}

	/** 若subject相关配置未找到，返回错误 */
	if (subject_found_flag != 1)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: no Cluster was found for Subject: %d !]\n", __FUNCTION__, __LINE__, sbj->subject_id);
		// error, what to do?
		esb_set_error(ESB_ERR_SBJ_INIT);
		return ESB_ERR_SBJ_INIT;
	}

	// 成功
	return ESB_ERR_SUCCESS;
}

/**
 * [check_init_cluster_pro 为“消费者”初始化 cluster 及 broker]
 * @param cluster_id [description]
 * @param esbcli     [description]
 * @param sbj        [description]
 */
int check_init_cluster_pro(long cluster_id, esb_client_t *esbcli, esb_subject_t *sbj, int cliType) {
	char *cluster_key, *sbj_key, *brk_addr;
	esb_cluster_t *cluster;
	esb_broker_t  *broker;
	int i, j, brk_found_flag = 0;
	regConf_json_t *regConf_obj;
	ClusterConf_json_t *cluConf;

	if (cliType != ESB_CLI_TYPE_PRODUCER) {
		return ESB_ERR_SUCCESS;
	}

	regConf_obj = esbcli->reg.reg_conf_obj;

	for (i = 0; i < regConf_obj->clu_array_cnt; ++i)
	{
		cluConf = &regConf_obj->cluConf_array[i];
		if (cluConf->hashCode != cluster_id || cluConf->type != cliType)
		{
			continue;
		}
		/** 查找，必要时，新建 cluster 对象 */
		cluster_key = (char*)calloc(1, 32);
		sprintf(cluster_key, "%ld", cluster_id);
		//cluster = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, cluster_key);
		cluster = (esb_cluster_t*)hash_get(sbj->sbj_pro_cluster_map, cluster_key);
		if (cluster == NULL)
		{
			/** cluster对象目前不存在，新建，并关联主题、插入"集群map" */
			cluster = new_esb_cluster(cluConf->hashCode, cluConf->type, cluConf->version, esbcli);
			//hash_set(esbcli->cli_cluster_map, get_cluster_map_key(cluster), cluster);
			hash_set(sbj->sbj_pro_cluster_map, get_cluster_map_key(cluster), cluster);
		}
		free(cluster_key);

		/** 双向关联“集群”与“主题” */
		sbj_key = get_sbj_map_key(sbj);
		cluster_sbj_addToMap(cluster, sbj_key);
		//subject_clu_addToMap(sbj, get_cluster_map_key(cluster));
		add_cluster_tosbj(sbj, get_cluster_map_key(cluster));


		for (j = 0; j < cluConf->node_cnt; ++j)
		{
			brk_addr = cluConf->nodes[j];

			broker = (esb_broker_t*)hash_get(cluster->clu_brk_map,brk_addr );
			if (broker == NULL)
			{
				/** broker 对象目前不存在，新建，并插入cluster的 brk map */
				broker = new_esb_broker_t(brk_addr, esbcli, cluster);
				if (broker == NULL) {
					esb_printf(ESB_PRINT_ERROR, "[%s,%d:: brk NULL]\n", __FUNCTION__, __LINE__);
					continue;
				}
				//hash_set(cluster->clu_brk_map, brk_addr, broker);
				cluster_brk_addToMap(cluster, broker);
			}
			brk_found_flag = 1;
		}
		generate_clu_brk_arr(cluster);
	}

	generate_sbj_clu_arr(sbj);

	if (brk_found_flag != 1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: no Server was found for Subject!]\n", __FUNCTION__, __LINE__);
		// error, what to do?
		esb_set_error(ESB_ERR_SBJ_INIT);
		return ESB_ERR_SBJ_INIT;
	}

	return ESB_ERR_SUCCESS;
}


/**
 * [check_and_init_cluster 为“消费者”初始化 cluster 及 broker]
 * @param cluster_id [description]
 * @param esbcli     [description]
 * @param sbj        [description]
 */
int check_init_cluster(long cluster_id, esb_client_t *esbcli, esb_subject_t *sbj, int cliType) {
	char *cluster_key, *sbj_key, *brk_addr;
	esb_cluster_t *cluster;
	esb_broker_t  *broker;
	int i, j, brk_found_flag = 0;
	regConf_json_t *regConf_obj;
	ClusterConf_json_t *cluConf;

	regConf_obj = esbcli->reg.reg_conf_obj;

	for (i = 0; i < regConf_obj->clu_array_cnt; ++i)
	{
		cluConf = &regConf_obj->cluConf_array[i];
		if (cluConf->hashCode != cluster_id || cluConf->type != cliType)
		{
			continue;
		}
		/** 查找，必要时，新建 cluster 对象 */
		cluster_key = (char*)calloc(1, 32);
		sprintf(cluster_key, "%ld", cluster_id);
		cluster = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, cluster_key);
		if (cluster == NULL)
		{
			/** cluster对象目前不存在，新建，并关联主题、插入"集群map" */
			cluster = new_esb_cluster(cluConf->hashCode, cluConf->type, cluConf->version, esbcli);
			hash_set(esbcli->cli_cluster_map, get_cluster_map_key(cluster), cluster);
		}
		free(cluster_key);

		/** 双向关联“集群”与“主题” */
		sbj_key = get_sbj_map_key(sbj);
		cluster_sbj_addToMap(cluster, sbj_key);
		//subject_clu_addToMap(sbj, get_cluster_map_key(cluster));
		add_cluster_tosbj(sbj, get_cluster_map_key(cluster));


		for (j = 0; j < cluConf->node_cnt; ++j)
		{
			brk_addr = cluConf->nodes[j];

			broker = (esb_broker_t*)hash_get(cluster->clu_brk_map, brk_addr);
			if (broker == NULL)
			{
				/** broker 对象目前不存在，新建，并插入cluster的 brk map */
				broker = new_esb_broker_t(brk_addr, esbcli, cluster);
				if (broker == NULL) {
					esb_printf(ESB_PRINT_ERROR, "[%s,%d:: brk NULL]\n", __FUNCTION__, __LINE__);
					continue;
				}
				//hash_set(cluster->clu_brk_map, brk_addr, broker);
				cluster_brk_addToMap(cluster, broker);
			}
			brk_found_flag = 1;
		}
		generate_clu_brk_arr(cluster);
	}

	generate_sbj_clu_arr(sbj);

	if (brk_found_flag != 1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: no Server was found for Subject!]\n", __FUNCTION__, __LINE__);
		// error, what to do?
		esb_set_error(ESB_ERR_SBJ_INIT);
		return ESB_ERR_SBJ_INIT;
	}

	return ESB_ERR_SUCCESS;
}


/**
 * [init_Local_msg_queue description]
 * @param  esbcli [description]
 * @param  cnt    [description]
 * @return        [description]
 */
int init_Local_msg_queue(esb_client_t *esbcli, int cnt) {
	esb_msg_t * msg_p;
	int i;

	/** 申请cnt指定个数msg空间，付给头指针（全局变量） */
	esbcli->GLB_msg_array = (esb_msg_t *)calloc(cnt, sizeof(esb_msg_t));
	assert(esbcli->GLB_msg_array);

	/** 初始化链表头 */
	TAILQ_INIT(&esbcli->local_msgq.emq_msgs);
	TAILQ_INIT(&esbcli->local_msgq_free.emq_msgs);

	msg_p = esbcli->GLB_msg_array;
	for (i = 0; i < cnt; ++i)
	{
		TAILQ_INSERT_TAIL(&esbcli->local_msgq_free.emq_msgs, msg_p, em_link);
		msg_p += 1;
	}
	esbcli->local_msgq_free.cnt = cnt;

	ESB_mutex_init(&esbcli->local_msgq.mutex, NULL);
	ESB_mutex_init(&esbcli->local_msgq_free.mutex, NULL);
	ESB_thread_cond_init(&esbcli->local_msgq.emp_cond);
	ESB_thread_cond_init(&esbcli->local_msgq_free.emp_cond);

	return 0;
}

/**
 * [free_Local_msg_queue description]
 * @param esbcli [description]
 */
void free_Local_msg_queue(esb_client_t *esbcli) {
	ESB_mutex_destory(&esbcli->local_msgq.mutex);
	ESB_mutex_destory(&esbcli->local_msgq_free.mutex);
	ESB_thread_cond_destroy(&esbcli->local_msgq.emp_cond);
	ESB_thread_cond_destroy(&esbcli->local_msgq_free.emp_cond);

	if (esbcli->GLB_msg_array != NULL)
	{
		free(esbcli->GLB_msg_array);
	}
}

/**
 * [esb_localQueue_consume_thread description]
 * @param ecli [description]
 */
void esb_localQueue_consume_thread(void * ecli) {
	esb_client_t *esbcli;
	esb_msg_t * esb_msg;
	int free_cnt;
	long int tid;

	esbcli = (esb_client_t *)ecli;

	//esb_set_signal_action();
	esb_set_signal_action_sigpipe();

	tid = (long int)ESB_gettid();
	esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: consume worker thread start! gettid:%lu]\n", __FUNCTION__, __LINE__, tid);

	while (1) {
		esb_msg = NULL;
		while (esb_msg == NULL) {
			ESB_mutex_lock(&esbcli->local_msgq.mutex);
			if (esbcli->local_msgq.cnt > 0) {
				esb_msg = TAILQ_FIRST(&esbcli->local_msgq.emq_msgs);
				if (esb_msg != TAILQ_END(&esbcli->local_msgq.emq_msgs))
				{
					TAILQ_REMOVE(&esbcli->local_msgq.emq_msgs, esb_msg, em_link);
					esbcli->local_msgq.cnt -= 1;
				}
			} else {
				if (esbcli->Flag_ThreadExit_OnEmpty != 0)
				{
					/** 主线程已经发出“退出指令”，跳出循环，准备退出 */
					ESB_mutex_unlock(&esbcli->local_msgq.mutex);
					break;
				}
				/** 待处理msg链表为空，thread进入"等待" */
				ESB_thread_cond_wait(
				    &esbcli->local_msgq.emp_cond,
				    &esbcli->local_msgq.mutex);
			}
			ESB_mutex_unlock(&esbcli->local_msgq.mutex);

		}

		/** 未获得msg */
		if (esb_msg == NULL)
		{
			if (esbcli->Flag_ThreadExit_OnEmpty != 0)
			{
				/** 线程退出 */
				esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: consume worker thread close! gettid:%lu]\n", __FUNCTION__, __LINE__, tid);
				break;
			} else {
				/** 再次尝试获取msg */
				continue;
			}
		}


		/**原逻辑：直接调起回调函数执行消息加工
		 * 新逻辑  	1.每个消息保存了消息来源queue
		 *			2.通过消息来源queue，确认消息的消息版本，版本过旧则抛弃
		 *			3.通过消息来源queue，确认消息是否应当被抛弃
		 *			4.进行了消息计数，并且更新本地的消息消费情况
		 */		
		

		if (GlobleExitFlag > 0 || esbcli->esbcli_close_flag > 0) {
			// 准备退出，剩余的msg不再处理
			// do nothing
		}else if(esb_msg->qid!=-1&&esb_msg->pull_version<esb_msg->queue->max_pull_version){
			/** 此处因消息版本过低进行消息抛弃，之后需要回收资源，不可直接continue，只需保证不进行callback和计数即可，**/
		}else if(esb_msg->qid!=-1&&esb_msg->queue->abandon!=0){
			/** 此处因队列被设置为抛弃状态进行消息抛弃，之后需要回收资源，不可直接continue，只需保证不进行callback和计数即可，**/
		}else {
			ESB_mutex_lock(&esbcli->in_callback_mutex);
			esbcli->in_callback_worker_cnt += 1;
			ESB_mutex_unlock(&esbcli->in_callback_mutex);
			/** 调起回调函数，执行对消息的加工 */
			esbcli->msg_callback(esb_msg, esbcli->cb_ext_arg);
			/** 自动提交 consume offset */
			esbcli_commit_consume_offset(esbcli, esb_msg);
			ESB_mutex_lock(&esbcli->in_callback_mutex);
			esbcli->in_callback_worker_cnt -= 1;
			ESB_mutex_unlock(&esbcli->in_callback_mutex);
		}


		resetMsg_and_freePayload(esb_msg);
		/** 放回 空闲链表，重复利用msg结构，减少内存分配压力 */
		ESB_mutex_lock(&esbcli->local_msgq_free.mutex);
		TAILQ_INSERT_TAIL(&esbcli->local_msgq_free.emq_msgs, esb_msg, em_link);
		esbcli->local_msgq_free.cnt += 1;
		if (esbcli->local_msgq_free.cnt == 1)
		{
			/** 唤醒所有因 "空闲链表为空" 而等待的thread */
			ESB_thread_cond_broadcast(&esbcli->local_msgq_free.emp_cond);
		}
		free_cnt = esbcli->local_msgq_free.cnt;
		ESB_mutex_unlock(&esbcli->local_msgq_free.mutex);
		/** 检查空闲链表余量，触发push控制 */
		esb_check_localQ_pushCtl(esbcli, free_cnt);
	}
	//ESB_thread_exit(NULL);

}

/**
 * [esb_localQueue_consume_autonomy 主动触发的方式，消费本地队列中的消息]
 * @param  ecli    [description]
 * @param  msg_buf [description]
 * @return         [description]
 */
int esb_localQueue_consume_autonomy(esb_client_t* esbcli, esb_msg_t* msg_buf) {
	esb_msg_t * esb_msg;
	int free_cnt;

Start:
	esb_msg = NULL;
	while (esb_msg == NULL) {
		ESB_mutex_lock(&esbcli->local_msgq.mutex);
		if (esbcli->local_msgq.cnt > 0) {
			esb_msg = TAILQ_FIRST(&esbcli->local_msgq.emq_msgs);
			if (esb_msg != TAILQ_END(&esbcli->local_msgq.emq_msgs))
			{
				TAILQ_REMOVE(&esbcli->local_msgq.emq_msgs, esb_msg, em_link);
				esbcli->local_msgq.cnt -= 1;
			}
		} else {
			if (esbcli->Flag_ThreadExit_OnEmpty != 0)
			{
				/** 主线程已经发出“退出指令”，跳出循环，准备退出 */
				ESB_mutex_unlock(&esbcli->local_msgq.mutex);
				break;
			}
			/** 待处理msg链表为空，thread进入"等待" */
			ESB_thread_cond_wait(
			    &esbcli->local_msgq.emp_cond,
			    &esbcli->local_msgq.mutex);
		}
		ESB_mutex_unlock(&esbcli->local_msgq.mutex);
	}

	/** 未获得msg */
	if (esb_msg == NULL)
	{
		if (esbcli->Flag_ThreadExit_OnEmpty != 0)
		{
			/** 通知调用者localQueue已经消费完，可以退出 */
			return ESB_RET_QUEUE_EMPTY;
		} else {
			/** 再次尝试获取msg */
			goto Start;
		}
	}

	/** 调起回调函数，执行对消息的加工 */
	//esbcli->msg_callback(esb_msg, esbcli->cb_ext_arg);

	/** 拷贝msg */
	copy_esb_msg(msg_buf, esb_msg);
	/** 自动提交 consume offset */
	esbcli_commit_consume_offset(esbcli, esb_msg);

	/** 清空msg对象 */
	resetMsg_and_freePayload(esb_msg);

	/** 放回 空闲链表，重复利用msg结构，减少内存分配压力 */
	ESB_mutex_lock(&esbcli->local_msgq_free.mutex);
	TAILQ_INSERT_TAIL(&esbcli->local_msgq_free.emq_msgs, esb_msg, em_link);
	esbcli->local_msgq_free.cnt += 1;
	if (esbcli->local_msgq_free.cnt == 1)
	{
		/** 唤醒所有因 "空闲链表为空" 而等待的thread */
		ESB_thread_cond_broadcast(&esbcli->local_msgq_free.emp_cond);
	}
	free_cnt = esbcli->local_msgq_free.cnt;
	ESB_mutex_unlock(&esbcli->local_msgq_free.mutex);
	/** 检查空闲链表余量，触发push控制 */
	esb_check_localQ_pushCtl(esbcli, free_cnt);

	return ESB_ERR_SUCCESS;
}

/**
 * [esb_get_opaque description]
 * @param  esbcli [description]
 * @return        [description]
 */
uint64_t esb_get_opaque(esb_client_t *esbcli) {
	uint64_t opaque;
	ESB_mutex_lock(&esbcli->opaque_mutex);
	esbcli->opaque_counter += 1;
	if (esbcli->opaque_counter == 0x7ffffffffffffffeL) {
		esbcli->opaque_counter = 1;
	}
	opaque = esbcli->opaque_counter;
	ESB_mutex_unlock(&esbcli->opaque_mutex);
	return opaque;
}

int esb_client_consume_autonomy_start(esb_client_t *esbcli, int flag) {
	char *map_key;
	int ret, status, i;
	esb_cluster_t *clu;

	if (esbcli == NULL) {
		esb_set_error(ESB_ERR_ECLI_NULL);
		return ESB_ERR_ECLI_NULL;
	}
	esbcli->client_type = ESB_CLI_TYPE_COMSUMER;
	if (hash_size(esbcli->cli_cluster_map) <= 0 || hash_size(esbcli->cli_sbj_map) <= 0)
	{
		esb_set_error(ESB_ERR_ECLI_NOBRK);
		return ESB_ERR_ECLI_NOBRK;
	}

	/** 初始化各种 “退出信号”处理方法 */
	esb_set_signal_action();

	status = ESB_evthread_use_pthreads();
	if (status < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_evthread_use_pthreads status < 0]\n", __FUNCTION__, __LINE__);
		return -1;
	}

	/** 全局 event 句柄，初始化  */
	esbcli->esb_evbase = ESB_event_base_new();

	/** 初始化一定数量的 msg对象，插入空闲链表备用 */
	status = init_Local_msg_queue(esbcli, esbcli->u_conf.local_msg_queue_len);
	if (status < 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: init_Local_msg_queue status] %d\n", __FUNCTION__, __LINE__, status);
		// error, what to do?
		return -1;
	}

	/** 启动每个cluster“集群”，以及所属的每个broker */
	hash_each(esbcli->cli_cluster_map, {
		map_key = key;
		clu = (esb_cluster_t*)val;
		/** 仅启动用于 “消费” 的集群 type=1 */
		if (clu->type != ESB_CLI_TYPE_COMSUMER)
			continue;
		status = cluster_start_each_broker(clu);
		if (status < 0)
		{
			esb_set_error(status);
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: cluster_start_each_broker,clu:%s status] %d\n", __FUNCTION__, __LINE__, map_key, status);
			// error, what to do?
			//return status;
			/**  */
			esbcli->esbcli_close_flag = 1;
		}
	});

	/** worker线程数设为 0，因为将由用户主动触发相关操作 */
	esbcli->u_conf.worker_thread_count = 0;

	esbcli->esb_cron_thrd = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
	/** 启动 cron定时任务 线程 */
	ESB_thread_create(esbcli->esb_cron_thrd, NULL, (void*)&esb_cron_thread, &esbcli->reg);

	return status;
}

void esbcli_queue_global_index_add(esb_client_t *esbcli, esb_queue_t *q) {
	hash_set(esbcli->queue_global_index, get_queue_index_key(q), q);
}

void esbcli_queue_global_index_del(esb_client_t *esbcli, esb_queue_t *q) {
	hash_del(esbcli->queue_global_index, get_queue_index_key(q));
}

void esbcli_commit_consume_offset(esb_client_t *esbcli, esb_msg_t *msg) {
	esb_queue_t *q = NULL;
	if (strlen(msg->queue_index_key) == 0) {
		return;
	}
	q = hash_get(esbcli->queue_global_index, msg->queue_index_key);
	if (q == NULL) {
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> commit consume offset queue nofound !] q_index_key:%s\n", __FUNCTION__, __LINE__, msg->queue_index_key);
		return;
	}
	if (msg->pull_version < q->max_pull_version) {
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> commit consume offset PULL_VERSION expired !] %u/%u\n", __FUNCTION__, __LINE__, msg->pull_version, q->max_pull_version);
		return;
	}
	/** 避免小数覆盖大数  */
	//if (q->consume_offset != -1 && q->consume_offset >= (msg->logic_offset + 1)) {
	//esb_printf(ESB_PRINT_WARNING, "[%s,%d--> q:%d ack_old:%d ack_new:%d pull_offset:%d ]\n", __FUNCTION__, __LINE__, q->queue_id, q->consume_offset, msg->logic_offset + 1, q->offset);	
	//	return;
	//}
	/** logic_offset + 1 */
	q->consume_offset = msg->logic_offset + 1;
	//if (GlobleExitFlag == 1 || esbcli->esbcli_close_flag == 1) {
	//esb_printf(ESB_PRINT_WARNING, "[%s,%d--> q:%d consume_offset:%d pull_offset:%d ]\n", __FUNCTION__, __LINE__, q->queue_id, q->consume_offset, q->offset);	
	//}
}
