/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_UTIL_H
#define _ESBCLI_UTIL_H

#define ESB_PRINT_CLOSE   0
#define ESB_PRINT_ERROR   1
#define ESB_PRINT_WARNING 2
#define ESB_PRINT_NOTICE  3
#define ESB_PRINT_DEBUG   4

int esb_printf(int level, const char *format, ...);

/** 非错误返回值 */
#define ESB_RET_QUEUE_EMPTY  1001  // 本地消息队列，已经消费完，并且esbcli对象已经关闭；用于通知外层代码退出关闭

/** 错误码 */
#define ESB_ERR_SUCCESS          0         // OK
#define ESB_ERR_REG_CONN        -1001      // registry连接失败
#define ESB_ERR_REG_CONF        -1002      // registry拉取配置失败
#define ESB_ERR_KPATH_ILLEGAL   -1003      // key path不合法
#define ESB_ERR_KPATH_OPEN      -1004      // key path打开失败
#define ESB_ERR_KPATH_READ      -1005      // key path读失败
#define ESB_ERR_KPATH_ADDR      -1006      // key文件记录reg地址不合法
#define ESB_ERR_REG_JSON        -1007      // registry拉取配置json解析失败
#define ESB_ERR_SBJ_INIT        -1008      // subject未找到或初始化失败

#define ESB_ERR_ECLI_NULL       -2001      // esbcli对象为空
#define ESB_ERR_ECLI_NOBRK      -2002      // esbcli记录broker为空
#define ESB_ERR_ECLI_NEWBRK     -2003      // 新建broker对象失败
#define ESB_ERR_BRK_ADDR        -2004      // broker地址不合法
#define ESB_ERR_BRK_SOCK        -2005      // broker建立socket失败
#define ESB_ERR_BRK_CONN        -2006      // broker连接失败
#define ESB_ERR_BRK_SEND        -2007      // broker发送失败
#define ESB_ERR_ECLI_CLITYPE    -2008      // esbcli预设的client type错误
#define ESB_ERR_BRK_READ        -2009      // broker读取失败
#define ESB_ERR_BRK_NULL        -2010	   //发送消息时获取broker为NULL
#define ESB_ERR_TIMEOUT         -2011      //发送消息超时
#define ESB_ERR_CONN_TIMEOUT    -2012      // broker连接超时
#define ESB_ERR_DISPATCH_START_FAILED    -2013      // client event dispatch启动失败
#define ESB_ERR_ECLI_ISRUNING   -2014      // client 对象已经开始消费，禁止add subject

#define ESB_ERR_CLU_NOBRK       -2101      // cluster所属broker为空
#define ESB_ERR_CLU_NOSBJ       -2102      // cluster订阅subject为空

#define ESB_ERR_RECSM_SUCCESS    0	        // 重试消费成功
#define ESB_ERR_RECSM_FAILED    -3001	   // 重试消费失败
#define ESB_ERR_RECSM_MAXTIME   -3002	   // 重试消费次数达到最大

#define ESB_ERR_CMTOFSET_SUCCESS     0     // 非法offset提交，可能是推模式
#define ESB_ERR_CMTOFSET_ILLEGEL     -3005 // 非法offset提交，可能是推模式
#define ESB_ERR_CMTOFFSET_UNVALIABLE -3006 // 无效offset提交

/** 错误说明 */
#define ESB_ERR_NO_ERR_INFO         "errinfo no found"
#define ESB_ERR_SUCCESS_INFO        "SUCCESS" // 0
#define ESB_ERR_REG_CONN_INFO       "registry connect failed" //-1001
#define ESB_ERR_REG_CONF_INFO       "registry get broker config failed" //-1002
#define ESB_ERR_KPATH_ILLEGAL_INFO  "key path illegal" //-1003 
#define ESB_ERR_KPATH_OPEN_INFO     "key path open failed" //-1004
#define ESB_ERR_KPATH_READ_INFO     "key path read failed" //-1005  
#define ESB_ERR_KPATH_ADDR_INFO     "registry address illegal" //-1006
#define ESB_ERR_REG_JSON_INFO       "registry parse json failed" //-1007
#define ESB_ERR_SBJ_INIT_INFO       "subject no found or init failed" //-1008

#define ESB_ERR_ECLI_NULL_INFO      "esbcli object is NULL" //-2001 
#define ESB_ERR_ECLI_NOBRK_INFO     "esbcli broker count is zero" //-2002  
#define ESB_ERR_ECLI_NEWBRK_INFO    "new broker object failed" //-2003      
#define ESB_ERR_BRK_ADDR_INFO       "broker address illegal" //-2004   
#define ESB_ERR_BRK_SOCK_INFO       "broker new socket failed" //-2005
#define ESB_ERR_BRK_CONN_INFO       "broker connect failed" //-2006
#define ESB_ERR_BRK_SEND_INFO       "broker send data failed" //-2007 
#define ESB_ERR_ECLI_CLITYPE_INFO   "wrong client type" //-2008
#define ESB_ERR_BRK_READ_INFO       "broker read data failed" //-2009
#define ESB_ERR_ECLI_ISRUNING_INFO  "consumer is runing, add subject is forbidden" //-2014

#define ESB_ERR_CLU_NOBRK_INFO      "cluster with empty broker" // -2101
#define ESB_ERR_CLU_NOSBJ_INFO      "cluster subscribe no subject" // -2102

#define ESB_ERR_RECONSUME_SUCCESS_INFO  "msg reconsume success"	   // 0
#define ESB_ERR_RECONSUME_FAILED_INFO   "msg reconsume failed"	   // -3001
#define ESB_ERR_RECONSUME_MAXTIME_INFO  "msg reconsume to maxtime" // -3002

#define ESB_ERR_CMTOFSET_SUCCESS_INFO     "msg offset commit success"    // 0
#define ESB_ERR_CMTOFSET_ILLEGEL_INFO     "msg offset commit illegal" // -3005
#define ESB_ERR_CMTOFFSET_UNVALIABLE_INFO "msg offset unvaliable"  // -3006

void esb_set_error(int);
int esb_get_globle_error_code(void);
char * esb_get_error_info(int);

int getlocalIp();
int get_hashcode(char *str, int len);

long get_currenttime();
#endif
