
#ifndef _ESBCLI_WINDOW_DATA_H
#define _ESBCLI_WINDOW_DATA_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include "esbcli_protocol.h"

#include "esbcli_thread.h"

#define MAX_SESSIONID 0x7ffffffffffffffeL

extern int sessionId;

typedef void* (*convert_fun_)(void *retRaw1, void *retRaw2);

typedef struct window_data_s {
	convert_fun_ callback_fun_;
	ESB_mutex_t mutex;
	ESB_thread_cond_t cond;
	char * key_id;
	char * data;
	int data_len;
}window_data_t;

window_data_t * new_window_data(convert_fun_ callback);

void free_window_data(window_data_t * wd);

int waitone(window_data_t *wd, int timeout);

int getDatalen(window_data_t * wd);

char* get_hash_key(long seq);

void getTimeSpec(int t_mills, struct timespec *time_spec);

#endif
