/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLIENT_H
#define _ESBCLIENT_H

#include <assert.h>
#include <stdlib.h>
#include <errno.h>

#include "esbcli_util.h"
#include "esbcli_registry.h"
#include "esbcli_msg.h"
#include "esbcli_broker.h"
#include "esbcli_event.h"
#include "esbcli_protocol.h"
#include "esbcli_thread.h"
#include "esbcli_produce.h"
#include "esbcli_store.h"
#include "hash.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief esb_client_c version 版本号常量
 */
#define ESB_CLI_C_VERSION  0x000901ff


#define ESB_CLI_TYPE_PRODUCER 0
#define ESB_CLI_TYPE_COMSUMER 1

#define ESB_ENABLE_SINGLE_THREAD_CONSUME  0x00
#define ESB_ENABLE_MULTI_THREAD_CONSUME  0x01

extern int GlobleLogPrintLevel;

/**
 * [void  description]
 * @param  ext_arg [description]
 * @return         [description]
 */
typedef void (*esb_consume_msg_cb)(esb_msg_t *msg, void *ext_arg);

typedef void (*esb_sig_handler)(int signum);

/**
 *
 */
typedef struct esb_client_conf_s {
	/** 本地 msg 接收缓冲队列长度 */
	int   local_msg_queue_len;
	/** 每次拉取消息数量 */
	int   each_pull_max_msg_cnt;
	/** 拉取请求超时（秒） */
	int   pull_request_timeout_sec;
	/** 消息消费线程数量 */
	int   worker_thread_count;
	/** 外层包裹语言，如 PHP、C++、GO */
	char  external_lang_str[15];
	/** 外层包裹语言version */
	char  external_lang_version[31];
} esb_client_conf_t;

/**
 *
 */
typedef struct esb_client_s {
	/** 注册中心结构 */
	esb_registry_t     reg;

	int    			   client_type;

	esb_client_conf_t  u_conf;

	ESB_event_base_t  *esb_evbase;
	esb_subject_t     *sbj;

	/** worker工作线程句柄 数组 */
	ESB_thread_t      *all_thrd_handles;
	/** 工作线程退出标志（当本地msg缓冲队列为空时） */
	int                Flag_ThreadExit_OnEmpty;
	/** 当前处在callback消费逻辑当中的worker线程数 */
	int                in_callback_worker_cnt;
	ESB_mutex_t		   in_callback_mutex;
	/** 配置定时更新线程*/
	ESB_thread_t      *esb_cron_thrd;
	/** 事件循环异步线程*/
	ESB_thread_t      *esb_dispatch_loop_thrd;

	/** cli对象关闭标志 */
	int  esbcli_close_flag;
	/** cli对象发送关闭标志 */
	int  esbcli_send_close_flag;

	/** 暂停消费 标志 */
	int  consume_pause_flag;

	/** opaque计数器 */
	uint64_t           opaque_counter;
	ESB_mutex_t        opaque_mutex;

	/** 本地消息队列，空闲 消息对象 链表 */
	esb_msgq_t         local_msgq_free;
	/** 本地消息队列，已装载 消息对象 链表 */
	esb_msgq_t         local_msgq;
	/** 消息数组，头指针；用于退出时，释放存储空间 */
	esb_msg_t         *GLB_msg_array;

	/** 消费回调函数 */
	esb_consume_msg_cb msg_callback;
	/** 回调函数 额外参数指针 */
	void              *cb_ext_arg;

	/** 全局queue对象索引，用于“消费ACK”功能，用来查询queue对象
	 *  说明：原本，queue对象的从属关系：esbcli => cluster => broker => queue；
	 *        但“消费ACK”查询queue对象时，频率很高，查询层级又过深;
	 *        故单独再维护一份esbcli全局索引，查询层级降到1层，且避免了许多“加锁操作”。
	 */
	hash_t            *queue_global_index;  // map: [char*] queue内存地址 => [esb_queue_t*] queue

	/** subject 主题 列表 */
	hash_t            *cli_sbj_map;   //  map:  [char*] subject_id  => [esb_subject_t*] sbj

	/** 消费 cluster 列表 */
	hash_t            *cli_cluster_map;  // map:  [char*] hash_code  => [] cl

	/** store列表 */
	hash_t			  *cli_store_map;

	/** store weight列表 */
	hash_t			  *cli_store_weight_map;

	esb_send_hd_t     *send_hd;

	ESB_mutex_t		  start_send_mutex;

	int               is_start_dispatch;

	ESB_mutex_t		  start_dispatch_mutex;

	hash_t 			  *sbj_send_info;
	hash_t 			  *abondan_queue;

	/**等待ack窗口*/
	hash_t            *wait_windows;
	ESB_mutex_t		  wait_windows_mutex;


} esb_client_t;

/**
 * [esb_client_new  新建esbclient对象]
 * @param  key_path         [key文件路径]
 * @return esb_client_t*    [对象指针]
 */
esb_client_t * esb_client_new(char *key_path);

/**
 * [esb_client_destroy 销毁esbclient对象]
 * @param esbcli [对象指针]
 */
void esb_client_destroy(esb_client_t *esbcli);
void free_esb_client(esb_client_t *esbcli);

void esb_client_prepare_to_close(esb_client_t *esbcli);

/**
 * [esb_client_add_subject description]
 * @param esbcli     [description]
 * @param subject_id [description]
 * @param client_id  [description]
 * @param sub_mode   [description]
 */
int esb_add_consume_subject(esb_client_t *esbcli, int subject_id,
                            int client_id, int sub_mode);

int find_sbj_and_init_cluster(esb_client_t *esbcli, esb_subject_t *sbj, int cliType);

int esb_client_comsumer_zts(esb_client_t *esbcli, esb_consume_msg_cb comsume_cb, int flag);

/**
 * [esb_client_comsumer_loop description]
 * @param  esbcli     [description]
 * @param  comsume_cb [description]
 * @return            [description]
 */
int esb_client_comsumer_loop(esb_client_t *esbcli, esb_consume_msg_cb comsume_cb, int flag);

/**
 * [esb_client_comsume_start description]
 * @param  esbcli     [description]
 * @param  comsume_cb [description]
 * @return            [description]
 */
int esb_client_comsume_start(esb_client_t *esbcli, esb_consume_msg_cb comsume_cb, int flag);

/**
 * [esb_client_consume_autonomy_start 主动获取模式  消费者启动]
 * @param  esbcli [description]
 * @param  flag   [description]
 * @return        [description]
 */
int esb_client_consume_autonomy_start(esb_client_t *esbcli, int flag);

/**
 * [esb_client_syncSend description]
 * @param  esbcli     [description]
 * @param  msg        [description]
 * @param  msg_len    [description]
 * @param  subject_id [description]
 * @return            [description]

int esb_client_syncSend(esb_client_t *esbcli, char *msg_body, int msg_len);*/


int init_Local_msg_queue(esb_client_t *esbcli, int cnt);
void free_Local_msg_queue(esb_client_t *esbcli);

void esb_localQueue_consume_thread(void * ecli);

int esb_localQueue_consume_autonomy(esb_client_t* esbcli, esb_msg_t* msg_buf);


/**
 * [esb_client_set_logPrintLevel 设置全局输出级别]
 * @param level [description]
 */
void esb_client_set_logPrintLevel(int level);

void esb_client_set_noSigHandle();

/**
 * [esb_client_set_cbExtArg description]
 * @param  esbcli  [description]
 * @param  ext_arg [description]
 * @return         [description]
 */
int esb_client_set_cbExtArg(esb_client_t *esbcli, void * ext_arg);


uint64_t esb_get_opaque(esb_client_t *esbcli);

void * asyncSend_cb(void * args);

void * asyncSend_queue_cb(void * args);

/**
 * [esb_client_produce_init 初始化生产者事件]
 * @param  esbcli     [description]
 * @return            [description]
 */
int esb_client_produce_init(esb_client_t *esbcli, int flag);
/**
 * [esb_client_dispatch_start description]
 * @param  esbcli     [description]
 * @return            [description]
 */
int esb_client_dispatch_start(esb_client_t *esbcli);

/**
 * [getBroker 发送时获取broker]
 * @param  msg        [发送消息实体]
 * @return            [null]
 */
esb_broker_t * get_broker(esb_client_t *esbcli, int subjectId);

esb_broker_t * get_broker_with_seq(esb_client_t *esbcli, int subjectId, int seq);

esb_broker_t * get_sole_broker(esb_client_t *esbcli, int subjectId);

/**
 * [esb_client_asyncSend 异步发送接口]
 * @param  msg        [发送消息实体]
 * @return            [null]
 */
void esb_client_asyncSend(esb_client_t *esbcli, esb_msg_t *msg);

/**
 * [esb_client_asyncSend_with_cb 异步发送+回调接口]
 * @param  msg        [发送消息实体]
 * @param  send_cb    [发送回调]
 * @return            [null]
 */
void esb_client_asyncSend_with_cb(esb_client_t *esbcli, esb_msg_t *msg, esb_send_msg_cb send_cb);

/**
 * [esb_client_asyncSend 异步顺序发送接口]
 * @param  msg        [发送消息实体]
 * @return            [null]
 */
void esb_client_asyncSend_queue(esb_client_t *esbcli, esb_msg_t *msg);

/**
 * [esb_client_asyncSend_queue_with_cb 异步顺序发送接口+回调]
 * @param  msg        [发送消息实体]
 * @param  send_cb    [发送回调]
 * @return            [null]
 */
void esb_client_asyncSend_queue_with_cb(esb_client_t *esbcli, esb_msg_t *msg, esb_send_msg_cb send_cb);

/**
 * [esb_client_syncSend_with_tm 同步发送接口+超时设置]
 * @param  msg        [发送消息实体]
 * @param  timeout    [超时时间(ms)]
 * @return            [发送结果]
 */
int esb_client_syncSend_with_tm(esb_client_t *esbcli, esb_msg_t *msg, int timeout);

/**
 * [esb_client_syncSend 同步发送接口]
 * @param  msg        [发送消息实体]
 * @return            [发送结果]
 */
int esb_client_syncSend(esb_client_t *esbcli, esb_msg_t *msg);

/**
 * [esb_client_syncSendQueue_with_tm 同步顺序发送接口+超时设置]
 * @param  msg        [发送消息实体]
 * @param  timeout    [超时时间(ms)]
 * @return            [发送结果]
 */
int esb_client_syncSendQueue_with_tm(esb_client_t *esbcli, esb_msg_t *msg, int timeout);

/**
 * [esb_client_syncSendQueue 同步顺序发送接口]
 * @param  msg        [发送消息实体]
 * @return            [发送结果]
 */
int esb_client_syncSendQueue(esb_client_t *esbcli, esb_msg_t *msg);



/**
 * 提交消费offset
 * @param msg
 * @param delayTimeLevel
 * @return
 */
int commitConsumeOffset(esb_msg_t *msg) ;

/**
 * 提交消费ack并重新消费
 * @param msg
 * @param delayTimeLevel
 * @return
 */
int commitMsgWithReconsume(esb_msg_t *msg,DelayLevel delayTimeLevel);

/**
 * 重新消费消息
 * @param msg 默认最多消费5次,每次消费延迟时间依次递增[1s, 5s, 10s, 20s, 30s]
 * @return
 */
int esb_client_reConsume(esb_msg_t *msg);

/**
 * 重新消费消息
 * @param msg
 * @param delayTimeLevel
 * @return
 */
int esb_client_reConsumeByCustomDelay(esb_msg_t *msg, DelayLevel delayTimeLevel);

/**
 * 重试消费的专用端口
 */
int esb_client_reConsume_sendBack(esb_client_t *esbcli, esb_msg_t *msg);

void esb_client_close_callback(esb_client_t *esbcli);

void esb_set_signal_action();
void esb_set_signal_action_sigpipe();
void esb_set_signal_handler(esb_sig_handler sig_handler);

void esb_client_set_store_conf(esb_client_t *esbcli);


#ifdef __cplusplus
}
#endif

#endif
