/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "esbcli_util.h"
#include "esbcli_registryJSON.h"

int parse_clusterConf(ClusterConf_json_t *cluConf, cJSON *clu_item);
int parse_subjectConf(SubjectConf_json_t *sbjConf, cJSON *sbj_item);

regConf_json_t *new_regConf_json_t() {
	regConf_json_t *conf_obj;

	conf_obj = (regConf_json_t*)calloc(1, sizeof(regConf_json_t));

	return conf_obj;
}

void free_regConf_json_t(regConf_json_t *conf_obj) {
	int i;
	if (conf_obj == NULL)
		return;
	if (conf_obj->cluConf_array != NULL) {
		for (i = 0; i < conf_obj->clu_array_cnt; ++i) {
			reset_ClusterConf_json_t(&conf_obj->cluConf_array[i]);
		}
		free(conf_obj->cluConf_array);
	}
	if (conf_obj->sbjConf_array != NULL) {
		for (i = 0; i < conf_obj->sbj_array_cnt; ++i) {
			reset_SubjectConf_json_t(&conf_obj->sbjConf_array[i]);
		}
		free(conf_obj->sbjConf_array);
	}
	if (conf_obj->key != NULL) {
		free(conf_obj->key);
	}
	free(conf_obj);
}

/**
 * [parse_regConf_from_json description]
 * @param  conf_obj [description]
 * @param  js_root  [description]
 * @return          [description]
 */
int parse_regConf_from_json(regConf_json_t *conf_obj, cJSON *js_root) {
	cJSON *sbj_list, *sbj_item, *clu_list, *clu_item, *key, *store_list, *store_item;
	int list_size, i, ret;
	char *key_str;

	if (js_root == NULL)
		return ESB_ERR_REG_JSON;

	/** 解析 主题 列表; subjects */
	sbj_list = cJSON_GetObjectItem(js_root, "subjects");
	if (sbj_list == NULL || sbj_list->type != cJSON_Array || cJSON_GetArraySize(sbj_list) == 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: sbj_list parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}

	list_size = cJSON_GetArraySize(sbj_list);
	conf_obj->sbjConf_array = (SubjectConf_json_t*)calloc(list_size, sizeof(SubjectConf_json_t));
	assert(conf_obj->sbjConf_array);
	conf_obj->sbj_array_cnt = list_size;

	for (i = 0; i < list_size; ++i)
	{
		sbj_item = cJSON_GetArrayItem(sbj_list, i);
		if (sbj_item == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: sbj_item NULL]\n", __FUNCTION__, __LINE__);
			return ESB_ERR_REG_JSON;
		}
		/** 进一步解析每个item，存储到 SubjectConf_json_t 对象中 */
		ret = parse_subjectConf(&conf_obj->sbjConf_array[i], sbj_item);
		if (ret < 0) {
			return ret;
		}
	}

	/** 解析 集群 列表; clusters */
	clu_list = cJSON_GetObjectItem(js_root, "clusters");
	if (clu_list == NULL || clu_list->type != cJSON_Array || cJSON_GetArraySize(clu_list) == 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: clu_list parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}

	list_size = cJSON_GetArraySize(clu_list);
	conf_obj->cluConf_array = (ClusterConf_json_t*)calloc(list_size, sizeof(ClusterConf_json_t));
	assert(conf_obj->cluConf_array);
	conf_obj->clu_array_cnt = list_size;

	for (i = 0; i < list_size; ++i)
	{
		clu_item = cJSON_GetArrayItem(clu_list, i);
		if (clu_item == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: clu_item NULL]%d of %d\n", __FUNCTION__, __LINE__, i, list_size);
			return ESB_ERR_REG_JSON;
		}
		/** 进一步解析每个item，存储到 ClusterConf_json_t 对象中 */
		ret = parse_clusterConf(&conf_obj->cluConf_array[i], clu_item);
		if (ret < 0) {
			return ret;
		}
	}

	/** 解析 key */
	key = cJSON_GetObjectItem(js_root, "key");
	if (key == NULL)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: key parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}
	key_str = key->valuestring;
	conf_obj->key = (char*)calloc(1, strlen(key_str) + 1);
	memcpy(conf_obj->key, key_str, strlen(key_str) + 1);

	/** 解析store列表 */
	store_list = cJSON_GetObjectItem(js_root, "storeIds");
	if (store_list == NULL || store_list->type != cJSON_Array || cJSON_GetArraySize(store_list) == 0) {
		// 老集群
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: store_list parse null]\n", __FUNCTION__, __LINE__);
		return 0;
	}

	list_size = cJSON_GetArraySize(store_list);
	conf_obj->storeConf_array = (StoreConf_json_t*)calloc(list_size, sizeof(StoreConf_json_t));
	assert(conf_obj->storeConf_array);
	conf_obj->store_array_cnt = list_size;

	for (i = 0; i < list_size; ++i)
	{
		store_item = cJSON_GetArrayItem(store_list, i);
		if (store_item == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: store_item NULL]%d of %d\n", __FUNCTION__, __LINE__, i, list_size);
			return ESB_ERR_REG_JSON;
		}
		/** 进一步解析每个item，存储到 StoreConf_json_t 对象中 */
		ret = parse_storeConf(&conf_obj->storeConf_array[i], store_item);
	}

	return 0;
}

/**
 * [parse_clusterConf description]
 * @param  cluConf  [description]
 * @param  clu_item [description]
 * @return          [description]
 */
int parse_clusterConf(ClusterConf_json_t *cluConf, cJSON *clu_item) {
	int i, brk_cnt;
	cJSON *clu_type, *clu_hash, *clu_version, *clu_nodes, *node;
	char *brk_addr;

	clu_type = cJSON_GetObjectItem(clu_item, "type");
	clu_hash = cJSON_GetObjectItem(clu_item, "hashCode");
	clu_version = cJSON_GetObjectItem(clu_item, "version");
	if (clu_type == NULL || clu_hash == NULL || clu_version == NULL) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: clu_item parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}

	cluConf->hashCode = clu_hash->valueint;
	cluConf->type = clu_type->valueint;
	cluConf->version = clu_version->valueint;

	clu_nodes = cJSON_GetObjectItem(clu_item, "nodes");
	if (clu_nodes == NULL || clu_nodes->type != cJSON_Array || cJSON_GetArraySize(clu_nodes) == 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: clu_nodes parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_SBJ_INIT;
	}

	brk_cnt = cJSON_GetArraySize(clu_nodes);
	cluConf->nodes = (char**)calloc(brk_cnt, sizeof(char*));
	cluConf->node_cnt = brk_cnt;
	for (i = 0; i < brk_cnt; ++i)
	{
		node = cJSON_GetArrayItem(clu_nodes, i);
		if (node == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: node item %d parse failed] %d\n", __FUNCTION__, __LINE__, i, cluConf->hashCode);
			return ESB_ERR_REG_JSON;
		}
		brk_addr = node->valuestring;
		cluConf->nodes[i] = (char*)calloc(1, strlen(brk_addr) + 1);
		memcpy(cluConf->nodes[i], brk_addr, strlen(brk_addr) + 1);
	}

	return 0;
}

/**
 * [parse_subjectConf description]
 * @param  sbjConf  [description]
 * @param  sbj_item [description]
 * @return          [description]
 */
int parse_subjectConf(SubjectConf_json_t *sbjConf, cJSON *sbj_item) {
	int i, cluster_cnt;
	cJSON *sbj_id, *cli_id, *sbj_type, *sbj_clusters, *cluster_id;

	sbj_id = cJSON_GetObjectItem(sbj_item, "name");
	cli_id = cJSON_GetObjectItem(sbj_item, "clientId");
	sbj_type = cJSON_GetObjectItem(sbj_item, "type");
	if (sbj_id == NULL || cli_id == NULL || sbj_type == NULL) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: sbj_item parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}

	sbjConf->clientId = cli_id->valueint;
	sbjConf->name = sbj_id->valueint;
	sbjConf->type = sbj_type->valueint;

	/** 解析subject对应的cluster ids */
	sbj_clusters = cJSON_GetObjectItem(sbj_item, "clusters");
	if (sbj_clusters == NULL || sbj_clusters->type != cJSON_Array || cJSON_GetArraySize(sbj_clusters) == 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: sbj_clusters parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}
	cluster_cnt = cJSON_GetArraySize(sbj_clusters);
	sbjConf->clusters = (long*)calloc(cluster_cnt, sizeof(long));
	sbjConf->clu_cnt = cluster_cnt;
	for (i = 0; i < cluster_cnt; ++i)
	{
		cluster_id = cJSON_GetArrayItem(sbj_clusters, i);
		if (cluster_id == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: sbj_clusters item %d parse failed] %d\n", __FUNCTION__, __LINE__, i, sbjConf->name);
			return ESB_ERR_REG_JSON;
		}
		sbjConf->clusters[i] = cluster_id->valueint;
	}

	return 0;
}

/**
 * [parse_storeConf description]
 * @param  storeConf  [description]
 * @param  store_item [description]
 * @return            [description]
 */
int parse_storeConf(StoreConf_json_t *storeConf, cJSON *store_item) {
	int i, node_cnt;
	cJSON *clusterId, *storeId, *store_weight, *store_type, *store_nodes, *node;
	char *brk_addr;

	clusterId = cJSON_GetObjectItem(store_item, "clusterId");
	storeId = cJSON_GetObjectItem(store_item, "storeId");
	store_weight = cJSON_GetObjectItem(store_item, "weight");
	store_nodes = cJSON_GetObjectItem(store_item, "nodes");

	if (clusterId == NULL || storeId == NULL || store_weight == NULL || store_type == NULL) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: store_item parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_REG_JSON;
	}

	storeConf->clusterId = clusterId->valuestring;
	storeConf->storeId = storeId->valueint;
	storeConf->weight = store_weight->valueint;

	if (store_nodes == NULL || store_nodes->type != cJSON_Array || cJSON_GetArraySize(store_nodes) == 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: store_nodes parse failed]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_SBJ_INIT;
	}

	node_cnt = cJSON_GetArraySize(store_nodes);
	storeConf->nodes = (char**)calloc(node_cnt, sizeof(char*));
	storeConf->node_cnt = node_cnt;

	for (i = 0; i < node_cnt; ++i)
	{
		node = cJSON_GetArrayItem(store_nodes, i);
		if (node == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: node item %d parse failed] %d\n", __FUNCTION__, __LINE__, i, storeConf->storeId);
			return ESB_ERR_REG_JSON;
		}
		brk_addr = node->valuestring;
		storeConf->nodes[i] = (char*)calloc(1, strlen(brk_addr) + 1);
		memcpy(storeConf->nodes[i], brk_addr, strlen(brk_addr) + 1);
	}

	return 0;
}

void reset_ClusterConf_json_t(ClusterConf_json_t *cluConf) {
	int i;
	if (cluConf == NULL)
		return;
	if (cluConf->nodes != NULL) {
		for (i = 0; i < cluConf->node_cnt; ++i) {
			if (cluConf->nodes[i] != NULL) {
				free(cluConf->nodes[i]);
			}
		}
		free(cluConf->nodes);
	}
}

void reset_SubjectConf_json_t(SubjectConf_json_t *sbjConf) {
	if (sbjConf == NULL)
		return;
	if (sbjConf->clusters != NULL)
		free(sbjConf->clusters);
}
