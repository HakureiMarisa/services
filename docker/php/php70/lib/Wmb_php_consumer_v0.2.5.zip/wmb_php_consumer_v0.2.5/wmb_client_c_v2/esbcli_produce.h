
#ifndef _ESBCLI_PRODUCE_H
#define _ESBCLI_PRODUCE_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "esbcli_event.h"
#include "esbcli_msg.h"
#include "esbcli_queue.h"
#include "byteConvert.h"
#include "esbcli_window_data.h"
#include "esbcli_util.h"

typedef void* (*esb_send_msg_cb)(void * msg, void * status, void * ext_arg);

#define STATUS_PUT_OK 0x00
#define STATUS_FLUSH_DISK_TIMEOUT 0x01
#define STATUS_FLUSH_SLAVE_TIMEOUT 0x02
#define STATUS_SLAVE_NOT_AVAILABLE 0x03
#define STATUS_SYSTEM_ERROR 0x04
#define STATUS_MESSAGE_ILLEGAL 0x05
#define STATUS_SERVICE_NOT_AVAILABLE  0x06
#define STATUS_UNKNOWN_ERROR 0x07
#define STATUS_SEND_TIMEOUT 0x08

#define SEND_SUCCESS 1;
#define SEND_FAILED -1;

#define ESB_DEFAULT_TIMEOUT 3000

#define ESB_MSG_FREE_SIZE 105000

/**
 * 发送msg队列
 */
typedef struct esb_send_op_s{
	/** 实现双向链表的 tailq 结构指针 */
	TAILQ_ENTRY(esb_send_op_s)		send_msg_link;
	esb_msg_t                  		*msg;
	uint32_t                    	timeout;
	uint32_t                    	start_time;
	esb_send_msg_cb              	send_cb;
}esb_send_op_t;

typedef struct esb_send_hd_s{
	ESB_mutex_t  					seq_mutex;
	/**发送序列号, 用于遍历broker*/
	uint32_t                        send_seq;
	/**非顺序发送相关*/
	ESB_mutex_t  					send_mutex;
	ESB_thread_cond_t 				send_cond;
	uint32_t   						send_list_size;
	/** 实现双向链表的 tailq 链表头结构体*/
	TAILQ_HEAD(, esb_send_op_s) 	send_op_list;
	ESB_thread_t 					*async_send_thread;

	/**顺序发送相关*/
	ESB_mutex_t  					sendq_mutex;
	ESB_thread_cond_t 				sendq_cond;
	uint32_t   						sendq_list_size;
	/**顺序消息发送队列*/
	TAILQ_HEAD(, esb_send_op_s) 	sendq_op_list;
	ESB_thread_t 					*async_sendq_thread;

	/**空闲消息实体列表*/
	TAILQ_HEAD(, esb_msg_s) 		msg_free_list;
	ESB_mutex_t  					msg_mutex;

	/**空闲消息实体列表*/
	TAILQ_HEAD(, esb_send_op_s) 	sendop_free_list;
	ESB_mutex_t  					sendop_mutex;
}esb_send_hd_t;

//void free_send_op(esb_send_op_t *send_op);

void free_send_op_tolist(void* esbcli, esb_send_op_t *send_op);

void free_send_op(esb_send_op_t *send_op);

esb_send_hd_t* new_esb_send_hd();

int getNextSendSeq(esb_send_hd_t * send_hd);

void free_esb_send_hd(esb_send_hd_t * send_hd);

void insert_free_msg(esb_send_hd_t * send_hd, esb_msg_t* msg);

esb_msg_t* get_free_msg(esb_send_hd_t * send_hd);

void insert_free_sendop(esb_send_hd_t * send_hd, esb_send_op_t *send_op);

esb_send_op_t* get_free_sendop(esb_send_hd_t * send_hd);

#endif





