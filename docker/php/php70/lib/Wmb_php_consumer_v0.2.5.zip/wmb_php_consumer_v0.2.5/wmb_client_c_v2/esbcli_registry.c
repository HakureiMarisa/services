/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <assert.h>
#include <errno.h>

#include "esbcli_registry.h"
#include "esbclient.h"
#include "cJSON.h"
#include "esbcli_util.h"
#include "esbcli_protocol.h"
#include "byteConvert.h"
#include "esbcli_version.h"


int byteCompare(char *bytePtr, char *needle, int len) {
	int i;
	for (i = 0; i < len; ++i)
	{
		if (bytePtr[i] != needle[i])
		{
			return -1;
		}
	}
	return 0;
}

void rtrim(char *s, char *trim_characters) {
	int i, j;

	for (i = strlen(s) - 1; i >= 0; --i)
	{
		for (j = 0; j < strlen(trim_characters); ++j)
		{
			if (s[i] == trim_characters[j])
			{
				s[i] = '\0';
				break;
			}
		}
		if (s[i] != '\0')
		{
			break;
		}
	}
}

int registrykeyInit(esb_registry_t *reg, char *key_path) {
	FILE * f;
	char line[1024];
	char equal[] = "=";
	char question[] = "?";
	char *tmp_keyPath, *ret_ptr, *k, *v, *f_path;

	/** 在registry对象中保存一份key_path */
	reg->key_path = (char*)calloc(1, strlen(key_path) + 1);
	memcpy(reg->key_path, key_path, strlen(key_path) + 1);

	/** 再复制一份临时变量，用于字符串截取 */
	tmp_keyPath = (char*)calloc(1, strlen(key_path) + 1);
	memcpy(tmp_keyPath, key_path, strlen(key_path) + 1);

	/** testkey.key?clientid=1 为兼容此类的key_path，需要截取“?” ,但忽略“?”之后的字符 */
	/** 截取key文件路径 */
	f_path = strtok(tmp_keyPath, question);
	if (f_path == NULL) {
		free(tmp_keyPath);
		return ESB_ERR_KPATH_ILLEGAL;
	}
	/** 截取client_id */
	// 如果有client_id,忽略

	f = fopen(f_path, "r");
	if (f == NULL) {
		free(tmp_keyPath);
		return ESB_ERR_KPATH_OPEN;
	}
	while (!feof(f)) {
		ret_ptr = fgets(line, 1024, f);
		if (ret_ptr == NULL) {
			if ( ferror(f) ) {
				fclose(f);
				free(tmp_keyPath);
				return ESB_ERR_KPATH_READ;
			} else {
				continue;
			}
		}
		rtrim(line, "\r\n\t ");

		k = strtok(line, equal);
		if (k == NULL)
			continue;
		v = strtok(NULL, equal);
		if (v == NULL)
			continue;

		if (strcmp(k, "key") == 0) {
			reg->key = (char*)malloc(strlen(v) + 1);
			/** 保存 key */
			strcpy(reg->key, v);
		} else if (strcmp(k, "registry_server_ip") == 0) {
			reg->registry_ip = (char*)malloc(strlen(v) + 1);
			/** 保存 registry_ip */
			strcpy(reg->registry_ip, v);
		} else if (strcmp(k, "registry_server_port") == 0) {
			/** 保存 registry_port */
			reg->registry_port = atoi(v);
			reg->reg_port_string = (char*)malloc(strlen(v) + 1);
			strcpy(reg->reg_port_string, v);
		} else {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: key config name unknown, key_name:%s]\n", __FUNCTION__, __LINE__, k);
			// error,what to do?
		}
	}

	fclose(f);
	free(tmp_keyPath);

	return ESB_ERR_SUCCESS;
}

void registry_reset(esb_registry_t *reg) {
	if (reg->key_path != NULL)
		{free(reg->key_path); reg->key_path = NULL;}
	if (reg->key != NULL)
		{free(reg->key); reg->key = NULL;}
	if (reg->registry_ip != NULL)
		{free(reg->registry_ip); reg->registry_ip = NULL;}
	if (reg->reg_port_string != NULL)
		{free(reg->reg_port_string); reg->reg_port_string = NULL;}
	if (reg->dns_res != NULL)
		{freeaddrinfo(reg->dns_res); reg->dns_res = NULL;}
	if (reg->reg_conf_json_str != NULL)
		{free(reg->reg_conf_json_str); reg->reg_conf_json_str = NULL;}
	if (reg->reg_json_root != NULL)
		{cJSON_Delete(reg->reg_json_root); reg->reg_json_root = NULL;}
	if (reg->reg_conf_obj != NULL)
		{free_regConf_json_t(reg->reg_conf_obj); reg->reg_conf_obj = NULL;}
}


int registryDNS_getaddrinfo(esb_registry_t * reg) {
	struct addrinfo hints, *res;
	int ret;

	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_INET;  // ip v4
	hints.ai_socktype = SOCK_STREAM;  // tcp

	ret = getaddrinfo(reg->registry_ip, reg->reg_port_string, &hints, &res);
	if (ret != 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: getaddrinfo ret]%d\n", __FUNCTION__, __LINE__, ret);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registry_ip:%s, port:%s\n", __FUNCTION__, __LINE__, reg->registry_ip, reg->reg_port_string);
		// error, what to do?
		return -1;
	}
	/** 保存DNS结果 到 reg 结构体 */
	reg->dns_res = res;
	return 0;
}

int registryConnectServer(esb_registry_t *reg) {
	int sockfd, status;
	struct sockaddr_in reg_addr;
	struct addrinfo *DNS_item;
	struct timeval tv;
	memset(&reg_addr, 0, sizeof(reg_addr) );

	status = registryDNS_getaddrinfo(reg);
	if (status < 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: registryDNS_getaddrinfo status]%d\n", __FUNCTION__, __LINE__, status);
		// DNS 解析失败
		// error,what to do?
		return -1;
	}

	for (DNS_item = reg->dns_res; DNS_item != NULL; DNS_item = DNS_item->ai_next)
	{
		sockfd = socket(PF_INET, SOCK_STREAM, 0);
		if ( sockfd == -1 ) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: socket sockfd]%d\n", __FUNCTION__, __LINE__, sockfd);
			return -1;
		}
		/** 设置读写超时 */
		tv.tv_sec = 3;
		tv.tv_usec = 0;
		setsockopt(sockfd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
		setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
		/** connect */
		status = connect(sockfd, (struct sockaddr*)DNS_item->ai_addr, sizeof(struct sockaddr) );
		if ( status == -1 )
		{
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: connect status]%d, error: %s\n", __FUNCTION__, __LINE__, status, strerror(errno));
			// error,what to do?
			close(sockfd);
			continue;
		}
		break;
	}

	/** 尝试连接多个ip都失败，退出 */
	if ( status == -1 )
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ALL_connect status]%d\n", __FUNCTION__, __LINE__, status);
		// error,what to do?
		return -1;
	}

	reg->reg_sock_fd = sockfd;
	return 0;
}

int registryReConnect(esb_registry_t * reg) {
	if (reg->dns_res != NULL) {
		{freeaddrinfo(reg->dns_res); reg->dns_res = NULL;}
	}
	if (reg->reg_sock_fd > 0) {
		{close(reg->reg_sock_fd); reg->reg_sock_fd = 0;}
	}
	return registryConnectServer(reg);
}

/**
 * [registryReportVersion description]
 * @param  reg [description]
 * @return     [description]
 */
int registryReportVersion(esb_registry_t * reg) {
	esb_registry_protocol_t * proto, *resp_proto;
	esb_string_t * sendBuff;
	esb_string_t * frameBuff;
	int ret, resStatus;
	char version_str[] = ESB_CLIENT_VERSION;
	char lang_str[] = ESB_CLIENT_LANG;
	char reg_body[127];

	esb_client_t * esbcli =  (esb_client_t*)reg->esbcli;
	if (strlen(esbcli->u_conf.external_lang_str)) {
		sprintf(reg_body, "%s&&%s/%s&&%s/%s",
		        reg->key, version_str, esbcli->u_conf.external_lang_version,
		        lang_str, esbcli->u_conf.external_lang_str);
	} else {
		sprintf(reg_body, "%s&&%s&&%s", reg->key, version_str, lang_str);
	}

	proto = new_reg_protocol(REG_OPCODE_HEARTBEAT, REG_CLIENT_HEARTBEAT, reg_body);
	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> req body]%s\n", __FUNCTION__, __LINE__, reg_body);

	sendBuff = reg_protocol_to_bytes(proto);
	/** 释放发送proto缓冲区 */
	free_reg_protocol(proto);

	ret = send(reg->reg_sock_fd, sendBuff->str, sendBuff->len, 0);
	if (ret < sendBuff->len)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: send ret]%d  %d, error: %s\n", __FUNCTION__, __LINE__, ret, sendBuff->len, strerror(errno));
		free_esb_string_t(sendBuff);
		registryReConnect(reg);
		return -1;
	}
	free_esb_string_t(sendBuff);

	frameBuff = recvFrame(reg->reg_sock_fd);
	if (frameBuff == NULL)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recvFrame NULL]\n", __FUNCTION__, __LINE__);
		registryReConnect(reg);
		return -1;
	}

	resStatus = -1;
	resp_proto = reg_protocol_from_bytes(frameBuff);
	if (resp_proto->msg_type == REG_RESPONSE_ACK && resp_proto->body != NULL)
	{
		resStatus = StreamToUint16(resp_proto->body, LITTLE_ENDIAN_ESB);
		esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> resStatus]%d\n", __FUNCTION__, __LINE__, resStatus);
	}
	if (resStatus != 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ReportVersion reponse failed]%d %d\n", __FUNCTION__, __LINE__, resp_proto->msg_type, resStatus);
	}
	/** 释放frame缓冲区 */
	free_esb_string_t(frameBuff);
	/** 释放返回proto缓冲区 */
	free_reg_protocol(resp_proto);

	return resStatus;
}

/**
 * [registryGetBrokerConf description]
 * @param  reg [description]
 * @return     [description]
 */
int registryGetBrokerConf(esb_registry_t *reg) {
	esb_registry_protocol_t  *proto, *resp_proto;
	esb_string_t * sendBuff;
	esb_string_t * frameBuff;
	int ret, retval = 0;
	cJSON *js_root;
	char *reg_body, *resp_body;

	js_root = cJSON_CreateObject();
	if (js_root == NULL)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: js_root NULL]\n", __FUNCTION__, __LINE__);
		// error,what to do?
		return -1;
	}
	cJSON_AddStringToObject(js_root, "key", reg->key);
	reg_body = cJSON_PrintUnformatted(js_root);
	cJSON_Delete(js_root);

	proto = new_reg_protocol(REG_OPCODE_CONFIG_GET, REG_REQUEST_ALL_DATAS, reg_body);
	free(reg_body);

	sendBuff = reg_protocol_to_bytes(proto);
	/** 释放发送proto缓冲区 */
	free_reg_protocol(proto);

	ret = send(reg->reg_sock_fd, sendBuff->str, sendBuff->len, 0);
	if (ret < sendBuff->len)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: send ret]%d  %d, error: %s\n", __FUNCTION__, __LINE__, ret, sendBuff->len, strerror(errno));
		// error,what to do?
		free_esb_string_t(sendBuff);
		registryReConnect(reg);
		return -1;
	}
	free_esb_string_t(sendBuff);

	frameBuff = recvFrame(reg->reg_sock_fd);
	if (frameBuff == NULL)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recvFrame NULL]\n", __FUNCTION__, __LINE__);
		// error,what to do?
		registryReConnect(reg);
		return -1;
	}

	resp_proto = reg_protocol_from_bytes(frameBuff);
	if (resp_proto->body == NULL)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: reg_protocol_from_bytes NULL]\n", __FUNCTION__, __LINE__);
		// error,what to do?
		retval = -1;
	} else {
		/** 保存body中的json数据 */
		resp_body = (char *)resp_proto->body;
		if (reg->reg_conf_json_str != NULL && strcmp(resp_body, reg->reg_conf_json_str) == 0)
		{
			// json字符串与上次相同， do nothing
			retval = 0;
		} else {
			if (reg->reg_conf_json_str != NULL)
				free(reg->reg_conf_json_str);
			if (reg->reg_json_root != NULL)
				cJSON_Delete(reg->reg_json_root);
			if (reg->reg_conf_obj != NULL)
				free_regConf_json_t(reg->reg_conf_obj);

			reg->reg_conf_json_str = (char*)calloc(1, strlen(resp_body) + 1);
			memcpy(reg->reg_conf_json_str, resp_body, strlen(resp_body) + 1);
			reg->conf_changed_flag = 1;

			retval = 0;

			esb_printf(ESB_PRINT_NOTICE, "[%s,%d-->reg config;reg_resp->body]%s\n", __FUNCTION__, __LINE__, reg->reg_conf_json_str);

			reg->reg_json_root = cJSON_Parse(reg->reg_conf_json_str);
			if (reg->reg_json_root == NULL) {
				retval = ESB_ERR_REG_JSON;
				esb_set_error(ESB_ERR_REG_JSON);
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: js_root NULL; reg_resp->body]%s\n", __FUNCTION__, __LINE__, reg->reg_conf_json_str);
			}

			/** 解析json，存入结构体中 */
			reg->reg_conf_obj = new_regConf_json_t();
			ret = parse_regConf_from_json(reg->reg_conf_obj, reg->reg_json_root);
			if (ret < 0)
			{
				esb_set_error(ret);
				return ret;
			}

		}

	}

	/** 释放frame缓冲区 */
	free_esb_string_t(frameBuff);
	/** 释放返回proto缓冲区 */
	free_reg_protocol(resp_proto);

	return retval;
}

/**
 * [recvFrame description]
 * @param  sockfd [description]
 * @return        [description]
 */
esb_string_t * recvFrame(int sockfd) {
	esb_string_t headBuff;
	char headStr[REG_HEAD_LEN + sizeof(esb_delimiter.P_START_TAG)];
	char end_delimiter[sizeof(esb_delimiter.P_END_TAG)];

	esb_string_t *frameBuff;
	int ret;
	uint32_t frame_len, body_len;

	headBuff.str = headStr;
	headBuff.len = REG_HEAD_LEN + sizeof(esb_delimiter.P_START_TAG);

	/**  先读取一个header长度的数据 */
	ret = recv(sockfd, headBuff.str, headBuff.len, MSG_WAITALL);
	if (ret < 0 || ret < headBuff.len)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recv ret < headBuff.len or 0]%d, error: %s\n", __FUNCTION__, __LINE__, ret, strerror(errno));
		// error, what to do?
		return NULL;
	}
	/** 匹配 frame 首分割串 */
	ret = byteCompare(headBuff.str, (char *)esb_delimiter.P_START_TAG, sizeof(esb_delimiter.P_START_TAG));
	if (ret == -1)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: byteCompare P_START_TAG]\n", __FUNCTION__, __LINE__);
		// error, what to do?
		return NULL;
	}

	frame_len = StreamToUint32(headBuff.str + sizeof(esb_delimiter.P_START_TAG), LITTLE_ENDIAN_ESB);
	body_len = frame_len - REG_HEAD_LEN;

	frameBuff = new_esb_string_t(frame_len);

	/** copy head */
	memcpy(frameBuff->str, headBuff.str + sizeof(esb_delimiter.P_START_TAG), REG_HEAD_LEN);
	/** read body */
	if (body_len > 0)
	{
		ret = recv(sockfd, frameBuff->str + REG_HEAD_LEN, body_len, MSG_WAITALL);
		if (ret < 0 || ret < body_len)
		{
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recv ret < body_len or 0]%d  %d  %d, error: %s\n", __FUNCTION__, __LINE__, ret, body_len, frame_len, strerror(errno));
			// error, what to do?
			free_esb_string_t(frameBuff);
			return NULL;
		}
	}
	frameBuff->len = frame_len;

	/** socket读取、匹配 frame 尾分割串  */
	ret = recv(sockfd, end_delimiter, sizeof(esb_delimiter.P_END_TAG), MSG_WAITALL);
	if (ret < 0 || ret < sizeof(esb_delimiter.P_END_TAG))
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recv ret < P_END_TAG or 0], error: %s\n", __FUNCTION__, __LINE__, ret, strerror(errno));
		// error, what to do?
		free_esb_string_t(frameBuff);
		return NULL;
	}
	ret = byteCompare(end_delimiter, (char *)esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));
	if (ret == -1)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: byteCompare P_END_TAG]\n", __FUNCTION__, __LINE__);
		//printf("[recvFrame:: byteCompare P_END_TAG] %d %d %d %d %d\n", end_delimiter[0], end_delimiter[1], end_delimiter[2], end_delimiter[3], end_delimiter[4]);
		// error, what to do?
		free_esb_string_t(frameBuff);
		return NULL;
	}

	return frameBuff;
}
