/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_THREAD_H
#define _ESBCLI_THREAD_H

#include <pthread.h>

#include <sys/syscall.h>
#define ESB_gettid() syscall(__NR_gettid)

#define ESB_mutex_t      pthread_mutex_t
#define ESB_thread_attr_t  pthread_attr_t
#define ESB_thread_t     pthread_t
#define ESB_mutexattr_t  pthread_mutexattr_t
#define ESB_thread_cond_t pthread_cond_t


int ESB_thread_create(ESB_thread_t *thread,
                      ESB_thread_attr_t *attr,
                      void * (*start_routine)(void *),
                      void * arg);

void ESB_thread_exit(void *rval_ptr);
int ESB_thread_join(ESB_thread_t thread, void **retval);

int ESB_mutex_init(ESB_mutex_t *mutex, ESB_mutexattr_t *mutexattr);
int ESB_mutex_lock(ESB_mutex_t *mutex);
int ESB_mutex_try_lock(ESB_mutex_t *mutex);
int ESB_mutex_unlock(ESB_mutex_t *mutex);
int ESB_mutex_destory(ESB_mutex_t *mutex);

int ESB_thread_cond_init(ESB_thread_cond_t *cond);
int ESB_thread_cond_wait(ESB_thread_cond_t *cond, ESB_mutex_t *mutex);
int ESB_thread_cond_broadcast(ESB_thread_cond_t *cond);
int ESB_thread_cond_destroy(ESB_thread_cond_t *cond);
int ESB_Thread_cond_timewait(ESB_thread_cond_t *cond, ESB_mutex_t *mutex, const struct timespec *abstime);
int ESB_thread_cond_signal(ESB_thread_cond_t *cond);
int ESB_thread_kill(ESB_thread_t thread, int sig);
ESB_thread_t ESB_thread_self();

#endif
