/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>

#include "esbcli_util.h"

/** 全局错误记录变量 */
int GlobleErrorRecord = ESB_ERR_SUCCESS;

/** 全局log输出级别配置 */
int GlobleLogPrintLevel = ESB_PRINT_NOTICE;

/**
 *
 */
int esb_printf(int level, const char *format, ...) {
	int ret = 0;
	va_list args;
	time_t now;
	char *level_infos[] = {
		"",  // 0
		"ERROR",  // 1 ESB_PRINT_ERROR
		"WARNING",  // 2 ESB_PRINT_WARNING
		"NOTICE",  // 3 ESB_PRINT_NOTICE
		"DEBUG",  // 4 ESB_PRINT_DEBUG
	};

	va_start(args, format);
	if (level > ESB_PRINT_DEBUG) {
		level = ESB_PRINT_WARNING;
	}

	if (level <= ESB_PRINT_WARNING || level <= GlobleLogPrintLevel)
	{
		time(&now);
		/**  */
		printf("<%s> %s       ", level_infos[level], ctime(&now));
		ret = vprintf(format, args);
		fflush(stdout);
	}

	va_end(args);
	return ret;
}

/**
 * [esb_set_error description]
 * @param errno [description]
 */
void esb_set_error(int errno) {
	GlobleErrorRecord = errno;
	return;
}

/**
 * [esb_get_globle_error_code description]
 * @return [description]
 */
int esb_get_globle_error_code() {
	return GlobleErrorRecord;
}

char * esb_get_error_info(int errno) {
	int index;
	static char *errinfos[] = {
		ESB_ERR_SUCCESS_INFO,  // 0
		ESB_ERR_REG_CONN_INFO,
		ESB_ERR_REG_CONF_INFO,
		ESB_ERR_KPATH_ILLEGAL_INFO,
		ESB_ERR_KPATH_OPEN_INFO,
		ESB_ERR_KPATH_READ_INFO, // 5
		ESB_ERR_KPATH_ADDR_INFO,
		ESB_ERR_ECLI_NULL_INFO,
		ESB_ERR_ECLI_NOBRK_INFO,
		ESB_ERR_ECLI_NEWBRK_INFO,
		ESB_ERR_BRK_ADDR_INFO,  // 10
		ESB_ERR_BRK_SOCK_INFO,
		ESB_ERR_BRK_CONN_INFO,
		ESB_ERR_BRK_SEND_INFO,
		ESB_ERR_ECLI_CLITYPE_INFO,
		ESB_ERR_REG_JSON_INFO,  // 15
		ESB_ERR_SBJ_INIT_INFO,  // 16
		ESB_ERR_CLU_NOBRK_INFO, // 17
		ESB_ERR_CLU_NOSBJ_INFO, // 18
		ESB_ERR_NO_ERR_INFO, // 19
		ESB_ERR_ECLI_ISRUNING_INFO, // 20
	};

	switch (errno) {
	case ESB_ERR_SUCCESS: index = 0; break;
	case ESB_ERR_REG_CONN: index = 1; break;
	case ESB_ERR_REG_CONF: index = 2; break;
	case ESB_ERR_KPATH_ILLEGAL: index = 3; break;
	case ESB_ERR_KPATH_OPEN: index = 4; break;
	case ESB_ERR_KPATH_READ: index = 5; break;
	case ESB_ERR_KPATH_ADDR: index = 6; break;
	case ESB_ERR_ECLI_NULL: index = 7; break;
	case ESB_ERR_ECLI_NOBRK: index = 8; break;
	case ESB_ERR_ECLI_NEWBRK: index = 9; break;
	case ESB_ERR_BRK_ADDR: index = 10; break;
	case ESB_ERR_BRK_SOCK: index = 11; break;
	case ESB_ERR_BRK_CONN: index = 12; break;
	case ESB_ERR_BRK_SEND: index = 13; break;
	case ESB_ERR_ECLI_CLITYPE: index = 14; break;
	case ESB_ERR_REG_JSON: index = 15; break;
	case ESB_ERR_SBJ_INIT: index = 16; break;
	case ESB_ERR_CLU_NOBRK: index = 17; break;
	case ESB_ERR_CLU_NOSBJ: index = 18; break;
	case ESB_ERR_ECLI_ISRUNING: index = 20; break;
	default:
		index = 19;
	}

	return errinfos[index];
}

int getlocalIp() {
	int MAXINTERFACES = 16;
	char *ip = NULL;
	int ipInt = 0;
	int fd, intrface, retn = 0;
	struct ifreq buf[MAXINTERFACES];
	struct ifconf ifc;

	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) >= 0)
	{
		ifc.ifc_len = sizeof(buf);
		ifc.ifc_buf = (caddr_t)buf;
		if (!ioctl(fd, SIOCGIFCONF, (char *)&ifc))
		{
			intrface = ifc.ifc_len / sizeof(struct ifreq);

			while (intrface-- > 0)
			{
				if (!(ioctl (fd, SIOCGIFADDR, (char *) &buf[intrface])))
				{
					ip = (inet_ntoa(((struct sockaddr_in*)(&buf[intrface].ifr_addr))->sin_addr));
					ipInt = inet_aton(ip, &(((struct sockaddr_in*)(&buf[intrface].ifr_addr))->sin_addr));
					break;
				}
			}
		}
		close (fd);
		return ipInt;
	}
	return 0;
}

int get_hashcode(char *str, int len) {
	int hash1 = 5381;
	int hash2 = hash1;
	int i = 0;
	for (i = 0; i < len; i++) {
		hash1 = ((hash1 << 5) + hash1) ^ *str;
		if (++i >= len) {
			break;
		}
		str += 1;
		hash2 = ((hash2 << 5) + hash2) ^ *str;
		str += 1;
	}
	return hash1 + (hash2 * 1566083941);
}

long get_currenttime() {
	struct timeval tv;
	long currentTimestamp, warmup_period;

	gettimeofday(&tv, NULL);
	currentTimestamp = (uint64_t)(tv.tv_sec * 1000) + (uint64_t)(tv.tv_usec / 1000);

	return currentTimestamp;
}
