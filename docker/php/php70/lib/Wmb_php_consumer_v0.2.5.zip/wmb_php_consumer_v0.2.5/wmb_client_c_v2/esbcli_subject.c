/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "esbcli_subject.h"
#include "esbcli_cluster.h"

esb_subject_t * new_esb_subject(int subject_id, int client_id, int sub_mode) {
	esb_subject_t *sbj;

	sbj = (esb_subject_t*)calloc(1, sizeof(esb_subject_t));
	assert(sbj);
	sbj->command_type = sub_mode;
	sbj->subject_id = (uint32_t)subject_id;
	sbj->client_id = (uint32_t)client_id;

	sbj->sbj_cluster_map = hash_new();

	sbj->current_cluster_key = NULL;

	ESB_mutex_init(&sbj->clu_mutex, NULL);

	sbj->sbj_clu_idx_map = hash_new();

	sbj->sbj_pro_cluster_map = hash_new();

	sbj->cluster_count = 0;
	sbj->unSub_req_retry_count = 0;
	return sbj;
}

void free_esb_subject(esb_subject_t *sbj) {
	esb_cluster_t *clu;

	if (sbj == NULL)
		return;
	if (sbj->sbj_cluster_map != NULL) {
		hash_free(sbj->sbj_cluster_map);
	}

	ESB_mutex_destory(&sbj->clu_mutex);

	if (sbj->sbj_clu_idx_map != NULL) {
		hash_each(sbj->sbj_clu_idx_map, {
			free((char*)key);
			free((char*)val);
		});

		hash_free(sbj->sbj_clu_idx_map);
	}

	if (sbj->sbj_pro_cluster_map != NULL) {
		hash_each(sbj->sbj_pro_cluster_map , {
			clu = (esb_cluster_t*)val;
			free_esb_cluster(clu);
		});
		hash_free(sbj->sbj_pro_cluster_map);
	}
	free(sbj);
}

char * get_sbj_map_key_byArg(uint32_t subject_id) {
	char *map_key;

	map_key = (char*)calloc(1, 32);
	sprintf(map_key, "%d", subject_id);

	return map_key;
}

char * get_sbj_map_key(esb_subject_t *sbj) {
	if (strlen(sbj->obj_map_key) == 0) {
		sprintf(sbj->obj_map_key, "%d", sbj->subject_id);
	}
	return sbj->obj_map_key;
}

//void subject_clu_addToMap(esb_subject_t *sbj, char *clu_key) {
//	hash_set(sbj->sbj_cluster_map, clu_key, clu_key);
//}

void add_cluster_tosbj(esb_subject_t *sbj, char *clu_key) {
	ESB_mutex_lock(&sbj->clu_mutex);
	hash_set(sbj->sbj_cluster_map, clu_key, clu_key);
	ESB_mutex_unlock(&sbj->clu_mutex);

}

void del_cluster_fromsbj(esb_subject_t *sbj, char *clu_key) {
	ESB_mutex_lock(&sbj->clu_mutex);
	hash_del(sbj->sbj_cluster_map, clu_key);
	hash_del(sbj->sbj_pro_cluster_map, clu_key);
	ESB_mutex_unlock(&sbj->clu_mutex);
}

void generate_sbj_clu_arr(esb_subject_t *sbj) {
	char *clu_key, *clu_idx;
	int size;
	int i;

	ESB_mutex_lock(&sbj->clu_mutex);
	if (sbj->sbj_clu_idx_map != NULL) {
		hash_each(sbj->sbj_clu_idx_map, {
			free((char*)key);
			free((char*)val);
		});
		hash_clear(sbj->sbj_clu_idx_map);
	}
	size = hash_size(sbj->sbj_pro_cluster_map);
	if (size > 0) {
		sbj->cluster_count = size;
		i = 0;
		hash_each(sbj->sbj_pro_cluster_map, {
			int key_len = strlen(key);
			clu_key = (char*)calloc(key_len + 5, sizeof(char));
			memcpy(clu_key, key, key_len);
			clu_idx = (char *)calloc(1, 32);
			sprintf(clu_idx, "%d", i);
			hash_set(sbj->sbj_clu_idx_map, clu_idx, clu_key);
			i++;
		});
	}
	ESB_mutex_unlock(&sbj->clu_mutex);
}
