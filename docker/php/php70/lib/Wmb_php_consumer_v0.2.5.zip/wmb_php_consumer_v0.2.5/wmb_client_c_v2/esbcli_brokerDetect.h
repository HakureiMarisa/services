#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

#include "esbcli_broker.h"
#include "esbcli_event.h"
#include "esbclient.h"
#include "esbcli_util.h"
#include "esbcli_thread.h"
#include "esbcli_protocol.h"

#ifndef _ESBCLI_CONNECT_H
#define _ESBCLI_CONNECT_H

/* delimiter_t esb_delimiter = {
	{18, 17, 13, 10, 9},
	{9, 10, 13, 17, 18}
}; */

int create_socket();

int brokerPing(esb_broker_t * brk);

int brokerDetected(esb_broker_t * brk);

void brokerStateCheck(void * arg);

#endif

