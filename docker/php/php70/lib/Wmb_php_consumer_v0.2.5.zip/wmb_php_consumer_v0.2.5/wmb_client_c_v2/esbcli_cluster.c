/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <stdlib.h>
#include <assert.h>

#include "esbcli_cluster.h"
#include "esbcli_util.h"
#include "esbcli_subject.h"
#include "esbclient.h"


esb_cluster_t * new_esb_cluster(long cluster_id, int type, long version, void *ecli) {
	esb_cluster_t *clu;

	clu = (esb_cluster_t*)calloc(1, sizeof(esb_cluster_t));
	assert(clu);
	/** 反向指针  赋值 */
	clu->esbcli = ecli;

	clu->hash_code = cluster_id;
	clu->type = type;
	clu->version = version;

	clu->clu_brk_map = hash_new();
	clu->clu_sbj_map = hash_new();

	clu->state = CLU_INIT;

	clu->current_brk = NULL;

	clu->clu_brk_idx_map = hash_new();

	clu->brk_count = 0;

	ESB_mutex_init(&clu->brk_mutex, NULL);
	return clu;
}

char * get_cluster_map_key(esb_cluster_t *clu) {
	if (strlen(clu->obj_map_key) == 0) {
		sprintf(clu->obj_map_key, "%ld", clu->hash_code);
	}
	return clu->obj_map_key;
}

char * get_cluster_map_key_byArg(long cluster_id) {
	char *cluster_key;
	cluster_key = (char*)calloc(1, 32);
	sprintf(cluster_key, "%ld", cluster_id);

	return cluster_key;
}

void cluster_sbj_addToMap(esb_cluster_t *clu, char *sbj_key) {
	hash_set(clu->clu_sbj_map, sbj_key, sbj_key);
}

void cluster_brk_addToMap(esb_cluster_t *clu, esb_broker_t *brk) {
	ESB_mutex_lock(&clu->brk_mutex);
	hash_set(clu->clu_brk_map, brk->brk_ip_port_str, brk);
	ESB_mutex_unlock(&clu->brk_mutex);
}

void cluster_brk_removeMap(esb_cluster_t *clu, esb_broker_t *brk) {
	ESB_mutex_lock(&clu->brk_mutex);
	hash_del(clu->clu_brk_map, brk->brk_ip_port_str);
	ESB_mutex_unlock(&clu->brk_mutex);
}

int cluster_has_brk(esb_cluster_t *clu, esb_broker_t *brk) {
	return hash_has(clu->clu_brk_map, brk->brk_ip_port_str);
}

void generate_clu_brk_arr(esb_cluster_t *clu) {
	char *brk_key, *brk_idx;
	int i, size;

	ESB_mutex_lock(&clu->brk_mutex);
	if (clu->clu_brk_idx_map != NULL) {
		hash_each(clu->clu_brk_idx_map, {
				free((char*)key);
				free((char*)val);
		});
		hash_clear(clu->clu_brk_idx_map);
	}
	size = hash_size(clu->clu_brk_map);
	if (size > 0) {
		clu->brk_count = size;
		i = 0;
		hash_each(clu->clu_brk_map, {
				int key_len = strlen(key);
				brk_key = (char*)calloc(key_len+5, sizeof(char));
				memcpy(brk_key, key, key_len);
				brk_idx = (char *)calloc(1,32);
				sprintf(brk_idx, "%d",i);
				hash_set(clu->clu_brk_idx_map, brk_idx, brk_key);
				i++;
		});
	}
	ESB_mutex_unlock(&clu->brk_mutex);
}

void free_esb_cluster(esb_cluster_t *clu) {
	esb_broker_t *brk;

	if (clu == NULL)
		return;
	if (clu->clu_brk_map != NULL) {
		hash_each(clu->clu_brk_map, {
			brk = (esb_broker_t*)val;
			free_esb_broker_t(brk);
		});
		hash_free(clu->clu_brk_map);
	}
	if (clu->clu_sbj_map != NULL) {
		hash_free(clu->clu_sbj_map);
	}

	ESB_mutex_destory(&clu->brk_mutex);

	if (clu->clu_brk_idx_map != NULL) {
		hash_each(clu->clu_brk_idx_map, {
				free((char*)key);
				free((char*)val);
		});
		hash_free(clu->clu_brk_idx_map);
	}
	free(clu);
}

/**
 * [cluster_start_each_broker description]
 * @param  clu [description]
 * @return     [description]
 */
int cluster_start_each_broker(esb_cluster_t *clu) {
	int ret, weight;
	esb_broker_t *brk;
	char *weightStr, *store_key;
	esb_store_t *esb_store;
	struct timeval tv;

	esb_client_t * esbclient = (esb_client_t *)clu->esbcli;
	gettimeofday(&tv, NULL);

	if (hash_size(clu->clu_brk_map) <= 0)
	{
		return ESB_ERR_CLU_NOBRK;
	}
	if (hash_size(clu->clu_sbj_map) <= 0)
	{
		return ESB_ERR_CLU_NOSBJ;
	}

	hash_each(clu->clu_brk_map, {
		brk = (esb_broker_t*)val;
		/** set broker weight*/
		if (brk->storeId != NULL) {
            hash_each(esbclient->cli_store_weight_map, {
                    esb_store = (esb_store_t*)val;
                    store_key = esb_store->store_key;
                    if (strcmp(store_key, brk->storeId) == 0) {
                            brk->storeWeight = esb_store->weight;
                            esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: broker_set_store_weight %s : %d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, brk->storeWeight);
                    }
            });
		}

		/** 状态检查 */
		if (brk->state != INIT)
			continue;
		/** 建立每个broker的tcp连接；并初始化相应的event句柄 */
		ret = brokerConnectServer(brk);
		if (ret < 0)
		{
			/** 连接失败，移除并释放broker对象 */
			cluster_brk_removeMap(clu, brk);
			free_esb_broker_t(brk);
		}

		brk->startTimestamp = (uint64_t)(tv.tv_sec * 1000) + (uint64_t)(tv.tv_usec / 1000);
	});

	/** cluster 没有成功连接的 broker，报错退出 */
	if (hash_size(clu->clu_brk_map) <= 0)
	{
		return ESB_ERR_CLU_NOBRK;
	}

	/** 更新clu状态为normal */
	clu->state = CLU_NORMAL;

	return 0;
}

/**
 * [cluster_sub_single_sbj description]
 * @param  clu [description]
 * @param  sbj [description]
 * @return     [description]
 */
int cluster_sub_single_sbj(esb_cluster_t *clu, esb_subject_t *sbj) {
	esb_broker_t *brk;
	int ret;
	char *sbj_key, *clu_key;

	hash_each(clu->clu_brk_map, {
		brk = (esb_broker_t*)val;
		ret = broker_send_subscribe_request(brk, sbj);
		if (ret < 0) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker_send_subscribe_request failed]%u\n", __FUNCTION__, __LINE__, sbj->subject_id);
			continue;
		}
		if (sbj->command_type != ESB_SBJ_CMD_TYPE_PULL || brk->state != NORMAL)
			continue;

		ret = broker_send_getQueue_request(brk, sbj);
		if (ret < 0) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker_send_getQueue_request failed]%u\n", __FUNCTION__, __LINE__, sbj->subject_id);
		}
	});

	/** 双向关联“集群”与“主题” */
	sbj_key = get_sbj_map_key(sbj);
	cluster_sbj_addToMap(clu, sbj_key);
	clu_key = get_cluster_map_key(clu);
	//subject_clu_addToMap(sbj, clu_key);
	add_cluster_tosbj(sbj, clu_key);
	generate_sbj_clu_arr(sbj);

	return 0;
}

/**
 * [cluster_unSub_single_sbj description]
 * @param  clu [description]
 * @param  sbj [description]
 * @return     [description]
 */
int cluster_unSub_single_sbj(esb_cluster_t *clu, esb_subject_t *sbj) {
	esb_broker_t *brk;
	esb_queue_t *q;
	int ret;
	char *sbj_key, *clu_key;

	hash_each(clu->clu_brk_map, {
		brk = (esb_broker_t*)val;

		/** 取消订阅 */
		ret = broker_send_unSub_request(brk, sbj);
		if (ret < 0) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker_send_unSub_request failed]%u\n", __FUNCTION__, __LINE__, sbj->subject_id);
		}

		/** 如果是“拉取”模式，停止相关queue的拉取 */
		if (sbj->command_type != ESB_SBJ_CMD_TYPE_PULL)
		{
			continue;
		}
		hash_each(brk->brk_queue_map, {
			q = (esb_queue_t*)val;
			/** 删除此subject的queue对象,以便停止后续的拉取 */
			if (q->subject_id == sbj->subject_id) {
				hash_del(brk->brk_queue_map, key);
			}
		});

	});

	/** 删除“集群”“主题”关联关系 */
	sbj_key = get_sbj_map_key(sbj);
	hash_del(clu->clu_sbj_map, sbj_key);
	clu_key = get_cluster_map_key(clu);
	//hash_del(sbj->sbj_cluster_map, clu_key);
	del_cluster_fromsbj(sbj, clu_key);

	return 0;
}

esb_broker_t * get_send_broker_with_seq(esb_cluster_t *clu, int seq, int isLocked) {
	char * brk_key, *brk_idx_s;
	esb_broker_t *broker = NULL;
	int clu_idx, brk_idx;

	if (clu == NULL || clu->brk_count <= 0) {
		return NULL;
	}

	if (isLocked) {
		ESB_mutex_lock(&clu->brk_mutex);
	}
	brk_idx_s = (char *)calloc(1,32);
	brk_idx = seq%(clu->brk_count);
	memset(brk_idx_s, 0, 32);
	sprintf(brk_idx_s, "%d", brk_idx);
	if (hash_has(clu->clu_brk_idx_map, brk_idx_s)) {
		brk_key = hash_get(clu->clu_brk_idx_map, brk_idx_s);
		broker = (esb_broker_t *)hash_get(clu->clu_brk_map, brk_key);
	}

	if (broker == NULL || broker->state != NORMAL || UNWRITABLE == broker->writable) {
		int index = (brk_idx + 1)%(clu->brk_count);
		while(index != brk_idx) {
			if(index > (clu->brk_count - 1)) {
				index = 0;
			}

			memset(brk_idx_s, 0, 32);
			sprintf(brk_idx_s, "%d", index);
			if (hash_has(clu->clu_brk_idx_map, brk_idx_s)) {
				brk_key = hash_get(clu->clu_brk_idx_map, brk_idx_s);
				broker = hash_get(clu->clu_brk_map, brk_key);
			}

			if (broker != NULL && broker->state == NORMAL && WRITABLE == broker->writable) {
				break;
			}
			index =  (index + 1) % clu->brk_count;
		}
	}
	if (isLocked) {
		ESB_mutex_unlock(&clu->brk_mutex);
	}
	free(brk_idx_s);
	return broker;
}

esb_broker_t * get_send_broker(esb_cluster_t *clu, int isLocked) {
	char * brk_key, *brk_idx_s;
	esb_broker_t *broker, *result;
	int clu_idx, brk_idx, count, total_weight, effective_weight, update_weight, i;

	broker = NULL;
	result = NULL;

	if (clu == NULL || clu->brk_count <= 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: get_send_broker NULL]%u\n", __FUNCTION__, __LINE__);
		return NULL;
	}

	if (isLocked) {
		ESB_mutex_lock(&clu->brk_mutex);
	}

	count = clu->brk_count;
	if (count == 1) {
		brk_idx_s = (char *)calloc(1, 32);
		memset(brk_idx_s, 0, 32);
		sprintf(brk_idx_s, "0");
		brk_key = hash_get(clu->clu_brk_idx_map, brk_idx_s);
		broker = hash_get(clu->clu_brk_map, brk_key);
		free(brk_idx_s);

		if (isLocked) {
			ESB_mutex_unlock(&clu->brk_mutex);
		}
		return broker;
	}

	total_weight = 0;
	for (i = 0; i < count; i++) {
		brk_idx_s = (char *)calloc(1, 32);
		memset(brk_idx_s, 0, 32);
		sprintf(brk_idx_s, "%d", i);
		if (hash_has(clu->clu_brk_idx_map, brk_idx_s)) {
			brk_key = hash_get(clu->clu_brk_idx_map, brk_idx_s);
			broker = hash_get(clu->clu_brk_map, brk_key);
		}

		if (broker == NULL || broker->state != NORMAL || UNWRITABLE == broker->writable) {
			free(brk_idx_s);
			continue;
		}

		if (iswarmup(broker)) {
			broker->effectiveWeight = warmupWeight(broker);
		}

		effective_weight = getEffectiveWeight(broker);
		if (effective_weight < 0) {
			free(brk_idx_s);
			continue;
		}

		total_weight = total_weight + effective_weight;
		update_weight = broker->currentWeight + effective_weight;
		broker->currentWeight = update_weight;

		if (result == NULL || broker->currentWeight > result->currentWeight) {
			if ( broker->state == NORMAL && WRITABLE == broker->writable) {
				result = broker;
			}
		}
		free(brk_idx_s);
	}

	if (result != NULL) {
		update_weight = (int)(result->currentWeight - total_weight);
		result->currentWeight = update_weight;
	}

	if (isLocked) {
		ESB_mutex_unlock(&clu->brk_mutex);
	}

	printf("result broker %s, current weight %d\n", result->brk_ip_port_str, result->currentWeight);

	return result;
}

esb_broker_t * get_send_sole_broker(esb_cluster_t *clu) {
	int seq;
	esb_broker_t *broker = NULL;

	if (clu == NULL || clu->brk_count <= 0) {
		return NULL;
	}

	ESB_mutex_lock(&clu->brk_mutex);
	if (clu->current_brk == NULL || cluster_has_brk(clu, clu->current_brk) <= 0
			|| NORMAL != clu->current_brk->state || UNWRITABLE == clu->current_brk->writable) {
		seq = rand() % (clu->brk_count);
		broker = get_send_broker_with_seq(clu, seq, 0);
		clu->current_brk = broker;
	}

	ESB_mutex_unlock(&clu->brk_mutex);
	return clu->current_brk;
}
