/**
 * @file   esbcli_event.h
 * @brief  对 事件驱动库（目前使用libevent） 的数据结构、方法进行封装；
 *         实现事件驱动逻辑的模块化。
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_EVENT_H
#define _ESBCLI_EVENT_H

#include <event2/event.h>
#include <event2/bufferevent.h>
#include <event2/buffer.h>
#include <event2/util.h>
#include <event2/thread.h>
#include <sys/socket.h>
#include <sys/time.h>

/**
 * 封装 libevent 的 event_base 结构
 */
//typedef struct event_base ESB_event_base_t;
#ifndef ESB_event_base_t
#define ESB_event_base_t struct event_base
#endif

/**
 * 封装 libevent 的 bufferevent 结构
 */
//typedef struct bufferevent ESB_bufferevent_t;
#ifndef ESB_bufferevent_t
#define ESB_bufferevent_t struct bufferevent
#endif

#ifndef ESB_event_t
#define ESB_event_t struct event
#endif

typedef void (*ESB_event_callback_fn)(evutil_socket_t, short, void *);

int ESB_event_assign(ESB_event_t *event, ESB_event_base_t *base,
                     evutil_socket_t fd, short what,
                     ESB_event_callback_fn cb, void *arg);

ESB_event_t *ESB_evtimer_new(ESB_event_base_t * base, ESB_event_callback_fn cb, void *arg);

int ESB_evtimer_add(ESB_event_t *ev, const struct timeval *tv);

void ESB_event_free(ESB_event_t *event);

/*事件循环控制标记：等待一次活跃事件，然后退出*/
#define ESB_EVLOOP_ONCE               EVLOOP_ONCE
/*事件循环控制标记：非阻塞控制*/
#define ESB_EVLOOP_NONBLOCK           EVLOOP_NONBLOCK
/*事件循环控制标记：无注册事件时也不退出*/
#define ESB_EVLOOP_NO_EXIT_ON_EMPTY   EVLOOP_NO_EXIT_ON_EMPTY


#define ESB_EV_TIMEOUT    EV_TIMEOUT      //0x01
#define ESB_EV_READ       EV_READ         //0x02
#define ESB_EV_WRITE      EV_WRITE        //0x04
#define ESB_EV_SIGNAL     EV_SIGNAL       //0x08
#define ESB_EV_PERSIST    EV_PERSIST      //0x10
#define ESB_EV_ET         EV_ET           //0x20


#define ESB_BEV_EVENT_READING    BEV_EVENT_READING
#define ESB_BEV_EVENT_WRITING    BEV_EVENT_WRITING
#define ESB_BEV_EVENT_ERROR      BEV_EVENT_ERROR
#define ESB_BEV_EVENT_TIMEOUT    BEV_EVENT_TIMEOUT
#define ESB_BEV_EVENT_EOF        BEV_EVENT_EOF
#define ESB_BEV_EVENT_CONNECTED  BEV_EVENT_CONNECTED


int ESB_evthread_use_pthreads();

//void ESB_event_global_shutdown();

#define ESB_evutil_socket_error_to_string  evutil_socket_error_to_string

int ESB_EVUTIL_SOCKET_ERROR();


/**
 * [ESB_event_base_new : 生成 event 事件池 句柄]
 * @return  [成功：ESB_event_base_t *；失败：NULL]
 */
ESB_event_base_t *ESB_event_base_new(void);

void ESB_event_base_free(ESB_event_base_t *base);

/**
 * [ESB_bufferevent_socket_new ： 生成基于bufferevent的连接句柄]
 * @param  base [event 事件池 句柄]
 * @param  fd   [socket句柄]
 * @return      [成功：ESB_bufferevent_t *；失败：NULL]
 */
ESB_bufferevent_t *ESB_bufferevent_socket_new(ESB_event_base_t *base);

/**
 * [ESB_bufferevent_socket_connect : 对bufferevent执行connect操作，实际建立连接]
 * @param  bufev     [bufferevent句柄]
 * @param  address [连接目标地址]
 * @param  addrlen []
 * @return         [成功：0；失败：-1]
 */
int ESB_bufferevent_socket_connect(
    ESB_bufferevent_t *bufev,
    struct sockaddr *address,
    int addrlen);

/**
 * [ESB_bufferevent_free 释放bufferevent句柄]
 * @param bufev [bufferevent句柄]
 */
void ESB_bufferevent_free(ESB_bufferevent_t *bufev);

//void socket_read_cb(bufferevent *bufev, void *arg);
//void socket_event_cb(bufferevent *bufev, short events, void *arg);

typedef void (*ESB_bufferevent_data_cb)(ESB_bufferevent_t *bufev, void *ctx);
typedef void (*ESB_bufferevent_event_cb)(ESB_bufferevent_t *bufev, short events, void *ctx);
//typedef bufferevent_data_cb ESB_bufferevent_data_cb;
//typedef bufferevent_event_cb ESB_bufferevent_event_cb;

/**
 * [ESB_bufferevent_setcb description]
 * @param bufev   [description]
 * @param readcb  [description]
 * @param writecb [description]
 * @param eventcb [description]
 * @param cbarg   [description]
 */
void ESB_bufferevent_setcb(
    ESB_bufferevent_t *bufev,
    ESB_bufferevent_data_cb readcb, ESB_bufferevent_data_cb writecb,
    ESB_bufferevent_event_cb eventcb, void *cbarg);

void ESB_bufferevent_setwatermark(ESB_bufferevent_t *bufev, short events,
	    size_t lowmark, size_t highmark);

void ESB_bufferevent_enable(ESB_bufferevent_t *bufev, short events);
void ESB_bufferevent_disable(ESB_bufferevent_t *bufev, short events);
short ESB_bufferevent_get_enabled(ESB_bufferevent_t *bufev);

int ESB_bufferevent_write(ESB_bufferevent_t *bufev,
                          const void *data, size_t size);
size_t ESB_bufferevent_read(ESB_bufferevent_t *bufev, void *data, size_t size);


void ESB_bufferevent_set_timeouts(ESB_bufferevent_t *bufev,
                                  const struct timeval *timeout_read,
                                  const struct timeval *timeout_write);

int ESB_bufferevent_get_outputbuf_length(ESB_bufferevent_t *bufev);

int ESB_event_search_word(ESB_bufferevent_t *bufev, void *what, int length);

int ESB_event_base_dispatch(ESB_event_base_t *base);






#endif
