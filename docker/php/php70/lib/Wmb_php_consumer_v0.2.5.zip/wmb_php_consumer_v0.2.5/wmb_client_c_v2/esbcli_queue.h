/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_QUEUE_H
#define _ESBCLI_QUEUE_H


#include "esbcli_event.h"
#include "esbcli_subject.h"

typedef struct esb_queue_s {
	/**zsj 已完成：修改计划添加一个抛弃状态
	 */
	int  abandon;

	void          *broker;
	char          obj_map_key[30];
	char          obj_abondan_map_key[80];
	char          glb_index_key[20];
	/** 主题ID */
	uint32_t      subject_id;
	/** 主题对象指针 */
	esb_subject_t *sbj_obj;
	/** queue id */
	uint32_t      queue_id;
	uint64_t      offset;


	/** 消费ACK */
	uint64_t      consume_offset;

	/** 已上报的消费ACK */
	uint64_t      consume_offset_commited;
	uint64_t      max_pull_version;

	uint8_t       has_removed;

	ESB_event_t   *queue_evtimer;
	//void          *timer_stub;
	uint32_t      later_ms;
	/** 上次拉取 时间戳 */
	uint64_t      pull_timestamp;
} esb_queue_t;

esb_queue_t* new_esb_queue();
void free_esb_queue(esb_queue_t *q);

char * get_queue_map_key_byArg(uint32_t subject_id, uint32_t queue_id);
char * get_queue_map_key(esb_queue_t *q);




/** 计算“全局queue索引”key，即：将q对象内存地址转化成字符串 */
void get_queue_index_key_byArg(char *keyBuf, esb_queue_t *q);
char * get_queue_index_key(esb_queue_t *q);


#endif
