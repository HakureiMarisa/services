/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_CRONTAB_H
#define _ESBCLI_CRONTAB_H

void esb_cron_thread(void * arg);

#endif