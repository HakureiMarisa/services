/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _BYTE_CONVERT_H
#define _BYTE_CONVERT_H

#include <inttypes.h>

#define BIG_ENDIAN_ESB    1
#define LITTLE_ENDIAN_ESB 2

uint16_t StreamToUint16(char *stream, int byteEndian);

uint32_t StreamToUint32(char *stream, int byteEndian);

int32_t StreamToInt32(char *stream, int byteEndian);

void Uint32ToStream(char *stream, uint32_t u32, int byteEndian);

void Int32ToStream(char *stream, int32_t i32, int byteEndian);

void Uint64ToStream(char *stream, uint64_t u64, int byteEndian);

uint64_t StreamToUint64(char *stream, int byteEndian);

uint64_t ip2long(const char* ip);

#endif
