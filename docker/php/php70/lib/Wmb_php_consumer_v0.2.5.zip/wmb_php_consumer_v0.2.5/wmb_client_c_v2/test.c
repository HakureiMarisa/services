
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct node {
	int data;
	struct node *next;
} Node, *pNode;

void func(int a[], int n) {
	pNode phead = NULL;
	for (int i = 0; i < n; i++) {
		pNode pnode = (pNode)malloc(sizeof(Node));
		pnode ->data = a[i];
		pnode ->next = NULL;
		phead = pnode;
		if (i == 0) {
			pNode pnode0 = (pNode)malloc(sizeof(Node));
			pnode0 ->data = -1;
			pnode0 ->next = NULL;
			pnode ->next = pnode0;
			printf(-1);
			continue;
		}

		pNode p = phead ->next;
		while (p != NULL) {
			if (p->data >= a[i]) {
				pNode q = p;
				p = p->next;
				free(q);
			} else {
				printf(p->data);
				pnode->next = p;
				phead = pnode;
				break;
			}
		}
	}
}

void main() {
	int a[9] = {3,6,1,4,2,3,7,5,8};
	func(a, 9);
}


