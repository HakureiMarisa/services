/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <malloc.h>
#include <string.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <assert.h>

#include "esbcli_msg.h"
#include "byteConvert.h"
#include "esbcli_protocol.h"
#include "esbcli_util.h"
#include "esbcli_thread.h"
#include "esbclient.h"
#include "esbcli_cluster.h"
#include "esbcli_subject.h"
#include "esbcli_broker.h"
#include "esbcli_produce.h"
#include "esbclient.h"

esb_msg_t * new_msg_old(void* esbcli, uint32_t subjectId, char *msg_body,
		uint32_t body_len, char *key_seq, uint32_t key_len) {
	esb_msg_t *msg;

	if (esbcli != NULL) {
		esb_client_t * esbclient = (esb_client_t *) esbcli;
		msg = get_free_msg(esbclient->send_hd);
		msg->free_type = FREE_LATER;
	} else {
		msg = (esb_msg_t *) calloc(1, sizeof(esb_msg_t));
		msg->free_type = FREE_NOW;
	}

	msg->subject = subjectId;
	msg->protocol_type = 1;
	msg->delivery_mode = 0;
	// check
	if (msg_body != NULL && body_len > 0) {
		msg->em_payload = (char *) calloc(body_len, sizeof(char));
		memcpy(msg->em_payload, msg_body, body_len);
//		free(msg_body);
	} else {
		msg->em_payload = NULL;
		body_len = 0;
	}

	msg->payload_len = body_len;
	msg->message_type = 0;
	msg->need_replay = 0;
	msg->command_type = MSG_CMD_TYPE_PUBLISH;

	/** 重试消费次数*/
	msg->reConsume_times = 0;
	/** 逻辑offset*/
	msg->logic_offset = 0;
	msg->propertiesMap = 0;
	msg->properties_Len = 0;
	msg->properties = 0;
	if (key_seq != NULL) {
		msg->sequence_id = abs(get_hashcode(key_seq, key_len));
		msg->version = 3;
	} else {
		msg->sequence_id = -1;
		msg->version = 2;
	}

	return msg;
}

esb_msg_t * new_msg(void* esbcli, uint32_t subjectId, char *msg_body,
		uint32_t body_len, char *key_seq, uint32_t key_len) {
	esb_msg_t *msg;

	if (esbcli != NULL) {
		esb_client_t * esbclient = (esb_client_t *) esbcli;
		msg = get_free_msg(esbclient->send_hd);
		msg->free_type = FREE_LATER;
	} else {
		msg = (esb_msg_t *) calloc(1, sizeof(esb_msg_t));
		msg->free_type = FREE_NOW;
	}

	msg->subject = subjectId;
	msg->protocol_type = 1;
	msg->delivery_mode = 0;
	// check
	if (msg_body != NULL && body_len > 0) {
		msg->em_payload = (char *) calloc(body_len, sizeof(char));
		memcpy(msg->em_payload, msg_body, body_len);
		free(msg_body);
	} else {
		msg->em_payload = NULL;
		body_len = 0;
	}
	assert(msg->em_payload);
	msg->payload_len = body_len;
	msg->message_type = 0;
	msg->need_replay = 0;
	msg->command_type = MSG_CMD_TYPE_PUBLISH;

	/** 重试消费次数*/
	msg->reConsume_times = 0;
	/** 逻辑offset*/
	msg->logic_offset = 0;
	msg->propertiesMap = 0;
	msg->properties_Len = 0;
	msg->properties = 0;
	if (key_seq != NULL) {
		msg->sequence_id = abs(get_hashcode(key_seq, key_len));
	} else {
		msg->sequence_id = -1;
	}
	msg->version = 5;
	return msg;
}
/**
 * 升级了msg版本之后，增加了属性map和属性string，高版本需要释放内存空间
 */
void free_esb_msg(esb_msg_t *msg) {
	if (msg == NULL) {
		return;
	}
	if (msg->version >= 5 && msg->properties != NULL){
		free(msg->properties);
		msg->properties=NULL;
	}
	if (msg->em_payload != NULL) {
		free(msg->em_payload);
		msg->em_payload=NULL;
	}
	/**
	 * modified:协议升级  清理properties propertiesMap
	 */
	if (msg->properties != NULL) {
		free(msg->properties);
		msg->properties=NULL;
	}
	if (msg->propertiesMap != NULL) {
		clearProperty(msg);
		hash_free(msg->propertiesMap);
	}
	free(msg);
}



/**
 * 复制一个esb_msg，深拷贝
 */
void copy_esb_msg(esb_msg_t *target, esb_msg_t *source) {
	memcpy(target, source, sizeof(esb_msg_t));
	target->em_payload = NULL;
	target->payload_len = 0;
	if (source->em_payload != NULL && source->payload_len > 0) {
		target->payload_len = source->payload_len;
		target->em_payload = (char *) calloc(target->payload_len, sizeof(char));
		memcpy(target->em_payload, source->em_payload, target->payload_len);
	}

	target->properties = NULL;
	
	target->properties_Len = 0;
	
	if (source->version >= 5 && source->properties != NULL && source->properties_Len > 0) {
		target->properties_Len = source->properties_Len;
		target->properties = (char *)calloc(target->properties_Len, sizeof(char));
		memcpy(target->properties, source->properties, target->properties_Len);
	}
	//version小于5时，没有属性字段，理论上不会进入该if
	if (source->version < 5 && source->properties != NULL && source->properties_Len > 0) {
		target->properties_Len = source->properties_Len;
		target->properties = (char *) calloc(target->properties_Len,
				sizeof(char));
		memcpy(target->properties, source->properties, target->properties_Len);
	}
	if (source->propertiesMap != NULL) {
		target->propertiesMap = hash_new();
		hash_each(source->propertiesMap, {
			putProperty(target->propertiesMap, key, val);
		});
	}
}

/**
 * 回收生产者的消息
 */
void free_esb_msg_tolist(void* esbcli, esb_msg_t *msg) {
	if (msg == NULL) {
		return;
	}
	if (msg->em_payload != NULL) {
		free(msg->em_payload);
		msg->em_payload==NULL;
	}

	/**
	 * modified:协议升级  清理properties propertiesMap
	 */
	if (msg->properties != NULL) {
		free(msg->properties);
	}
	if (msg->propertiesMap != NULL) {
		esb_printf(ESB_PRINT_DEBUG,"clearProperty(msg->propertiesMap)\n");		clearProperty(msg);
		hash_free(msg->propertiesMap);
	}
	memset(msg, 0, sizeof(msg));
	esb_client_t* esbclient = (esb_client_t *) esbcli;
	insert_free_msg(esbclient->send_hd, msg);
}

int esb_msg_recvFromSocket(esb_msg_t *msg, int sockfd) {
	esb_printf(ESB_PRINT_DEBUG, "执行esb_msg_recvFromSocket\n");	int ret;
	uint32_t total_len;
	char headStr[4], *ptr;
	char end_delimiter[sizeof(esb_delimiter.P_END_TAG)];
	esb_string_t *msgBuff;
	/**  先读取4个byte长度的数据，计算总长度 */
	ret = recv(sockfd, headStr, 4, 0);
	if (ret < 4) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recv ret < 4]%d\n", __FUNCTION__,
		__LINE__, ret);
		// error, what to do?
		return ESB_ERR_BRK_READ;
	}
	ptr = headStr;
	total_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	msgBuff = new_esb_string_t(total_len);
	/** 复制 4字节total len */
	memcpy(msgBuff->str, headStr, 4);
	/** 读取 剩余字节 */
	ptr = msgBuff->str + 4;
	ret = recv(sockfd, ptr, total_len - 4, 0);
	if (ret < (total_len - 4)) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: recv ret < total_len - 4]%d %d\n",
				__FUNCTION__, __LINE__, ret, total_len);
		// error, what to do?
		return ESB_ERR_BRK_READ;
	}
	/** socket读取、匹配 尾分隔符  */
	ret = recv(sockfd, end_delimiter, sizeof(esb_delimiter.P_END_TAG), 0);
	if (ret < 0 || ret < sizeof(esb_delimiter.P_END_TAG)) {
		esb_printf(ESB_PRINT_ERROR,
				"[%s,%d:: recv ret < P_END_TAG or 0], error: %s\n",
				__FUNCTION__, __LINE__, strerror(errno));
		// error, what to do?
		free_esb_string_t(msgBuff);
		return ESB_ERR_BRK_READ;
	}
	ret = byteCompare(end_delimiter, (char *) esb_delimiter.P_END_TAG,
			sizeof(esb_delimiter.P_END_TAG));
	if (ret == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: byteCompare P_END_TAG failed]\n",
				__FUNCTION__, __LINE__);
		// error, what to do?
		free_esb_string_t(msgBuff);
		return -1;
	}
	/** 解析、填充msg结构 */
	ret = esb_msg_fromBytes(msg, msgBuff->str);
	free_esb_string_t(msgBuff);
	if (ret < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_msg_fromBytes failed, ret:%d]\n",
				__FUNCTION__, __LINE__, ret);
		return ret;
	}
	return 0;
}
/**
 * 旧版的反序列化，当新版测试通过后废弃
 */
int esb_msg_fromBytes_old(esb_msg_t *msg, void *buf) {
	char *ptr = (char *) buf;
	int msg_header_lence = MSG_HEADER_LEN_V2;

	msg->total_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;

	msg->version = (uint8_t) (*ptr);
	ptr += 1;
	if (msg->version == 3) {
		msg_header_lence = MSG_HEADER_LEN_V3;
	} else if (msg->version == 5)
	{
		msg_header_lence = MSG_HEADER_LEN_V5;
	}
	if (msg->total_len < msg_header_lence) {
		return -1;
	}
	msg->command_type = (uint8_t) (*ptr);
	ptr += 1;
	msg->protocol_type = (uint8_t) (*ptr);
	ptr += 1;
	msg->subject = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	msg->message_id = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	msg->session_id = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	msg->message_type = (uint8_t) (*ptr);
	ptr += 1;
	msg->delivery_mode = (uint8_t) (*ptr);
	ptr += 1;
	msg->client_id = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	msg->need_replay = (uint8_t) (*ptr);
	ptr += 1;
	msg->ip = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	msg->timestamp = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	if (msg->version >= 3)
	{
		msg->sequence_id = StreamToInt32(ptr, LITTLE_ENDIAN_ESB);
		ptr += 4;
	}
	if (msg->version >= 5)
	{
		msg->reConsume_times = (uint8_t)(*ptr);
		ptr += 1;
		msg->logic_offset = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
		ptr += 8;
		msg->properties_Len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
		ptr += 4;
		if (msg->properties_Len > 0)
		{
			msg->properties = calloc(1, msg->properties_Len);
			memcpy(msg->properties, ptr, msg->properties_Len);
			ptr += msg->properties_Len;
		}
	}

	/** 保存消息实体 */
	msg->payload_len = msg->total_len - msg_header_lence;
	if (msg->version >= 5 && msg->properties_Len > 0)
	{
		msg->payload_len -= msg->properties_Len;
	}
	if (msg->payload_len > 0)
	{
		/** 申请动态内存，注意及时释放 */
		msg->em_payload = calloc(1, msg->payload_len);
		assert(msg->em_payload);
		/** 复制 payload 数据 */
		memcpy(msg->em_payload, ptr, msg->payload_len);
		ptr += msg->payload_len;
	}
	return msg->total_len;
}

/**
 * 新版消息反序列化
 */
int esb_msg_fromBytes(esb_msg_t *msg, void *buf) {
	//这些非共有变量 应当事先初始化
	msg->reConsume_times = 0;
	/** 逻辑offset*/
	msg->logic_offset = 0;
	/** 属性map的长度*/
	msg->properties_Len = 0;
	/** 属性map生成的字符串*/
	msg->properties = 0;
	msg->propertiesMap = 0;

	char *ptr = (char *) buf;
	int msg_header_lence = 0;

	msg->total_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;

	msg->version = (uint8_t) (*ptr);
	ptr += 1;
	esb_printf(ESB_PRINT_DEBUG, "反序列化msg--协议版本:%d\n", msg->version);
	if (msg->version <= 2) {
		msg_header_lence = MSG_HEADER_LEN_V2;
	} else if (msg->version == 3) {
		msg_header_lence = MSG_HEADER_LEN_V3;
	} else if (msg->version == 4) {
		msg_header_lence = MSG_HEADER_LEN_V4;
	} else if (msg->version == 5) {
		msg_header_lence = MSG_HEADER_LEN_V5;
	}

	if (msg->total_len < msg_header_lence) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_msg_fromBytes total_len %d < msg_header_lence %d]\n",
				__FUNCTION__, __LINE__, msg->total_len, msg_header_lence);
		return -1;
	}
	msg->command_type = (uint8_t) (*ptr);
	ptr += 1;
	msg->protocol_type = (uint8_t) (*ptr);
	ptr += 1;
	msg->subject = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	msg->message_id = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	msg->session_id = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	msg->message_type = (uint8_t) (*ptr);
	ptr += 1;
	msg->delivery_mode = (uint8_t) (*ptr);
	ptr += 1;
	msg->client_id = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	msg->need_replay = (uint8_t) (*ptr);
	ptr += 1;
	msg->ip = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	msg->timestamp = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;

	if (msg->version == 3 || msg->version == 4 || msg->version == 5) {
		msg->sequence_id = StreamToInt32(ptr, LITTLE_ENDIAN_ESB);
		ptr += 4;
	}
	if (msg->version == 5) {
		msg->reConsume_times = (uint8_t) (*ptr);
		ptr += 1;
		msg->logic_offset = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
		ptr += 8;
	}
	if (msg->version == 4 || msg->version == 5) {
		msg->properties_Len = StreamToInt32(ptr, LITTLE_ENDIAN_ESB);
		ptr += 4;
		if (msg->properties_Len > 0) {
			/** 申请动态内存，注意及时释放 */
			msg->properties = calloc(1, msg->properties_Len + 1);
			assert(msg->properties);
			/** 复制 properties 数据 */
			memcpy(msg->properties, ptr, msg->properties_Len);
			((char*) msg->properties)[msg->properties_Len] = '\0';
			string2messageProperties(msg, msg->properties, msg->properties_Len);
		}
		ptr += msg->properties_Len;
	}

	/** 保存消息实体 */

	if (msg->version == 4 || msg->version == 5) {
		msg->payload_len = msg->total_len - msg_header_lence
				- msg->properties_Len;
	} else {
		msg->payload_len = msg->total_len - msg_header_lence;
	}

	if (msg->payload_len > 0) {
		/** 申请动态内存，注意及时释放 */
		msg->em_payload = calloc(1, msg->payload_len + 1);
		assert(msg->em_payload);
		/** 复制 payload 数据 */
		memcpy(msg->em_payload, ptr, msg->payload_len);
		((char*) msg->em_payload)[msg->payload_len] = '\0';
		int i = 0;
	}
	return msg->total_len;
}

//旧版序列化
esb_string_t * esb_msg_toBytes_old(esb_msg_t *msg) {
	esb_string_t * final_byte;
	int frame_len;
	char *ptr;
	int msg_header_lence = MSG_HEADER_LEN_V2;

	if (msg->version == 3) {
		msg_header_lence = MSG_HEADER_LEN_V3;
	} else if (msg->version == 5)
	{
		msg_header_lence = MSG_HEADER_LEN_V5;
	}

	msg->total_len = msg_header_lence + msg->payload_len;
	if (msg->version >= 5 && msg->properties_Len > 0)
	{
		msg->total_len += msg->properties_Len;
	}
	frame_len = msg->total_len + sizeof(esb_delimiter.P_END_TAG);

	final_byte = new_esb_string_t(frame_len);

	ptr = final_byte->str;
	/** 总长度 */
	Uint32ToStream(ptr, msg->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char) msg->version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char) msg->command_type;
	ptr += 1;
	/** 协议类型 */
	ptr[0] = (char) msg->protocol_type;
	ptr += 1;
	/** 主题 id */
	Uint32ToStream(ptr, msg->subject, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 消息id */
	Uint64ToStream(ptr, msg->message_id, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** session id */
	Uint64ToStream(ptr, msg->session_id, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** message_type */
	ptr[0] = (char) msg->message_type;
	ptr += 1;
	/** delivery_mode */
	ptr[0] = (char) msg->delivery_mode;
	ptr += 1;
	/** client_id */
	Uint32ToStream(ptr, msg->client_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** need_replay */
	ptr[0] = (char) msg->need_replay;
	ptr += 1;
	/** 客户端IP */
	Uint32ToStream(ptr, msg->ip, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** timestamp */
	Uint64ToStream(ptr, msg->timestamp, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** sequence_id (V3) */
	if (msg->version >= 3) {
		Int32ToStream(ptr, msg->sequence_id, LITTLE_ENDIAN_ESB);
		ptr += 4;
	}
	if (msg->version >= 5) {
		/** reConsume_times */
		ptr[0] = (char)msg->reConsume_times;
		ptr += 1;
		/** logic_offset */
		Uint64ToStream(ptr, msg->logic_offset, LITTLE_ENDIAN_ESB);
		ptr += 8;
		/** properties_Len */
		Uint32ToStream(ptr, msg->properties_Len, LITTLE_ENDIAN_ESB);
		ptr += 4;
		/** properties */
		if (msg->properties_Len > 0)
		{
			memcpy(ptr, msg->properties, msg->properties_Len);
			ptr += msg->properties_Len;
		}
	}
	/** em_payload */
	if (msg->payload_len > 0) {
		memcpy(ptr, msg->em_payload, msg->payload_len);
		ptr += msg->payload_len;

	}
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));

	return final_byte;
}

//新版序列化
esb_string_t * esb_msg_toBytes(esb_msg_t *msg) {
	esb_string_t * final_byte;
	int frame_len;
	char *ptr;
	int msg_header_lence;
	if (msg->version == 2) {
		msg_header_lence = MSG_HEADER_LEN_V2;
	} else if (msg->version == 3) {
		msg_header_lence = MSG_HEADER_LEN_V3;
	} else if (msg->version == 4) {
		/*放前头以防万一*/
		properties2String(msg);
		msg_header_lence = MSG_HEADER_LEN_V4;
	} else if (msg->version == 5) {
		/*放前头以防万一*/
		properties2String(msg);
		msg_header_lence = MSG_HEADER_LEN_V5;
	}

	msg->total_len = msg_header_lence + msg->properties_Len + msg->payload_len;

	frame_len = msg->total_len + sizeof(esb_delimiter.P_END_TAG);

	final_byte = new_esb_string_t(frame_len);

	ptr = final_byte->str;
	/** 总长度 */
	Uint32ToStream(ptr, msg->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char) msg->version;
	ptr += 1;

	/** 消息类型 */
	ptr[0] = (char) msg->command_type;
	ptr += 1;

	/** 协议类型 */
	ptr[0] = (char) msg->protocol_type;
	ptr += 1;
	/** 主题 id */
	Uint32ToStream(ptr, msg->subject, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 消息id */
	Uint64ToStream(ptr, msg->message_id, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** session id */
	Uint64ToStream(ptr, msg->session_id, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** message_type */
	ptr[0] = (char) msg->message_type;
	ptr += 1;
	/** delivery_mode */
	ptr[0] = (char) msg->delivery_mode;
	ptr += 1;
	/** client_id */
	Uint32ToStream(ptr, msg->client_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** need_replay */
	ptr[0] = (char) msg->need_replay;
	ptr += 1;
	/** 客户端IP */
	Uint32ToStream(ptr, msg->ip, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** timestamp */
	Uint64ToStream(ptr, msg->timestamp, LITTLE_ENDIAN_ESB);
	ptr += 8;

	/** 指定版本，避免后续增加版本带来麻烦 */
	if (msg->version == 3 || msg->version == 4 || msg->version == 5) {
		Int32ToStream(ptr, msg->sequence_id, LITTLE_ENDIAN_ESB);
		ptr += 4;
	}
	if (msg->version == 5) {
		/** reConsume_times */
		ptr[0] = (char) msg->reConsume_times;
		ptr += 1;
		/** LogicOffset */
		Uint64ToStream(ptr, msg->logic_offset, LITTLE_ENDIAN_ESB);
		ptr += 8;
	}
	if (msg->version == 4 || msg->version == 5) {
		/** properties_Len */
		Uint32ToStream(ptr, msg->properties_Len, LITTLE_ENDIAN_ESB);
		ptr += 4;
		if (msg->properties_Len > 0) {
			memcpy(ptr, msg->properties, msg->properties_Len);
			ptr += msg->properties_Len;
		}
	}
	if (msg->payload_len > 0) {
		memcpy(ptr, msg->em_payload, msg->payload_len);
		ptr += msg->payload_len;

	}
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));
	return final_byte;
}

//新版释放函数
void resetMsg_and_freePayload(esb_msg_t *msg) {
	if (msg == NULL)
		return;
	if (msg->properties != NULL) {
			free(msg->properties);
			msg->properties=NULL;
		}
	if (msg->propertiesMap != NULL) {
		clearProperty(msg);
		hash_free(msg->propertiesMap);
	}
	if (msg->em_payload != NULL) {
		free(msg->em_payload);
		msg->em_payload=NULL;
	}
	memset(msg, 0, sizeof(esb_msg_t));
	return;
}

//旧版释放函数
void resetMsg_and_freePayload_old(esb_msg_t *msg) {
	if (msg == NULL)
		return;
	if (msg->em_payload != NULL) {
		free(msg->em_payload);
	}
	/**
	 * modified:协议升级  清理properties propertiesMap
	 */
	if (msg->properties != NULL) {
		free(msg->properties);
	}
	if (msg->propertiesMap != NULL) {
		clearProperty(msg);
		hash_free(msg->propertiesMap);
	}
	memset(msg, 0, sizeof(esb_msg_t));
	return;
}

void msg_setBody(esb_msg_t *msg, char *body, int body_len) {
	if (body != NULL && body_len > 0) {
		msg->em_payload = (char *) calloc(body_len, sizeof(char));
		memcpy(msg->em_payload, body, body_len);
	} else {
		msg->em_payload = NULL;
	}
	assert(msg->em_payload);
	msg->payload_len = body_len;
}

char* msg_getBody(esb_msg_t *msg) {
	return (char*) msg->em_payload;
}

void msg_initArg(esb_msg_t *msg, uint32_t subject, uint32_t client_id) {
	struct timeval tv;
	msg->version = 2;
	msg->command_type = 0;
	msg->protocol_type = 1;
	msg->subject = subject;
	/** 生成 msg id */
	//msg->message_id = 100100;
	msg->session_id = session_id_generator();
	msg->client_id = client_id;
	gettimeofday(&tv, NULL);
	msg->timestamp = tv.tv_sec;
}

void msg_setProtocolType(esb_msg_t *msg, uint8_t protocol_type) {
	msg->protocol_type = protocol_type;
}

void msg_setCommandType(esb_msg_t *msg, uint8_t command_type) {
	msg->command_type = command_type;
}

void msg_setVersion(esb_msg_t *msg, uint8_t version) {
	msg->version = version;
}

/**
 * [esb_msg_decode_andInsertLocalQ 从buf字节流中解码msg，存入 local msg queue 链表]
 * @param esbcli []
 * @param buf    []
 */
int esb_msg_decode_andInsertLocalQ(void *ecli,void *queue,uint32_t qid, void *buf, uint64_t pull_version, char *q_index_key) {
	esb_msgq_t *local_msgq, *local_msgq_free;
	esb_msg_t *empty_msg;
	esb_queue_t *esbqueue;
	int msg_byte_num, free_cnt;
	esb_client_t *esbcli;
	esbcli = (esb_client_t*) ecli;
	esbqueue = (esb_queue_t *)queue;
	local_msgq = &esbcli->local_msgq;
	local_msgq_free = &esbcli->local_msgq_free;
	/** 从空闲链表头部，摘取一个msg对象 */
	empty_msg = NULL;
	while (empty_msg == NULL) {
		ESB_mutex_lock(&local_msgq_free->mutex);
		if (local_msgq_free->cnt > 0) {
			empty_msg = TAILQ_FIRST(&local_msgq_free->emq_msgs);
			TAILQ_REMOVE(&local_msgq_free->emq_msgs, empty_msg, em_link);
			local_msgq_free->cnt -= 1;
			free_cnt = local_msgq_free->cnt;
		} else {
			/** "空闲链表为空",thread进入"等待" */
			ESB_thread_cond_wait(&local_msgq_free->emp_cond,
					&local_msgq_free->mutex);
		}
		ESB_mutex_unlock(&local_msgq_free->mutex);
		/** 检查空闲链表余量，触发push控制 */
		esb_check_localQ_pushCtl(ecli, free_cnt);
	}

	/** 解析消息参数及内容，写入msg对象 */
	msg_byte_num = esb_msg_fromBytes(empty_msg, buf);
	/** 在消息内部，记录pull version */
	empty_msg->pull_version = pull_version;

	/*
	 * zsj 已完成：修改计划在消息体内加入来源queue的指针
	 */
	empty_msg->queue = esbqueue;
	empty_msg->qid = qid;

	/** 在消息内部，存储queue对象的index key */
	if (q_index_key != NULL) {
		memcpy(empty_msg->queue_index_key, q_index_key, strlen(q_index_key) + 1);
	}

	/** 将msg对象，插入 待处理msg链表 头部，准备抛给上层callback函数 */
	ESB_mutex_lock(&local_msgq->mutex);
	TAILQ_INSERT_TAIL(&local_msgq->emq_msgs, empty_msg, em_link);
	local_msgq->cnt += 1;
	if (local_msgq->cnt == 1) {
		ESB_thread_cond_broadcast(&local_msgq->emp_cond);
	}
	ESB_mutex_unlock(&local_msgq->mutex);
	return msg_byte_num;
}

void esb_check_localQ_pushCtl(void *ecli, int localQ_free_cnt) {
	int localQ_total;
	esb_client_t *esbcli;
	esbcli = (esb_client_t*) ecli;
	localQ_total = esbcli->u_conf.local_msg_queue_len;
	if (((float) localQ_free_cnt / (float) localQ_total) < 0.3
			&& esbcli->consume_pause_flag != 1) {
		esbcli->consume_pause_flag = 1;
		esb_printf(ESB_PRINT_NOTICE,
				"[%s,%d--> pushControl PUSHCTL_TYPE_STOP!] %d/%d\n",
				__FUNCTION__, __LINE__, localQ_free_cnt, localQ_total);
		/** 暂停push推送 */
		esb_send_pushCtl_for_sbj(esbcli, PUSHCTL_TYPE_STOP);
	} else if (((float) localQ_free_cnt / (float) localQ_total) > 0.7
			&& esbcli->consume_pause_flag == 1) {
		esbcli->consume_pause_flag = 0;
		esb_printf(ESB_PRINT_NOTICE,
				"[%s,%d--> pushControl PUSHCTL_TYPE_START!] %d/%d\n",
				__FUNCTION__, __LINE__, localQ_free_cnt, localQ_total);
		/** 继续push推送 */
		esb_send_pushCtl_for_sbj(esbcli, PUSHCTL_TYPE_START);
	}
}

void esb_send_pushCtl_for_sbj(void *ecli, int pushCtl_type) {
	esb_subject_t *sbj;
	esb_cluster_t *clu;
	esb_broker_t *brk;
	char *clu_key;
	int ret;
	esb_client_t *esbcli;
	esbcli = (esb_client_t*) ecli;
	/** 遍历每个主题sbj */
	hash_each(esbcli->cli_sbj_map,
			{ sbj = (esb_subject_t*)val;
			/** 跳过“拉取”模式的主题 */
			if (sbj->command_type != ESB_SBJ_CMD_TYPE_PUSH) { continue; }
			/** 遍历sbj的每个集群clu */
			hash_each(sbj->sbj_cluster_map, { clu_key = key; clu = (esb_cluster_t*)hash_get(esbcli->cli_cluster_map, clu_key); if (clu == NULL) continue;
			/** 遍历每个clu的主机brk */
			hash_each(clu->clu_brk_map, { brk = (esb_broker_t*)val;
			/** 发送“推送控制”请求 */
			ret = broker_send_pushControl_request(brk, sbj, pushCtl_type); if (ret < 0) {
			/** 重试一次 */
			broker_send_pushControl_request(brk, sbj, pushCtl_type); } }); }); });
}

/**
 * auth:zhuangshaojing   Date:2017.09.30
 * 升级协议，新增接口
 *
 * clearProperty:清空整个属性map，包括key，val指向的地址空间
 * delProperty:删除属性
 * deep_cp:复制一份源数据
 * setDelayLevel:属性map中put delay信息，深拷贝
 * setDelayLevel_enum:属性map中put delay信息，深拷贝
 * setKeys:属性map中put keys信息，深拷贝
 * putProperty:设置属性值
 * getProperty:得到属性值
 * properties2String:属性map序列化成字符串
 * string2messageProperties:字符串反序列化成属性map
 */

void clearProperty(esb_msg_t *msg) {
	if (msg->propertiesMap != NULL) {
		hash_each(msg->propertiesMap,
				{
				free(key); free(val);
				 });
	} else {
	}
}

void delProperty(esb_msg_t *msg, const char* const name) {
	if (NULL != msg->propertiesMap) {
		char *val=getProperty(msg, name);
		char *key = hash_get_key(msg->propertiesMap, name);
		hash_del(msg->propertiesMap, (char*) key);
		free(key);free(val);
	}
}

char* deep_cp(const char* const source, int len) {
	char* target = (char*) calloc(1, len);
	memcpy(target, source, len);
	return target;
}


/**
 * 若改变了key，超过了25的长度，会造成越界访问
 */
void setDelayLevel(esb_msg_t *msg, int level) {
	char string[25]; //退出则消失
	sprintf(string, "%d", level);
	putProperty(msg, PROPERTY_DELAY_LEVEL, string);
}

/**
 * 延迟消费等级设置
 */
void setDelayLevel_enum(esb_msg_t *msg, DelayLevel delaylevel) {
	char string[25]; //退出则消失
	sprintf(string, "%d", delaylevel);
	putProperty(msg, PROPERTY_DELAY_LEVEL, string);
}
/**
 * 对msg属性map设置键值对
 */
void setKeys(esb_msg_t *msg, const char* keys) {
	putProperty(msg, PROPERTY_KEYS, keys);
}

/**
 * 更新msg属性map的内容，需考虑内存释放和申请，重复key等
 */
void putProperty(esb_msg_t *msg, const char* const name,
		const char* const value) {
	if (NULL == msg->propertiesMap) {
		msg->propertiesMap = hash_new();
	}
	char* val = deep_cp(value, strlen(value) + 1);
	char* oldval = getProperty(msg, name);
	char *oldkey = hash_get_key(msg->propertiesMap, name);
	if (oldval != NULL) {
		free(oldval);
		hash_set(msg->propertiesMap, oldkey, val);
		return;
	}
	char* key = deep_cp(name, strlen(name) + 1);
	hash_set(msg->propertiesMap, key, val);
}

/**
 * 查询msg属性map的键值
 */
char* getProperty(esb_msg_t *msg, const char* const name) {
	if (NULL == msg->propertiesMap) {
		msg->propertiesMap = hash_new();
	}
	return (char*) hash_get(msg->propertiesMap, (char*) name);
}

/**
 * msg属性map序列化生成字符串
 */
void properties2String(esb_msg_t *msg) {
	uint32_t length = 0;
	char* ptr;
	char* start;
	if (msg->properties != NULL) {
		free(msg->properties);
	}
	if (msg->propertiesMap != NULL) {
		hash_each(msg->propertiesMap,
				{ length+= strlen(key)+strlen(NAME_VALUE_SEPARATOR)+strlen((char*)val)+strlen(PROPERTY_SEPARATOR); });
		start = (char *) calloc(1, length + 1);
		ptr = start;
		hash_each(msg->propertiesMap,
				{ memcpy(ptr, key, strlen(key)); ptr += strlen(key); memcpy(ptr, NAME_VALUE_SEPARATOR, strlen(NAME_VALUE_SEPARATOR)); ptr += strlen(NAME_VALUE_SEPARATOR); memcpy(ptr, val, strlen((char*)val)); ptr += strlen((char*)val); memcpy(ptr, PROPERTY_SEPARATOR, strlen(PROPERTY_SEPARATOR)); ptr += strlen(PROPERTY_SEPARATOR); });
		ptr = '\0';
		msg->properties = start;
		msg->properties_Len = length;
	} else {
		msg->properties_Len = 0;
	}
}
/**
 * 字符串反序列化生成msg属性map
 */
void string2messageProperties(esb_msg_t *msg, const char* const properties,
		uint32_t properties_Len) {
	if (msg->propertiesMap == NULL) {
		msg->propertiesMap = hash_new();
	}

	if (properties != NULL) {
		uint32_t i = 0;
		uint32_t k = 0;
		char str[properties_Len + 1];
		for (; i < properties_Len; i++) {
			str[i] = properties[i];
		}
		str[properties_Len] = '\0';
		char *ptr;
		char *p;
		ptr = strtok_r(str, PROPERTY_SEPARATOR, &p);
		while (ptr != NULL) {
			char *p2;
			char *kptr = strtok_r(ptr, NAME_VALUE_SEPARATOR, &p2);
			char *vptr = strtok_r(NULL, NAME_VALUE_SEPARATOR, &p2);
			putProperty(msg, kptr, vptr);
			ptr = strtok_r(NULL, PROPERTY_SEPARATOR, &p);
		}
	}
}
