/**
 * @file
 * @brief
 *
 * @auth 58ganji - Liu Dan
 */

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "esbcli_store.h"

esb_store_t * new_esb_store(char* store_key, uint32_t weight, void *ecli) {
	esb_store_t *esb_store;

	esb_store = (esb_store_t*)calloc(1, sizeof(esb_store_t));
	esb_store->store_key = (char*)calloc(1, 64);
	memcpy(esb_store->store_key, store_key, 64);
	esb_store->weight = weight;
	esb_store->esbcli = ecli;

	return esb_store;
}

void free_esb_store(esb_store_t *store) {
	if(store == NULL) {
		return;
	}

	if (store->store_key != NULL) {
		free(store->store_key);
	}
	free(store);
}
