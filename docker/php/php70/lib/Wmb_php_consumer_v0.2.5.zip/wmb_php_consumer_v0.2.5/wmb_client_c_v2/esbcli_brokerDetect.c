#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <sys/ioctl.h>
#include "esbcli_broker.h"
#include "esbcli_event.h"
#include "esbclient.h"
#include "esbcli_util.h"
#include "esbcli_thread.h"
#include "esbcli_protocol.h"
#include "esbcli_msg.h"

int create_socket() {
	int fd, ret;
	fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (-1 == fd) {
		//error log
		return -1;
	}
	int keepalive = 1;
	ret = setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &keepalive, sizeof(int));
	if (0 != ret) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: setsockopt KEEPALIVE failed:%s]\n", __FUNCTION__, __LINE__, strerror(errno));
		close(fd);
		return ESB_ERR_BRK_SOCK;
	}
	return fd;
}

int brokerPing(esb_broker_t * brk) {
	struct sockaddr_in brk_addr;
	memset(&brk_addr, 0, sizeof(brk_addr));
	int status;

	if (brk->closable == 1 && brk->broker_close_flag == 1) {
		return ESB_ERR_BRK_CONN;
	}

	brk_addr.sin_family = AF_INET;
	brk_addr.sin_port = htons(brk->broker_port);
	status = inet_aton(brk->broker_ip, &brk_addr.sin_addr);
	if (status == 0)
	{
		esb_set_error(ESB_ERR_BRK_ADDR);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: inet_aton status = 0, broker ip %s]\n", __FUNCTION__, __LINE__, brk->broker_ip);
		return ESB_ERR_BRK_ADDR;
	}

	int fd = create_socket();
	if (fd < 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: brokerPing create socket failed]\n",
				__FUNCTION__, __LINE__);
		return ESB_ERR_BRK_SOCK;
	}

	struct timeval tv;
	tv.tv_sec = 2;
	tv.tv_usec = 0;
	setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	status = connect(fd, (struct sockaddr*)&brk_addr, sizeof(struct sockaddr));
	if (status == -1)
	{
		esb_set_error(ESB_ERR_BRK_CONN);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: connect status = -1, error : %s]\n", __FUNCTION__, __LINE__, strerror(errno));
		close(fd);
		return ESB_ERR_BRK_CONN;
	}

	esb_msg_t   msg_toSend;
	memset(&msg_toSend, 0, sizeof(esb_msg_t));
	msg_setCommandType(&msg_toSend, MSG_CMD_TYPE_CLICHECK);
	msg_setProtocolType(&msg_toSend, 1);
	msg_setVersion(&msg_toSend, 2);
	esb_string_t *sendBytes;
	/** 序列化msg对象，并在尾部加上“尾分隔符” */
	sendBytes = esb_msg_toBytes(&msg_toSend);

	/** 发送字节流到socket */
	status = send(fd, sendBytes->str, sendBytes->len, 0);
	if (status < sendBytes->len)
	{
		esb_set_error(ESB_ERR_BRK_SEND);
		esb_printf(ESB_PRINT_ERROR, "[%s,%d::  connect send status < sendBytes->len]%d  %d, error : %s\n", __FUNCTION__, __LINE__, status, sendBytes->len, strerror(errno));
		free_esb_string_t(sendBytes);
		resetMsg_and_freePayload(&msg_toSend);
		close(fd);
		return ESB_ERR_BRK_SEND;
	}
	free_esb_string_t(sendBytes);
	resetMsg_and_freePayload(&msg_toSend);

	/** 读取返回msg */
	esb_msg_t   msg_toRecv;
	memset(&msg_toRecv, 0, sizeof(esb_msg_t));
	status = esb_msg_recvFromSocket(&msg_toRecv, fd);
	close(fd);
	if (status < 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_msg_recvFromSocket failed, status:%d]\n",
				__FUNCTION__, __LINE__, status);
		resetMsg_and_freePayload(&msg_toRecv);
		return status;
	}

	int pingResult = -1;
	if (msg_toRecv.command_type == MSG_CMD_TYPE_CHECK_OK) {
		/** 返回 broker 状态恢复正常，重新初始化broker连接 */
		status = brokerConnectServer(brk);
		if (status < 0) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: connect brk failed %s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
			close(fd);
			return ESB_ERR_BRK_CONN;
		}
		brk->state = NORMAL;
		/** 成功、返回0 */
		pingResult = 0;
	}
	resetMsg_and_freePayload(&msg_toRecv);
	return pingResult;
}

void brokerDetected(void * brk) {
	esb_broker_t *broker = (esb_broker_t *) brk ;
	while (1) {
		int ret = brokerPing(broker);
		if (ret == 0) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: broker detect success! brk:%s]\n", __FUNCTION__, __LINE__, broker->brk_ip_port_str);
			/** 探测成功，退出 */
			break;
		}

		if (ret == ESB_ERR_BRK_ADDR || (broker->closable == 1 && broker->broker_close_flag == 1)) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: broker detect failed, maybe deleted.! brk:%s]\n", __FUNCTION__, __LINE__, broker->brk_ip_port_str);
			break;
		}

		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: broker detect not success yet, continue after 5 sec! brk:%s]\n", __FUNCTION__, __LINE__, broker->brk_ip_port_str);

		/** 尚未成功，稍后继续 */
		sleep(5);
	}
	free(broker->state_checker_thread);
	broker->state_checker_thread = NULL;
}

void brokerStateCheck(esb_broker_t * brk) {
	/** 释放bufferevent句柄 */
	if (brk->state == NORMAL) {
		ESB_mutex_lock(&brk->brk_check_mutex);
//		if ( brk->bev != NULL) {
//			ESB_bufferevent_free(brk->bev);
//			brk->bev = NULL;
//		}

		if (brk->state == NORMAL) {
			esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: broker state check %s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
			brk->state = TESTING;
			brk->state_checker_thread = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));
			/** 启动检测broker状态 线程 */
			int times=3;
			while(times){
				if(ESB_thread_create(brk->state_checker_thread, NULL, (void*)&brokerDetected, brk)==0){
					break;
				}
				--times;
			}
			if(times<=0){
					esb_printf(ESB_PRINT_NOTICE, "brokerDetected------thread create fail, retry times:3");
			}
		}
		ESB_mutex_unlock(&brk->brk_check_mutex);
	}
}
