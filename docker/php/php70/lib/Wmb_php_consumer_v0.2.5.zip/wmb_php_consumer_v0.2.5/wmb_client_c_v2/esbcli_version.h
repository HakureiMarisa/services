/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_VERSION_H
#define _ESBCLI_VERSION_H


#define ESB_CLIENT_VERSION "[WMB-Client] 0.3.1"
#define ESB_CLIENT_LANG "C"


#endif
