/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_PROTOCOL_H
#define _ESBCLI_PROTOCOL_H

#include <sys/time.h>
#include <unistd.h>
#include <inttypes.h>

#include "esbcli_event.h"
#include "esbcli_queue.h"

/**
 * 协议分割符
 */
typedef struct delimiter_s {
	/** 首分割标记 {18, 17, 13, 10, 9} */
	uint8_t const    P_START_TAG[5];
	/** 尾分割标记 {9, 10, 13, 17, 18} */
	uint8_t const    P_END_TAG[5];
} delimiter_t;

//delimiter_t esb_delimiter = {
//	{18, 17, 13, 10, 9},
//	{9, 10, 13, 17, 18}
//};
extern delimiter_t esb_delimiter;


typedef struct esb_string_s {
	int32_t len;
	char * str;  /* points into data[] or other memory,* not NULL-terminated */
} esb_string_t;

esb_string_t * new_esb_string_t(int maxlen);
void free_esb_string_t(esb_string_t *target);


/** registry 相关的 msg type定义 */
#define REG_RESPONSE_NO_CHANGE 0x00
#define REG_RESPONSE_ALL_DATAS_SUCCESS  0x01
#define REG_RESPONSE_HAS_CHANGE  0x02
#define REG_RESPONSE_ERROR  0x03
#define REG_RESPONSE_ALL_DATAS_ERROR  0x04
#define REG_RESPONSE_ACK  0x05
#define REG_REQUEST_VALIDATION  0x00
#define REG_REQUEST_ALL_DATAS  0x01
#define REG_REQUEST_HEARTBEAT  0x05
#define REG_REQUEST_VERIFY_ACK  0x09
#define REG_PUSH_ALL_DATAS  0x06
#define REG_PUSH_CHANGED_SERVER  0x07
#define REG_CLIENT_HEARTBEAT  0x08
#define REG_CONSUME_BACK  0x10
/** registry 相关的 op code 定义 */
#define REG_OPCODE_CONFIG_GET 0x00
#define REG_OPCODE_CONFIG_PUSH 0x01
#define REG_OPCODE_HEARTBEAT 0x02
#define REG_OPCODE_SERVER_VERIFY 0x03
#define REG_OPCODE_SERVER_CONSUMEBACK 0x04

#define REG_HEAD_LEN 15


/**********************************
 *  registry 相关定义、声明
 *
 *********************************/

typedef struct esb_registry_protocol_s {
	/** 协议头长度 */
	uint32_t   header_len;
	/** 总长度 [length:4] */
	uint32_t   total_len;
	/** 版本 [length:1] */
	uint8_t    version;
	/** 操作码 [length:1] */
	uint8_t    opaque;
	/** 请求的请求类型或响应的结果类型；用于快速处理 [length:1] */
	uint8_t    msg_type;
	/**sessionID [length:8]*/
	uint64_t   session_id;
	/** 二进制的数据实体 [length = total_len - header_len] */
	void      *body;
} esb_registry_protocol_t;

esb_registry_protocol_t * new_reg_protocol(uint8_t opaque, uint8_t msg_type, char *body);
void free_reg_protocol(esb_registry_protocol_t * proto);
esb_registry_protocol_t * reg_protocol_from_bytes(esb_string_t * buf);
esb_string_t * reg_protocol_to_bytes(esb_registry_protocol_t * proto);



#define CMD_TYPE_UNSUB      0
#define CMD_TYPE_PULLREQ    1
#define CMD_TYPE_GETQUEUE   2
#define CMD_TYPE_HEARTBEAT  3
#define CMD_TYPE_PUSHCTRL   4
#define CMD_TYPE_COMMIT_OFFSET   5

#define PROTO_TYPE_MSG   1
#define PROTO_TYPE_SUBJ  2   /** 老的订阅协议 */
#define PROTO_TYPE_REQ   3
#define PROTO_TYPE_RESP  4
#define PROTO_TYPE_SUBS  5   /** 新的订阅协议 */

#define CURR_PROTO_REQ_VERSION  1
#define CURR_PULL_REQ_VERSION  2

#define RESP_STATUS_SUCCESS       0
#define RESP_STATUS_FAILED        1
#define RESP_STATUS_FOUND         2
#define RESP_STATUS_NOT_FOUND     3
#define RESP_STATUS_ACK_OFFSET_OK 4
#define RESP_STATUS_REFUSED       5
#define RESP_STATUS_ADJUSTING     6
#define RESP_STATUS_CONSUMEBACK   7

#define FLAG_CONSUMEBACK  0x00000001

#define REQUEST_HEAD_LEN 27
#define RESPONSE_HEAD_LEN 28
#define HEARTBEAT_REQ_HEAD_LEN 15

/**********************************
 *  request 相关定义、声明
 *
 *********************************/

typedef struct esb_request_s {
	/** 总长度 [length:4] */
	uint32_t   total_len;
	/** 版本 [length:1] */
	uint8_t    version;
	/** 0取消订阅 1 拉取请求 2 拉取队列 3心跳 4推送控制 */
	uint8_t    command_type;
	/** 1:ESBMessage 2:ESBSubject_old 3:ESBRequest 4:ESBResponse 5:ESBSubject_new */
	uint8_t    protocol_type;
	/** 主题 [length:4] */
	uint32_t   subject;
	/** 客户端ID [length:4] */
	uint32_t   client_id;
	/** 请求序列号 */
	uint64_t   opaque;
	/** 标记 */
	uint32_t   flag;
	/** 二进制的数据实体 [] */
	//void      *body;
} esb_request_t;

void init_esb_request(esb_request_t *req, uint32_t total_len, uint32_t command_type,
                      uint32_t subject_id, uint32_t client_id, uint64_t opaque, uint32_t flag);
void free_esb_request(esb_request_t *req);
esb_request_t * new_getQueue_request(uint32_t subject, uint32_t client_id);
esb_request_t * new_unSub_request(uint32_t subject, uint32_t client_id);
esb_string_t * esb_request_toBytes(esb_request_t *req);
void esb_request_fillBytes(esb_request_t *req, esb_string_t *req_str);
esb_request_t * new_heartBeat_request();
esb_string_t * heartBeat_request_toBytes(esb_request_t *hbreq);

typedef struct esb_pull_request_s {
	/** 基础request结构 */
	esb_request_t base_request;
	/** 拉取的队列id */
	uint32_t   queue_id;
	/** 拉取的offset */
	uint64_t   next_offset;
	/** 本次拉取的最大消息数 */
	uint32_t   pull_num;
	/** 目前已经被消费处理的offset（用于 消费ACK 功能） */
	uint64_t   consume_offset;
} esb_pull_request_t;

void free_pull_request(esb_pull_request_t *pullreq);
//esb_pull_request_t * new_pull_request(esb_pull_request_t *pullreq, uint32_t subject,
//                                      uint32_t client_id, uint32_t queue_id,
//                                      uint64_t offset, uint32_t max_pull);
esb_pull_request_t * new_pull_request(esb_pull_request_t *pullreq, uint32_t subject,
                                      uint32_t client_id, uint32_t queue_id,
                                      uint64_t offset, uint32_t max_pull, uint64_t consume_ack);
esb_string_t * pull_request_toBytes(esb_pull_request_t *pullreq);

#define PUSHCTL_TYPE_STOP  1
#define PUSHCTL_TYPE_START 0

typedef struct esb_pushCtl_request_s {
	/** 基础request结构 */
	esb_request_t base_request;
	/** 1:停止推送  0:允许推送 */
	int8_t        type;
} esb_pushCtl_request_t;

esb_pushCtl_request_t * new_pushCtl_request(int type, uint32_t subject_id, uint32_t client_id);

esb_string_t * pushCtl_request_toBytes(esb_pushCtl_request_t *pushCtlReq);

/**********************************
 *  response 相关定义、声明
 *
 *********************************/

typedef struct esb_response_s {
	/** 总长度 [length:4] */
	uint32_t   total_len;
	/** 版本 [length:1] */
	uint8_t    version;
	/**0取消订阅 1 拉取请求  2 拉取队列*/
	uint8_t    command_type;
	/** 1:ESBMessage 2:ESBSubject_old 3:ESBRequest 4:ESBResponse 5:ESBSubject_new */
	uint8_t    protocol_type;
	/** 主题 [length:4] */
	uint32_t   subject;
	/** 客户端ID [length:4] */
	uint32_t   client_id;
	/** 请求序列号 */
	uint64_t   opaque;
	/** 标记 */
	uint32_t   flag;
	/**状态码*/
	uint8_t    status;
	/** 二进制的数据实体 [] */
	void      *body;
} esb_response_t;

void esb_response_fromBytes(esb_response_t * resp, esb_string_t * buf);
void esb_heartBeat_resp_fromBytes(esb_response_t * resp, esb_string_t * buf);

typedef struct esb_getQueue_response_s {
	/** 基础resp结构实例 */
	esb_response_t  base_resp;
	/** 队列列表 */
	esb_queue_t   **queues;
	/** 队列个数 */
	int             q_count;
} esb_getQueue_response_t;

esb_getQueue_response_t * new_esb_getQueue_response();
void free_esb_getQueue_response(esb_getQueue_response_t * qresp);
esb_getQueue_response_t * getQueue_response_fromBytes(esb_string_t * buf);


typedef struct esb_pull_response_s {
	/** 基础resp结构实例 */
	esb_response_t  base_resp;
	/**  */
	uint32_t queue_id;
	/**  */
	uint64_t next_offset;
	/**  */
	uint64_t pull_version;
	/**  */
	//void * msgs;
} esb_pull_response_t;


/**********************************
 *  session 相关定义、声明
 *
 *********************************/
//uint64_t session_counter = 0;
uint64_t session_id_generator();



#define SUB_TYPE_PUSH  -1
#define SUB_TYPE_PULL   1
#define SUB_TYPE_UNSUB  0

#define SUBJECT_HEAD_LEN 22
#define SUBSCRI_HEAD_LEN 7


/**********************************
 *  subject protocol 相关定义、声明
 *
 *********************************/

typedef struct esb_sbj_proto_s {
	/** 总长度 [length:4] */
	uint32_t   total_len;
	/** 版本 [length:1] */
	uint8_t    version;
	/** -1推送模式, 0取消订阅, 1拉取模式 */
	int8_t     command_type;
	/** 主题 [length:4] */
	uint32_t   subject;
	/** 客户端ID [length:4] */
	uint32_t   client_id;
	/** 订阅消息的起始时间 [length:8] */
	uint64_t   start_time;
} esb_sbj_proto_t;

#define SUB_CURR_VERSION  2    // 为支持pull ack模式，升级esb_sbj_proto_t 的 version 为 2

esb_sbj_proto_t * new_esb_sbj_proto(int8_t sub_type, uint32_t subject, uint32_t client_id);
void free_esb_sbj_proto(esb_sbj_proto_t *sbj);

typedef struct esb_subscribe_protocol_s {
	/** 总长度 [length:4] */
	uint32_t   total_len;
	/** 版本 [length:1] */
	uint8_t    version;
	/** 消息属性(-1订阅)暂没用,为了与发送消息协议保持一致 */
	int8_t     command_type;
	/** 1:ESBMessage 2:ESBSubject_old 3:ESBRequest 4:ESBResponse 5:ESBSubject_new */
	uint8_t    protocol_type;
	/** 二进制的数据实体，包含多个sbj_proto的字节流数据 [] */
	void      *body;
} esb_subscribe_protocol_t;

esb_subscribe_protocol_t * new_esb_subscribe_protocol();
void free_esb_subscribe_protocol(esb_subscribe_protocol_t *subscr);
esb_string_t * pack_subscribe_subject_toByte(esb_sbj_proto_t *sbj, int sbj_cnt);



typedef struct esb_commit_offset_request_s {
	/** 基础request结构 */
	esb_request_t base_request;
	/** 拉取的队列id */
	uint32_t   queue_id;
	/** 目前已经被消费处理的offset（用于 消费ACK 功能） */
	uint64_t   consume_offset;
} esb_commit_offset_request_t;

esb_string_t * commit_offset_request_toBytes(esb_commit_offset_request_t *commitreq);
esb_commit_offset_request_t * new_commit_offset_request(esb_commit_offset_request_t *commitreq, uint32_t subject,uint32_t client_id, uint32_t queue_id, uint64_t consume_ack);
#endif
