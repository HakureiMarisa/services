/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */
#ifndef _ESBCLI_MSG_H
#define _ESBCLI_MSG_H

#include <inttypes.h>

#include "linkQueue.h"
#include "esbcli_thread.h"
#include "esbcli_protocol.h"


#define MAX_RECONSUME_TIMES 5


#define MSG_HEADER_LEN_V2 46
#define MSG_HEADER_LEN_V3 50
#define MSG_HEADER_LEN_V2 46
#define MSG_HEADER_LEN_V3 50
#define MSG_HEADER_LEN_V4 54
#define MSG_HEADER_LEN_V5 63


#define PROPERTY_KEYS  "KEYS"
#define NAME_VALUE_SEPARATOR  "!"
#define PROPERTY_SEPARATOR  "^"
#define PROPERTY_DELAY_LEVEL  "DELAY_LEVEL"


#define MSG_CMD_TYPE_PUBLISH   0
#define MSG_CMD_TYPE_ACK       7
#define MSG_CMD_TYPE_PUSH      2
#define MSG_CMD_TYPE_REPUB     3
#define MSG_CMD_TYPE_REBOOT    4
#define MSG_CMD_TYPE_CLICHECK  5
#define MSG_CMD_TYPE_CHECK_OK  6
#define MSG_CMD_TYPE_RECONSUME 8


typedef enum {
	FREE_LATER = 0,  //不可写的状态
	FREE_NOW = 1,
} esb_msg_free_type;

/**
 * esb client msg 消息结构.
 */
typedef struct esb_msg_s {
	/* 实现双向链表的 tailq 结构指针*/
	TAILQ_ENTRY(esb_msg_s)  em_link;

	/** 字节流总长度 [length:4] */
	uint32_t   total_len;
	/** 版本 [length:1] */
	uint8_t    version;
	/**消息属性 :
	 * 0发布者发送;
	 * 1推送发送者ACK应答;
	 * 2推送订阅者;
	 * 3发布者重发;
	 * 4服务器reboot时返回客户端;
	 * 5客户端探测;
	 * 6服务器返回探测成功;
	 * */
	uint8_t    command_type;
	/** 1:ESBMessage 2:ESBSubject */
	uint8_t    protocol_type;
	/** 主题 [length:4] */
	uint32_t   subject;
	/** 消息id [length:8] */
	uint64_t   message_id;
	/**sessionID[length:8]*/
	uint64_t   session_id;
	/** 消息类型(0持久化类型;1非持久化类型) */
	uint8_t    message_type;
	/** 投递方式[length:1] */
	uint8_t    delivery_mode;
	/** 客户端ID [length:4] */
	uint32_t   client_id;
	/** 是否需要回应(0不需要，1需要) */
	uint8_t    need_replay;
	/** 客户端IP */
	uint32_t   ip;
	/** 时间戳 */
	uint64_t   timestamp;
	/** 相同sequence_id 的消息会被发送到固定server的固定queue; 默认值：-1 */
	int32_t    sequence_id;
	/** 重试消费次数 */
	uint8_t    reConsume_times;
	/** 逻辑offset */
	uint64_t   logic_offset;
	/** 属性map的长度 */
	uint32_t   properties_Len;

	/** 重试消费次数     reConsumeTimes*/
	/** 逻辑offset    logicOffset*/
	/** 属性map的长度    propertiesLen*/

	/** 属性map生成的字符串*/
	void *properties;
	hash_t *propertiesMap;



	/** 消息内容-body */
	void      *em_payload;
	/** 消息内容长度 */
	uint32_t   payload_len;

	esb_msg_free_type  free_type;

	/**
	 * zsj 已完成：修改计划，增加记录来源queue字段
	 */
	esb_queue_t* queue;
	uint32_t qid;


	char       queue_index_key[20];
	uint64_t   pull_version;
} esb_msg_t;


/**
 * auth:zhuangshaojing   Date:2017.09.30
 * 升级协议，新增延时枚举类
 */
typedef enum {
	DELAY_1S = 1,
	DELAY_5S = 2,
	DELAY_10S = 3,
	DELAY_20S = 4,
	DELAY_30S = 5,

	DELAY_1M = 6,
	DELAY_2M = 7,
	DELAY_5M = 8,
	DELAY_10M = 9,
	DELAY_20M = 10,
	DELAY_30M = 11,

	DELAY_1H = 12,
	DELAY_2H = 13,
	DELAY_12H = 14,

	DELAY_1D = 15,
	DELAY_2D = 16,
} DelayLevel;


esb_msg_t * new_msg(void* esbcli, uint32_t subjectId, char *msg_body, uint32_t body_len, char *key_seq, uint32_t key_len);
esb_msg_t * new_msg_old(void* esbcli, uint32_t subjectId, char *msg_body,
		uint32_t body_len, char *key_seq, uint32_t key_len);
void free_esb_msg(esb_msg_t *msg);

void copy_esb_msg(esb_msg_t *target, esb_msg_t *source);

void free_esb_msg_tolist(void* esbcli, esb_msg_t *msg);

int esb_msg_recvFromSocket(esb_msg_t *msg, int sockfd);

int esb_msg_fromBytes_old(esb_msg_t *msg, void *buf);
int esb_msg_fromBytes(esb_msg_t *msg, void *buf);
esb_string_t * esb_msg_toBytes(esb_msg_t *msg);
void resetMsg_and_freePayload(esb_msg_t *msg);
void resetMsg_and_freePayload_old(esb_msg_t *msg);
void msg_setBody(esb_msg_t *msg, char *body, int body_len);
char* msg_getBody(esb_msg_t *msg);
void msg_initArg(esb_msg_t *msg, uint32_t subject, uint32_t client_id);
void msg_setCommandType(esb_msg_t *msg, uint8_t   command_type);
void msg_setProtocolType(esb_msg_t *msg, uint8_t   protocol_type);
void msg_setVersion(esb_msg_t *msg, uint8_t   version);

//int esb_msg_decode_andInsertLocalQ(void *ecli,void *ebrk,uint32_t qid, void *buf, uint64_t pull_version, char *q_index_key);
int esb_msg_decode_andInsertLocalQ(void *ecli,void *queue,uint32_t qid, void *buf, uint64_t pull_version, char *q_index_key);

void esb_check_localQ_pushCtl(void *ecli, int localQ_free_cnt);
void esb_send_pushCtl_for_sbj(void *ecli, int pushCtl_type);


/**
 * auth:zhuangshaojing   Date:2017.09.30
 * 升级协议，新增接口
 *
 * clearProperty:清空整个属性map，包括key，val指向的地址空间
 * setDelayLevel:属性map中put delay信息，深拷贝
 * setDelayLevel_enum:属性map中put delay信息，深拷贝
 * setKeys:属性map中put keys信息，深拷贝
 * putProperty:
 */

/**
 * Function: clearProperty
 * Description: 清空esb_msg对象的，整个属性map
 * Input: esb_msg_t *msg 实例对象的指针
 * Other: free属性map中的所有key，val
 */
void clearProperty(esb_msg_t *msg);

/**
 * Function: setDelayLevel
 * Description: 向esb_msg对象的的属性map中添加 属性--延时
 * Input: esb_msg_t *msg 实例对象的指针,仅修改属性map
 *		  int level 局部变量，延时级别(十进制数)，被转化为对应的char*存放于属性map
 * Calls:delProperty
 */
void setDelayLevel(esb_msg_t *msg, int level);

/**
 * Function: setDelayLevel_enum
 * Description: 向esb_msg对象的的属性map中添加 属性--延时
 * Input: esb_msg_t *msg 实例对象的指针,仅修改属性map
 *		  DelayLevel delaylevel 局部变量，延时级别(枚举类型)，被转化为对应的char*存放于属性map
 * Calls:putProperty
 */
void setDelayLevel_enum(esb_msg_t *msg, DelayLevel delaylevel);

/**
 * Function: setKeys
 * Description: 向esb_msg对象的的属性map中添加 属性--keys
 * Input: esb_msg_t *msg 实例对象的指针,仅修改属性map
 *		  const char* const keys 指针变量，拷贝的数据源，底层const承诺不改变用户数据
 * Calls:putProperty
 */
void setKeys(esb_msg_t *msg, const char* const keys);

/**
 * Function: putProperty
 * Description: 向esb_msg对象的的属性map中添加 属性--key:name val:value
 * Input: esb_msg_t *msg 实例对象的指针,仅修改属性map
 *		  const char* const name 指针变量，拷贝的数据源，底层const承诺不改变用户数据
 *		  const char* const value 指针变量，拷贝的数据源，底层const承诺不改变用户数据
 * Other:malloc对象key，val,并put在msg的属性map中
 */
void putProperty(esb_msg_t *msg, const char* const name,
		const char* const value);


/**
 * Function: free_esb_msg
 * Description: 释放msg实例
 */
void free_esb_msg(esb_msg_t *msg);


/**
 * Function: deep_cp
 * Description: malloc对象，长度len，并将source的内容写入对象中
 * Input: const char* const source 指针变量，深拷贝的数据源，底层const承诺不改变用户数据
 *		  len 数据源长度
 */
char* deep_cp(const char* const source, int len);

/**
 * Function: delProperty
 * Description: msg的属性map中移除 key，并释放key所指向的地址空间
 * Input: const char* const name 指针变量，key，底层const承诺不改变用户数据
 *		  len 数据源长度
 */
void delProperty(esb_msg_t *msg, const char* const name);

/**
 * Function: getProperty
 * Description: msg的属性map中getkey
 * Input: const char* const name 指针变量，key，底层const承诺不改变用户数据
 * Return: key对应的value
 */
char* getProperty(esb_msg_t *msg, const char* const name);

/**
 * Function: string2messageProperties
 * Description: 将序列化字段反序列化成msg的属性map
 * Input: const char* const properties，key，底层const承诺不改变用户数据
 */
void string2messageProperties(esb_msg_t *msg, const char* const properties,
		uint32_t properties_Len);

/**
 * Function: properties2String
 * Description: 将msg的属性map序列化并存到字段中
 * Input: const char* const properties，key，底层const承诺不改变用户数据
 */
void properties2String(esb_msg_t *msg);


/**
 * esb 消息本地队列（local msg queue）.
 * base: doubly-linked list 双向链表.
 */
typedef struct esb_msgq_s {
	/** 实现双向链表的 tailq 链表头结构体*/
	TAILQ_HEAD(, esb_msg_s) emq_msgs;
	/** 链表元素个数 */
	uint32_t    cnt;
	/**  */
	ESB_mutex_t        mutex;
	ESB_thread_cond_t  emp_cond;
} esb_msgq_t;


#endif
