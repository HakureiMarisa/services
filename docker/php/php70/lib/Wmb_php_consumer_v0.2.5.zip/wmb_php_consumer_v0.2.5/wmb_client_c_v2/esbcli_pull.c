/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "esbcli_event.h"
#include "esbcli_pull.h"
#include "byteConvert.h"
#include "hash.h"
#include "esbclient.h"
#include "esbcli_util.h"
#include "esbcli_subject.h"


void esb_pull_response_fromBytes(esb_pull_response_t *pullresp,
                                 esb_string_t * buf,
                                 esb_broker_t * brk) {
	char *ptr, *q_key, queue_index_key[20];
	int   msgbytes_len, remain_len, mtotal_len, ret_num;
	uint8_t command_type;
	esb_queue_t *queue;

	esb_response_fromBytes(&(pullresp->base_resp), buf);

	ptr = buf->str + RESPONSE_HEAD_LEN;
	pullresp->queue_id = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	pullresp->next_offset = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	msgbytes_len = pullresp->base_resp.total_len - RESPONSE_HEAD_LEN - (4 + 8);
	if (pullresp->base_resp.version > 1)
	{
		pullresp->pull_version = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
		ptr += 8;
		msgbytes_len -= 8;
	}
	if (msgbytes_len <= 0) {
		return;
	}

	/** 先从map找到queue对象 */
	q_key = get_queue_map_key_byArg(pullresp->base_resp.subject, pullresp->queue_id);
	queue = (esb_queue_t*)hash_get(brk->brk_queue_map, q_key);
	free(q_key);
	if (queue == NULL || queue->has_removed == 1)
	{
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: queue not found or removed]sbj:%u|q_no:%u\n", __FUNCTION__, __LINE__, pullresp->base_resp.subject, pullresp->queue_id);
		memset(queue_index_key, 0, sizeof(queue_index_key));
		return;
	} else {
		// 记录queue的 最大pull version
		queue->max_pull_version = pullresp->pull_version;
		// 获得 queue_index_key
		get_queue_index_key_byArg(queue_index_key, queue);
	}


	/** 解析多条消息，并插入待处理消息链表 */
	remain_len = msgbytes_len;
	while (remain_len > 0) {
		mtotal_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
		//esb_printf(ESB_PRINT_DEBUG, "[esb_pull_response_fromBytes--> get one msg, mtotal_len:]%d\n", mtotal_len);
		if (mtotal_len < MSG_HEADER_LEN_V2) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: msg frame error]%d\n", __FUNCTION__, __LINE__, mtotal_len);
			break;
		}

		command_type = (uint8_t)ptr[5];
		if (command_type == MSG_CMD_TYPE_REBOOT)
		{
			/** 服务端重启，准备关闭broker对象 */
			brk->broker_close_flag = 1;
			brk->unSub_resp_rcv_flag = 1;
			ret_num = mtotal_len;
			goto Next;
		}


		/**
		 * zsj 已完成：修改计划，把队列指针带入msg实体中储存
		 * 注意事项：queue实例不可以被释放，否则反向指针解引用时将产生段错误
		 */
		ret_num = esb_msg_decode_andInsertLocalQ(brk->esbcli,queue,queue->queue_id, ptr, pullresp->pull_version, queue_index_key);

		/**  */
Next:	ptr += ret_num;
		remain_len -= ret_num;
	}

	return;
}


void esb_pullMsgLater_callback(int sock, short which, void *arg) {
	esb_request_stub_t *my_stub;
	esb_queue_t *queue;
	esb_broker_t *brk;
	esb_client_t *esbcli;

	//my_stub = (esb_request_stub_t*)arg;
	queue = (esb_queue_t*)arg;
	brk = (esb_broker_t*)queue->broker;
	esbcli = (esb_client_t*)brk->esbcli;

	/** 当前为“暂停消费”状态,不再推迟“拉取”,依然发起拉取请求 */
	if (esbcli->consume_pause_flag == 1 && esbcli->esbcli_close_flag != 1 && GlobleExitFlag != 1) {

	}
	if (brk->broker_close_flag == 1) {
		return;
	}
	//zsj 已完成：抛弃状态下，判断最新的offset是否提交
	if(queue->abandon!=0&&queue->consume_offset>=queue->consume_offset_commited){
		return;
	}

	broker_pullMsg_for_queue(brk, queue->sbj_obj, queue->queue_id, queue->offset, 0);
}

void esb_pull_msg_later(esb_queue_t *queue) {
	struct timeval tv;
	ESB_event_t *ev;
	//esb_request_stub_t *queue_stub;

	ev = queue->queue_evtimer;
	//queue_stub = (esb_request_stub_t*)queue->timer_stub;
	//queue_stub->next_offset = queue->offset;

	//memcpy(queue_stub, req_stub, sizeof(esb_request_stub_t));
	//ret = ESB_event_assign(ev, esbcli->esb_evbase, -1, 0, esb_pullMsgLater_callback, my_stub);
	if (queue->later_ms == 0)
		queue->later_ms = 30;  // min 30 ms
	if (queue->later_ms < 120)
		queue->later_ms += 10; // max 120 ms

	tv.tv_sec = 0;
	tv.tv_usec = queue->later_ms  * 1000;
	ESB_evtimer_add(ev, &tv);
}

void esb_pull_msg_delay_nSec(esb_queue_t *queue) {
	struct timeval tv;
	ESB_event_t *ev;

	ev = queue->queue_evtimer;
	tv.tv_sec = 0;  // 秒
	tv.tv_usec = 10 * 1000;

	ESB_evtimer_add(ev, &tv);
}

/**
 * [esb_pull_check_status description]
 * @param pullresp [description]
 * @param req_stub [description]
 * @param bufev    [description]
 * @param brk      [description]
 */
void esb_pull_check_status(esb_pull_response_t *pullresp, esb_broker_t *brk) {
	uint32_t queue_id;
	uint64_t next_offset;
	esb_queue_t *queue;
	esb_request_stub_t *req_stub;
	char *stub_key;
	esb_client_t *esbcli = (esb_client_t*)brk->esbcli;

	/** 从 map中查找 “request stub”请求存根 */
	stub_key = get_stub_map_key_byArg(pullresp->base_resp.opaque);
	req_stub = hash_get(brk->brk_ersq, stub_key);
	if (req_stub == NULL) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d: req_stub no found]%s\n", __FUNCTION__, __LINE__, stub_key);
		free(stub_key);
		return;
	}
	hash_del(brk->brk_ersq, stub_key);
	free(stub_key);

	queue = req_stub->q;
	if (queue == NULL || queue->has_removed == 1)
	{
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: queue not found or removed]sbj:%u|q_no:%u\n", __FUNCTION__, __LINE__, pullresp->base_resp.subject, pullresp->queue_id);
		return;
	}

	/** 处理各种 status状态 */
	if (pullresp->base_resp.status == RESP_STATUS_FOUND)
	{
		/** 状态正常 */
		next_offset = queue->offset = pullresp->next_offset;
		queue_id = pullresp->queue_id;
		/** 延迟时长清零: */
		queue->later_ms = 0;
		//可以合并
		if (esbcli->consume_pause_flag == 1) {
			broker_pullMsg_for_queue(brk, queue->sbj_obj, queue_id, next_offset, 0);
		} else {
			/** 对这个queue_id, 再次发起 pull msg “拉取消息” 请求 */
			broker_pullMsg_for_queue(brk, queue->sbj_obj, queue_id, next_offset, 0);
		}
	}
	else if (pullresp->base_resp.status == RESP_STATUS_NOT_FOUND)
	{
		queue->offset = pullresp->next_offset;
		/** 延迟一段时间，再发送拉取请求 */
		esb_pull_msg_later(queue);
	}
	else if (pullresp->base_resp.status == RESP_STATUS_REFUSED)
	{
		/** 被拒绝，通常因为server端队列重新分配，此时，移除此队列 */
		esb_pull_remove_queue_into_abondan(brk,queue);
		broken_commit_offset_for_queue(brk,queue, queue->sbj_obj,0);
		//char* q_key = get_abondan_queue_map_key(queue,brk);
		//相当于cancelTask（queuq）
		//queue->abandon=1;
		//esb_pull_remove_index_queue(brk, queue);
		//保证队列中的消息的指针访问不会出问题
		//hash_set(esbcli->abondan_queue, q_key, queue);
	}
	else if (pullresp->base_resp.status == RESP_STATUS_CONSUMEBACK)
	{
		/** CONSUMEBACK状态，下次请求时，需要设置flag参数FLAG_CONSUMEBACK */
		next_offset = queue->offset = pullresp->next_offset;
		queue_id = pullresp->queue_id;
		/** 对这个queue_id, 再次发起 pull msg “拉取消息” 请求 */
		broker_pullMsg_for_queue(brk, queue->sbj_obj, queue_id, next_offset, FLAG_CONSUMEBACK);
	}
	else if (pullresp->base_resp.status == RESP_STATUS_ACK_OFFSET_OK)
	{
		/** ACK_OFFSET_OK状态 */
		if (1 == brk->broker_close_flag )
		{
			/** 处于“退出”状态，移除队列，不再拉取 */
			//		esb_pull_remove_queue(brk, queue);
			esb_pull_remove_queue_into_abondan(brk, queue);
		} else {
			/** 延迟时长重置: */
			queue->later_ms = 30;
			/** 延迟一段时间，再发送拉取请求 */
			esb_pull_msg_later(queue);
		}
	}
	else if (pullresp->base_resp.status == RESP_STATUS_ADJUSTING)
	{
		//zsj 完成：--手动触发上传offset，不再拉取，等待调整完成，会重新初始化拉取
		esb_pull_remove_queue_into_abondan(brk,queue);
		broken_commit_offset_for_queue(brk,queue, queue->sbj_obj,0);
		// 队列调整中
		/** 延迟一段时间，再发送拉取请求 */
//		esb_pull_msg_later(queue);
//		esb_pull_msg_later(req_stub->q);
	} else {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: pullresp status unknown]%d\n", __FUNCTION__, __LINE__, pullresp->base_resp.status);
		/** 延迟一段时间，再发送拉取请求 */
		esb_pull_msg_later(queue);
	}

	/** 插入broker所属的  空闲stub“存根” map */
	hash_set(brk->brk_ersq_free, get_stub_map_key(req_stub), req_stub);

	return;
}

void esb_pushCtlLater_callback(int sock, short which, void *arg) {
	esb_broker_t *brk;
	esb_request_stub_t *req_stub;

	brk = (esb_broker_t*)arg;
	req_stub = &brk->pushctl_stub;
	broker_send_pushControl_request(brk, req_stub->sbj_obj, req_stub->pushCtl_type);
}

void esb_pushCtl_later(esb_broker_t *brk, esb_request_stub_t *req_stub) {
	struct timeval tv;
	tv.tv_sec = 0;
	tv.tv_usec = 10;  // 10 us
	esb_client_t * esbcli = (esb_client_t *)brk->esbcli;
	memcpy(&brk->pushctl_stub, req_stub, sizeof(esb_request_stub_t));
	if (brk->pushCtl_evtimer == NULL) {
		brk->pushCtl_evtimer = ESB_evtimer_new(esbcli->esb_evbase, esb_pushCtlLater_callback, brk);
	}
	ESB_evtimer_add(brk->pushCtl_evtimer, &tv);
}

void esb_getQueueLater_callback(int sock, short which, void *arg) {
	esb_broker_t *brk;
	int ret;
	esb_client_t * esbcli;
	brk = (esb_broker_t*)arg;
	esbcli = (esb_client_t *)brk->esbcli;
	if (GlobleExitFlag == 1 || esbcli->esbcli_close_flag == 1 || brk->broker_close_flag == 1) {
		return;
	}
	ret = broker_getQueue_for_sbjs(brk);
	if (ret < 0)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker_getQueue_for_sbjs failed]\n", __FUNCTION__, __LINE__);
		// error,what to do?
	}
}

void esb_get_qeue_later(esb_broker_t *brk) {
	struct timeval tv;
	tv.tv_sec = 0;
	tv.tv_usec = 1000 * 1000;  // 1 s
	esb_client_t * esbcli;

	esbcli = (esb_client_t *)brk->esbcli;
	if (GlobleExitFlag == 1 || esbcli->esbcli_close_flag == 1 || brk->broker_close_flag == 1) {
		return;
	}

	if (brk->getQ_evtimer == NULL) {
		brk->getQ_evtimer = ESB_evtimer_new(esbcli->esb_evbase, esb_getQueueLater_callback, brk);
	}
	ESB_evtimer_add(brk->getQ_evtimer, &tv);
}

void esb_queue_init_pull(esb_broker_t *brk, esb_queue_t *q) {
	esb_client_t * cli;
	//esb_request_stub_t *req_stub;

	cli = (esb_client_t*)brk->esbcli;
	//req_stub = new_esb_request_stub();
	//req_stub->q = q;
	//req_stub->brk = (void*)brk;
	//req_stub->sbj_obj = q->sbj_obj;

	//q->timer_stub = (void*)req_stub;
	q->broker = (void*)brk;
	q->queue_evtimer = ESB_evtimer_new(cli->esb_evbase,
	                                   esb_pullMsgLater_callback,
	                                   q);
	if (q->queue_evtimer == NULL)
	{
		// error,what to do
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_evtimer_new failed]\n", __FUNCTION__, __LINE__);
	}
	esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> pull queue, brk:%s, queue_id:%d] offset:%lu\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, q->queue_id, q->offset);

	/** 拉取 */
	broker_pullMsg_for_queue(brk, q->sbj_obj, q->queue_id, q->offset, 0);
}

void esb_getQueue_check_status(esb_getQueue_response_t *qresp,
                               esb_broker_t *brk) {
	int i;
	char *q_key, *sbj_key;
	esb_queue_t *q, *old_q,*abond_q;
	struct timeval tv;
	uint64_t time_interval;
	esb_client_t *cli = (esb_client_t*)brk->esbcli;

	if (brk->getQ_evtimer == NULL)
	{
		brk->getQ_evtimer = ESB_evtimer_new(cli->esb_evbase, esb_getQueueLater_callback, brk);
	}

	esb_printf(ESB_PRINT_DEBUG,
	           "[%s,%d--> getqueue,brk:%s,q_count:%d,status:%d,opaque:%lu]\n", __FUNCTION__, __LINE__,
	           brk->brk_ip_port_str,
	           qresp->q_count,
	           qresp->base_resp.status,
	           qresp->base_resp.opaque);

	if (qresp->q_count == 0 || qresp->base_resp.status == RESP_STATUS_ADJUSTING)
	{
		/** 此次getQueue未能获得数据 */
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> getQueue get zero queue, brk:%s resp.status:%d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, qresp->base_resp.status);
		return;
	}

	gettimeofday(&tv, NULL);

	/**
	 * zsj已完成：修改计划排查减少的队列，放入抛弃map中
	 * 设置队列抛弃标志
	 * 清理已经失效的queue: 遍历brk->brk_queue_map，与qresp->queues[i]的q_key进行比较，若不存在就打上抛弃标志
	 * esb_queue_t->abondan
	 */
	hash_each(brk->brk_queue_map, {
				q = (esb_queue_t*)val;

				if (q->subject_id != qresp->base_resp.subject) {
					continue;
				}

				int found=0;
				for (i = 0; i < qresp->q_count; ++i){
					esb_queue_t   *newq = qresp->queues[i];
					if(q->subject_id==newq->subject_id&& q->queue_id==newq->queue_id){
						found=1;
						break;
					}
				}

				if(found==0){
					//zsj 已完成：修改计划，将抛弃的queue单独存储，保留状态，并从有效队列中移除
					//zsj 完成：--手动触发上传offset
					esb_pull_remove_queue_into_abondan(brk, q);
					broken_commit_offset_for_queue(brk,q, q->sbj_obj,0);
				}
			});

/**
 * 检查新配置,将新来的queue加入到map中
 */
	for (i = 0; i < qresp->q_count; ++i)
	{
		q = qresp->queues[i];
		q_key = get_queue_map_key(q);
		old_q = (esb_queue_t*)hash_get(brk->brk_queue_map, q_key);
		esb_queue_t   *tempQ=q;
		if (old_q == NULL)
		{
			/**
			 * 配置中发现新的queue
			 * zsj已完成：修改计划 这里是broker新增加的消费队列，需要检查抛弃map中是否存在该队列，有则移除
			*/
			get_abondan_queue_map_key(q,brk);
			char * abond_q_key = q->obj_abondan_map_key;
			abond_q = (esb_queue_t*)hash_get(cli->abondan_queue, abond_q_key);
			//尝试从abondan_queue中恢复
			if(abond_q != NULL){
				hash_del(cli->abondan_queue, abond_q);
				/**
				 * 下面三行的把q的字段内容全部转移覆盖abond_q的内容，然后q指向abond_q指向的地址空间
				 * 作用在于
				 * A.连续更变队列时，消费队列的旧消息msg内的指向来源queue反向指针一直有效，以免产生段错误
				 * B.来源于同一个queue的所有msg内的指向queue的反向指针永远指向同一块地址空间(唯一的queue数据源信息)，避免意想不到的事件发生
				 * C.更新queue字段，作为抛弃消息依据，和拉取消息依据
				 */
				copy_queue(abond_q,q);
				abond_q->max_pull_version = q->max_pull_version;
				q = abond_q;
//				printf("abond_q指针的值：%d\n",(int)abond_q);
//				printf("q指针的值：%d\n",(int)q);
			}else{
//				printf("抛弃队列中未找到%s\n",abond_q_key);
			}
			q->abandon =0;
			/** 插入broker的queue Map */
			hash_set(brk->brk_queue_map, q_key, q);
			/** 插入esbcli的全局queue索引 Map */
			esbcli_queue_global_index_add(cli, q);
			/** 置空，否则 将会在释放qresp时一并释放 q */
			qresp->queues[i] = NULL;
			/** 查找sbj对象 */
			sbj_key = get_sbj_map_key_byArg(qresp->base_resp.subject);
			q->sbj_obj = (esb_subject_t*)hash_get(cli->cli_sbj_map, sbj_key);
			free(sbj_key);
			/** 初始化 队列，并启动拉取 */
			esb_queue_init_pull(brk, q);
			q=tempQ;
		} else {
			/** 重新发起已经中断了的 pull 请求 */
			/** 判断是否中断了，超时时间 是 pull请求本身超时设置的 3 倍 */
			time_interval = tv.tv_sec - old_q->pull_timestamp;
			if (cli->consume_pause_flag != 1 && old_q->pull_timestamp > 0 && time_interval > cli->u_conf.pull_request_timeout_sec * 3)
			{
				esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> reinit pull for queue, brk:%s, queue_id:%d] offset:%lu suspend_sec:%d\n", __FUNCTION__, __LINE__,
				           brk->brk_ip_port_str, old_q->queue_id, old_q->offset, time_interval);
				/** 发起拉取 */
				old_q->abandon=0;
				esb_pull_msg_delay_nSec(old_q);
			}
		}
	}

}

/**
 * 已废弃
 * 替代函数为 esb_pull_remove_queue_into_abondan
 * [esb_pull_remove_queue 移除 broker 的某个队列 q]
 * @param brk  []
 * @param q    []
 */
//void esb_pull_remove_queue(esb_broker_t *brk, esb_queue_t *q) {
//	hash_del(brk->brk_queue_map, get_queue_map_key(q));
//	esbcli_queue_global_index_del((esb_client_t*)brk->esbcli, q);
//	//zsj修改计划，未完成：这个函数需要考虑是否抛弃，暂时使用esb_pull_remove_queue_into_abondan代替
//	free_esb_queue(q);
//}

/**
 * [void esb_pull_remove_queue_into_abondan 移除 broker 的某个队列 q 到抛弃列表  但不释放对象]
 * @param brk  []
 * @param q    []
 */
void esb_pull_remove_queue_into_abondan(esb_broker_t *brk, esb_queue_t *q) {
	q->abandon=1;
	esb_client_t *cli = (esb_client_t*)brk->esbcli;
//	char* q_key = get_abondan_queue_map_key(q,brk);
	//相当于cancelTask(queue)
	hash_del(brk->brk_queue_map, get_queue_map_key(q));
	esbcli_queue_global_index_del((esb_client_t*)brk->esbcli, q);
	sprintf(q->obj_abondan_map_key, "%u|%u|%u",brk->iplong, q->subject_id, q->queue_id);
	//保证队列中的消息的指针访问不会出问题
	hash_set(cli->abondan_queue, q->obj_abondan_map_key, q);
}

void copy_queue(esb_queue_t *dest,esb_queue_t* src){
	dest->abandon=src->abandon;
	dest->subject_id=src->subject_id;
	dest->queue_id=src->queue_id;
	dest->offset=src->offset;
	dest->max_pull_version = src->max_pull_version;
			// q的消费ACK值，初始状态赋值，如果是>0的值，会被server当做合法数据处理（有可能会导致offset错乱）
	dest->consume_offset=src->consume_offset;
}
