/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <stdio.h>

#include "byteConvert.h"

uint64_t ip2long(const char* ip){
	if(ip==NULL) return 0;
  unsigned char a, b, c, d;
  sscanf(ip, "%hhu.%hhu.%hhu.%hhu", &a, &b, &c, &d);
  return ((a << 24) | (b << 16) | (c << 8) | d);
}

uint16_t StreamToUint16(char *stream, int byteEndian) {
	int i;
	uint16_t u16 = 0, byte_int;
	if (byteEndian == BIG_ENDIAN_ESB)
	{
		for (i = 0; i < 2; ++i)
		{
			byte_int = (uint8_t)stream[i];
			u16 += byte_int << ((1 - i) * 8);
		}
	}
	else
	{
		for (i = 0; i < 2; ++i)
		{
			byte_int = (uint8_t)stream[i];
			u16 += byte_int << (i * 8);
		}
	}
	return u16;
}

uint32_t StreamToUint32(char *stream, int byteEndian) {
	int i;
	uint32_t u32 = 0, byte_int;
	if (byteEndian == BIG_ENDIAN_ESB)
	{
		for (i = 0; i < 4; ++i)
		{
			byte_int = (uint8_t)stream[i];
			u32 += byte_int << ((3 - i) * 8);
		}
	}
	else
	{
		for (i = 0; i < 4; ++i)
		{
			byte_int = (uint8_t)stream[i];
			u32 += byte_int << (i * 8);
		}
	}
	return u32;
}

int32_t StreamToInt32(char *stream, int byteEndian) {
	int32_t i32;
	i32 = (int32_t)StreamToUint32(stream, byteEndian);
	return i32;
}

void Uint32ToStream(char *stream, uint32_t u32, int byteEndian) {
	int i;
	if (byteEndian == BIG_ENDIAN_ESB) {
		for (i = 0; i < 4; i++) {
			stream[i] = (char)(u32 >> (8 * (3 - i)));
		}
	} else {
		for (i = 0; i < 4; i++) {
			stream[i] = (char)(u32 >> (8 * i));
		}
	}
	return;
}

void Int32ToStream(char *stream, int32_t i32, int byteEndian) {
	Uint32ToStream(stream, (uint32_t)i32, byteEndian);
}

void Uint64ToStream(char *stream, uint64_t u64, int byteEndian) {
	int i;
	if (byteEndian == BIG_ENDIAN_ESB) {
		for (i = 0; i < 8; i++) {
			stream[i] = (char)(u64 >> (8 * (7 - i)));
		}
	} else {
		for (i = 0; i < 8; i++) {
			stream[i] = (char)(u64 >> (8 * i));
		}
	}
	return;
}

uint64_t StreamToUint64(char *stream, int byteEndian) {
	int i;
	uint64_t u64 = 0, byte_int;
	if (byteEndian == BIG_ENDIAN_ESB) {
		for (i = 0; i < 8; i++) {
			byte_int = (uint8_t)stream[i];
			u64 += byte_int << (8 * (7 - i));
		}
	} else {
		for (i = 0; i < 8; i++) {
			byte_int = (uint8_t)stream[i];
			u64 += byte_int << (i * 8);
		}
	}
	return u64;
}
