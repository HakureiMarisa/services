/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_CLUSTER_H
#define _ESBCLI_CLUSTER_H

#include "hash.h"
#include "esbcli_broker.h"

#define ESB_CLUSTER_STORE_SEPERATOR "&"

typedef enum {
	CLU_INIT = 1,  //刚刚创建对象，但还未发起连接
	CLU_NORMAL,
} esb_cluster_state_t;

typedef struct esb_cluster_s {
	char    obj_map_key[30];
	long    hash_code;
	int     type;
	long    version;
	/** 反向指针，指向 esb_client_t 对象 */
	void   *esbcli;

	/** broker 列表 */
	hash_t *clu_brk_map;   // map: [char*] brk_addr  =>  [esb_broker_t*] broker

	/** broker 列表 */
	hash_t *clu_brk_idx_map;

	/** broker 数量 */
	int	brk_count;

	/** subject 主题 列表 */
	hash_t *clu_sbj_map;   // map: [char*] sbj_key =>  [char*] "dummy"

	esb_cluster_state_t state;

	esb_broker_t *current_brk;

	ESB_mutex_t brk_mutex;
} esb_cluster_t;

esb_cluster_t * new_esb_cluster(long cluster_id, int type, long version, void *ecli);
void free_esb_cluster(esb_cluster_t *clu);

char * get_cluster_map_key(esb_cluster_t *clu);

char * get_cluster_map_key_byArg(long cluster_id);

void cluster_sbj_addToMap(esb_cluster_t *clu, char *sbj_key);

void cluster_brk_addToMap(esb_cluster_t *clu, esb_broker_t *brk);

void cluster_brk_removeMap(esb_cluster_t *clu, esb_broker_t *brk);

int cluster_has_brk(esb_cluster_t *clu, esb_broker_t *brk);

void generate_clu_brk_arr(esb_cluster_t *clu);

int cluster_start_each_broker(esb_cluster_t *clu);

int cluster_sub_single_sbj(esb_cluster_t *clu, esb_subject_t *sbj);

int cluster_unSub_single_sbj(esb_cluster_t *clu, esb_subject_t *sbj);

esb_broker_t * get_send_broker(esb_cluster_t *clu, int isLocked);

esb_broker_t * get_send_broker_with_seq(esb_cluster_t *clu, int seq, int isLocked);

esb_broker_t * get_send_sole_broker(esb_cluster_t *clu);

#endif
