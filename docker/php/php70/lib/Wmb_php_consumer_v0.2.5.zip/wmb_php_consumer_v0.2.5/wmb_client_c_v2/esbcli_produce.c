
#include "esbcli_produce.h"
#include "esbcli_thread.h"
#include "esbcli_queue.h"
#include "esbclient.h"

void free_send_op_tolist(void* esbcli, esb_send_op_t *send_op) {
	esb_client_t * esbclient = (esb_client_t*)esbcli;
	if (send_op != NULL) {
		if (send_op->msg != NULL) {
			if (send_op->msg->free_type == FREE_LATER) {
				free_esb_msg_tolist(esbclient, send_op->msg);
			} else {
				free_esb_msg(send_op->msg);
			}
		}

		memset(send_op, 0 , sizeof(send_op));
		insert_free_sendop(esbclient->send_hd, send_op);
	}

}

void free_send_op(esb_send_op_t *send_op) {
	if (send_op != NULL) {
		if (send_op->msg != NULL) {
			free_esb_msg(send_op->msg);
		}
		free(send_op);
	}
}

esb_send_hd_t* new_esb_send_hd() {
	esb_send_hd_t* send_hd = (esb_send_hd_t*)calloc(1, sizeof(esb_send_hd_t));
	ESB_mutex_init(&send_hd->seq_mutex, NULL);
	send_hd->send_seq = 0;
	esb_msg_t *msg;
	esb_send_op_t * send_op;
	int i;

	ESB_mutex_init(&send_hd->send_mutex, NULL);
	ESB_thread_cond_init(&send_hd->send_cond);
	TAILQ_INIT(&send_hd->send_op_list);
	send_hd->send_list_size = 0;
	send_hd->async_send_thread = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));

	ESB_mutex_init(&send_hd->sendq_mutex, NULL);
	ESB_thread_cond_init(&send_hd->sendq_cond);
	TAILQ_INIT(&send_hd->sendq_op_list);
	send_hd->sendq_list_size = 0;
	send_hd->async_sendq_thread = (ESB_thread_t *)calloc(1, sizeof(ESB_thread_t));

	ESB_mutex_init(&send_hd->msg_mutex, NULL);
	TAILQ_INIT(&send_hd->msg_free_list);

	for (i = 0; i < ESB_MSG_FREE_SIZE; i++) {
		msg = (esb_msg_t *)calloc(1, sizeof(esb_msg_t));
		TAILQ_INSERT_TAIL(&send_hd->msg_free_list, msg, em_link);
	}

	ESB_mutex_init(&send_hd->sendop_mutex, NULL);
	TAILQ_INIT(&send_hd->sendop_free_list);
	for (i = 0; i < ESB_MSG_FREE_SIZE; i++) {
		send_op = (esb_send_op_t*)calloc(1, sizeof(esb_send_op_t));
		TAILQ_INSERT_TAIL(&send_hd->sendop_free_list, send_op, send_msg_link);
	}
	return send_hd;
}

void free_esb_send_hd(esb_send_hd_t * send_hd) {
	esb_send_op_t* send_op;
	esb_msg_t* msg;
	if (send_hd != NULL) {
		ESB_mutex_destory(&send_hd->seq_mutex);
		ESB_mutex_destory(&send_hd->send_mutex);
		ESB_thread_cond_destroy(&send_hd->send_cond);
		while (send_hd->send_list_size > 0) {
			send_op = TAILQ_FIRST(&send_hd->send_op_list);
			TAILQ_REMOVE(&send_hd->send_op_list, send_op, send_msg_link);
			free_send_op(send_op);
			send_op = NULL;
			send_hd->send_list_size--;
		}

		if (send_hd->async_send_thread != NULL) {
			free(send_hd->async_send_thread);
		}

		ESB_mutex_destory(&send_hd->sendq_mutex);
		ESB_thread_cond_destroy(&send_hd->sendq_cond);
		while (send_hd->sendq_list_size > 0) {
			send_op = TAILQ_FIRST(&send_hd->sendq_op_list);
			TAILQ_REMOVE(&send_hd->sendq_op_list, send_op, send_msg_link);
			free_send_op(send_op);
			send_op = NULL;
			send_hd->sendq_list_size--;
		}

		if (send_hd->async_sendq_thread != NULL) {
			free(send_hd->async_sendq_thread);
		}

		ESB_mutex_destory(&send_hd->msg_mutex);
		while(!TAILQ_EMPTY(&send_hd->msg_free_list)) {
			msg = TAILQ_FIRST(&send_hd->msg_free_list);
			TAILQ_REMOVE(&send_hd->msg_free_list, msg, em_link);
			free(msg);
		}

		ESB_mutex_destory(&send_hd->sendop_mutex);
		while(!TAILQ_EMPTY(&send_hd->sendop_free_list)) {
			send_op = TAILQ_FIRST(&send_hd->sendop_free_list);
			TAILQ_REMOVE(&send_hd->sendop_free_list, send_op, send_msg_link);
			free(send_op);
		}
	}
	free(send_hd);
	send_hd = NULL;
}

int getNextSendSeq(esb_send_hd_t * send_hd) {
	int seq;

	ESB_mutex_lock(&send_hd->seq_mutex);
	if (send_hd->send_seq < (0x7fffffff-1)) {
		send_hd->send_seq = send_hd->send_seq + 1;
	} else {
		send_hd->send_seq = 1;
	}
	seq = send_hd->send_seq;
	ESB_mutex_unlock(&send_hd->seq_mutex);

	return seq;
}

void insert_free_msg(esb_send_hd_t * send_hd, esb_msg_t* msg) {
	ESB_mutex_lock(&send_hd->msg_mutex);
	TAILQ_INSERT_TAIL(&send_hd->msg_free_list, msg, em_link);
	ESB_mutex_unlock(&send_hd->msg_mutex);
}

esb_msg_t* get_free_msg(esb_send_hd_t * send_hd) {
	esb_msg_t* msg = NULL;
	ESB_mutex_lock(&send_hd->msg_mutex);
	if (!TAILQ_EMPTY(&send_hd->msg_free_list)) {
		msg = TAILQ_FIRST(&send_hd->msg_free_list);
		TAILQ_REMOVE(&send_hd->msg_free_list, msg, em_link);
	}
	ESB_mutex_unlock(&send_hd->msg_mutex);
	return msg;
}

void insert_free_sendop(esb_send_hd_t * send_hd, esb_send_op_t *send_op) {
	ESB_mutex_lock(&send_hd->sendop_mutex);
	TAILQ_INSERT_TAIL(&send_hd->sendop_free_list, send_op, send_msg_link);
	ESB_mutex_unlock(&send_hd->sendop_mutex);
}

esb_send_op_t* get_free_sendop(esb_send_hd_t * send_hd) {
	esb_send_op_t *send_op = NULL;
	ESB_mutex_lock(&send_hd->sendop_mutex);
	if (!TAILQ_EMPTY(&send_hd->sendop_free_list)) {
		send_op = TAILQ_FIRST(&send_hd->sendop_free_list);
		TAILQ_REMOVE(&send_hd->sendop_free_list, send_op, send_msg_link);
	}
	ESB_mutex_unlock(&send_hd->sendop_mutex);
	return send_op;
}


