
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#include "esbcli_window_data.h"
#include "esbclient.h"
#include "esbcli_util.h"
#include "esbcli_protocol.h"

int sessionId = 0;

//int waitone(window_data_t *wd, int timeout) {
//	int ret = 0, sec, mill_sec;
//    long macro_sec;
//    struct timespec mytime;
//    struct timeval now;
//	gettimeofday(&now, NULL);
//
//    sec = timeout / 1000;
//    mill_sec = timeout % 1000;
//    sec += (mill_sec * 1000 + now.tv_usec) / (1000 * 1000);
//    macro_sec = (mill_sec * 1000 + now.tv_usec) % (1000 * 1000);
//
//	mytime.tv_sec = now.tv_sec + sec;
//	mytime.tv_nsec = macro_sec * 1000;
//
//	ESB_mutex_lock(&wd->mutex);
//	ret = ESB_Thread_cond_timewait(&wd->cond, &wd->mutex, &mytime);
//	ESB_mutex_unlock(&wd->mutex);
//	return ret;
//}

void getTimeSpec(int t_mills, struct timespec *time_spec) {
	int sec, mill_sec;
    long macro_sec;
    struct timeval now;
	gettimeofday(&now, NULL);

    sec = t_mills / 1000;
    mill_sec = t_mills % 1000;
    sec += (mill_sec * 1000 + now.tv_usec) / (1000 * 1000);
    macro_sec = (mill_sec * 1000 + now.tv_usec) % (1000 * 1000);

    time_spec->tv_sec = now.tv_sec + sec;
    time_spec->tv_nsec = macro_sec * 1000;
}

int waitone(window_data_t *wd, int timeout) {
	int ret = 0;
    struct timespec *mytime = (struct timespec *)calloc(1, sizeof(struct timespec));
    getTimeSpec(timeout, mytime);

	ESB_mutex_lock(&wd->mutex);
	ret = ESB_Thread_cond_timewait(&wd->cond, &wd->mutex, mytime);
	ESB_mutex_unlock(&wd->mutex);
	free(mytime);
	return ret;
}

window_data_t * new_window_data(convert_fun_ callback) {
	window_data_t * wd  = (window_data_t *)calloc(1, sizeof(window_data_t));
	wd->callback_fun_ = callback;
	//ESB_mutex_t mutex;
	ESB_mutex_init(&wd->mutex, NULL);
	//wd->mutex = mutex;

	ESB_thread_cond_t cond;
	ESB_thread_cond_init(&cond);
	wd->cond = cond;
	wd->key_id = NULL;
	wd->data = NULL;
	wd->data_len = 0;
	return wd;
}

void free_window_data(window_data_t * wd) {
	if (wd->callback_fun_ != NULL) {
		free(wd->callback_fun_);
		wd->callback_fun_ = NULL;
	}

	ESB_mutex_destory(&wd->mutex);
	//free(&wd->mutex);
	ESB_thread_cond_destroy(&wd->cond);
	//free(&wd->cond);
	if (wd->key_id != NULL) {
		free(wd->key_id);
	}
	if (wd->data != NULL) {
		free(wd->data);
	}
	free(wd);
}

char* get_hash_key(long seq) {
	char* key = (char*)calloc(1,64);
	sprintf(key, "%ld", seq);
	return key;
}

