#include <errno.h>

#include "esbcli_event.h"
#include "esbcli_util.h"

int ESB_evthread_use_pthreads() {
	return evthread_use_pthreads();
}

//void ESB_event_global_shutdown() {
//	libevent_global_shutdown();
//	return;
//}

int ESB_EVUTIL_SOCKET_ERROR() {
	return EVUTIL_SOCKET_ERROR();
}

ESB_event_base_t *ESB_event_base_new(void) {
	ESB_event_base_t *base;
	base = event_base_new();

	return base;
}

ESB_bufferevent_t *ESB_bufferevent_socket_new(ESB_event_base_t *base) {
	ESB_bufferevent_t *bufev;
	/** 设置两个flag：释放时关闭连接、多线程安全 */
	bufev = bufferevent_socket_new(base, -1, BEV_OPT_CLOSE_ON_FREE | BEV_OPT_THREADSAFE);

	return bufev;
}

void ESB_event_base_free(ESB_event_base_t *base) {
	event_base_free(base);
	return;
}

int ESB_bufferevent_socket_connect(ESB_bufferevent_t *bufev,
                                   struct sockaddr *address, int addrlen) {
	return bufferevent_socket_connect(bufev, address, addrlen);
}

void ESB_bufferevent_free(ESB_bufferevent_t *bufev) {
	bufferevent_free(bufev);
}

void ESB_bufferevent_setcb(ESB_bufferevent_t *bufev,
                           ESB_bufferevent_data_cb readcb, ESB_bufferevent_data_cb writecb,
                           ESB_bufferevent_event_cb eventcb, void *cbarg) {
	bufferevent_setcb(bufev, readcb, writecb, eventcb, cbarg);
}

void ESB_bufferevent_setwatermark(ESB_bufferevent_t *bufev, short events,
	    size_t lowmark, size_t highmark) {
	bufferevent_setwatermark(bufev, events, lowmark, highmark);
}

void ESB_bufferevent_enable(ESB_bufferevent_t *bufev, short events) {
	bufferevent_enable(bufev, events);
}

void ESB_bufferevent_disable(ESB_bufferevent_t *bufev, short events) {
	bufferevent_disable(bufev, events);
}

short ESB_bufferevent_get_enabled(ESB_bufferevent_t *bufev) {
	return bufferevent_get_enabled(bufev);
}


int ESB_bufferevent_write(ESB_bufferevent_t *bufev, const void *data, size_t size) {
	if (bufev != NULL) {
		return bufferevent_write(bufev, data, size);
	} else {
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: bufferevent write failed.]\n", __FUNCTION__, __LINE__);
		return -1;
	}
}

size_t ESB_bufferevent_read(ESB_bufferevent_t *bufev, void *data, size_t size) {
	return bufferevent_read(bufev, data, size);
}

void ESB_bufferevent_set_timeouts(ESB_bufferevent_t *bufev,
                                  const struct timeval *timeout_read,
                                  const struct timeval *timeout_write) {
	bufferevent_set_timeouts(bufev, timeout_read, timeout_write);
	return;
}

int ESB_bufferevent_get_outputbuf_length(ESB_bufferevent_t *bufev) {
	if (bufev != NULL && bufferevent_get_output(bufev) != NULL) {
		return (int)evbuffer_get_length(bufferevent_get_output(bufev));
	} else {
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: bufferevent get outputbuf length failed.]\n", __FUNCTION__, __LINE__);
		return 0x7fffffff;
	}
}

/**
 * [ESB_event_search_word 查找evbuffer中是否包含 指定字符串（字节串）]
 * @param  bufev  []
 * @param  what   []
 * @param  length []
 * @return        [-1:未找到, >0:字符串在evbuffer中的位置]
 */
int ESB_event_search_word(ESB_bufferevent_t *bufev, void *what, int length) {
	struct evbuffer *evbuf;
	struct evbuffer_ptr p;

	evbuf = bufferevent_get_input(bufev);

	p = evbuffer_search(evbuf, (char*)what, (size_t)length, NULL);

	return (int)p.pos;
}

int ESB_event_base_dispatch(ESB_event_base_t *base) {
	return event_base_dispatch(base);
}

int ESB_event_assign(ESB_event_t *event, ESB_event_base_t *base,
                     evutil_socket_t fd, short what,
                     ESB_event_callback_fn cb, void *arg) {
	return event_assign(event, base, fd, what, cb, arg);
}

ESB_event_t *ESB_evtimer_new(ESB_event_base_t * base, ESB_event_callback_fn cb, void *arg) {
	return evtimer_new(base, cb, arg);
}

int ESB_evtimer_add(ESB_event_t *ev, const struct timeval *tv) {
	return evtimer_add(ev, tv);
}

void ESB_event_free(ESB_event_t *event) {
	event_free(event);
	return;
}
