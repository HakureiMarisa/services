
#ifndef _ESBCLI_BROKER_H
#define _ESBCLI_BROKER_H

#include "esbcli_event.h"
#include "esbcli_msg.h"
#include "esbcli_queue.h"
#include "esbcli_window_data.h"
#include "esbcli_produce.h"

extern int GlobleExitFlag;

#define ESB_BRK_WRITE_LOW_WATER 10240 /*10K*/
#define ESB_BRK_WRITE_HIGH_WATER 134217728 /*128M*/

#define CLOSABLE 1;
#define UNCLOSABLE 0;

#define WARMUP_PERIOD 5 * 60 * 1000L;
#define INIT_WEIGHT 100;
#define CUTOFF_WEIGHT 0;
#define MAX_FAILED_TIMES 5;

typedef enum {
	UNWRITABLE = 0,  //不可写的状态
	WRITABLE = 1,
} esb_brk_write_state_t;

/**
 * broker请求“存根”
 * 用途，记录每次client向broker发出的请求，在收到响应时，做数据对照，超时处理等。
 */
typedef struct esb_request_stub_s {
	/** 指向对应 broker 结构的指针 */
	void *brk;
	char obj_map_key[30];

	/** 0取消订阅 1拉取请求 2拉取队列 3心跳 4推送控制 */
	uint8_t    command_type;
	/** 请求序列号,用于response和request的对应查找 */
	uint64_t   opaque;

	/** 1拉取请求，队列对象指针 */
	esb_queue_t *q;
	/** 主题对象指针 */
	esb_subject_t *sbj_obj;

	/** 1拉取请求，队列id、偏移量 */
	uint32_t   queue_id;
	uint64_t   next_offset;
	/** 4推送控制, 控制选项：1暂停推送、2重启推送*/
	int        pushCtl_type;

	/** 请求时间戳，用于超时处理 */
	uint64_t   timestamp;
	/** request 发送成功与否的标记 */
	int        send_status;
} esb_request_stub_t;

esb_request_stub_t * new_esb_request_stub();
void free_esb_request_stub(esb_request_stub_t * req_stub);
char * get_stub_map_key(esb_request_stub_t * req_stub);
char * get_stub_map_key_byArg(uint64_t opaque);

typedef enum {
	INIT = 1,  //刚刚创建对象，但还未发起连接
	NORMAL,
	TESTING,
	DEAD,
	REBOOTING,
	CLOSE
} esb_broker_state_t;

/**
 *
 */
typedef struct esb_broker_s {
	/** 反向指针，指向 esb_client_t 对象 */
	void * esbcli;
	/** 反向指针，指向 esb_cluster_t 对象 */
	void * my_cluster;

	/** 包含ip和port的原始地址字符串，用于标识brk身份 */
	char * brk_ip_port_str;
	char * broker_ip;
	int    broker_port;

	/**
	 * zsj 已完成：修改计划加入iplong值，表明来源ip地址
	 */
	uint64_t iplong;

	ESB_bufferevent_t * bev;
	int    brok_sock_fd;

	ESB_event_t   *getQ_evtimer;
	ESB_event_t   *heartBeat_evtimer;
	ESB_event_t   *pushCtl_evtimer;
	ESB_event_t   *freeBrk_evtimer;
	esb_request_stub_t   pushctl_stub;

	/** 二级队列map */
	hash_t  *brk_queue_map;

	/** broker请求“存根”map */
	hash_t  *brk_ersq;
	/** broker请求“存根”空闲map, 实现“存根”对象复用 */
	hash_t  *brk_ersq_free;
	/** “存根”锁 */
	ESB_mutex_t  ersq_stub_mutex;

	int  broker_close_flag;    // 标记：broker准备关闭
	int  unSub_resp_rcv_flag; // 标记：unSub(取消订阅)的response已经收到
	int  subscribe_subject_count;
	int  unsub_subject_count;
	uint64_t   close_timestamp;

	esb_broker_state_t state;
	ESB_thread_t * state_checker_thread;
	ESB_mutex_t brk_check_mutex;

	ESB_mutex_t conn_mutex;
	ESB_thread_cond_t conn_cond;

	ESB_mutex_t writable_mutex;
	int writable;

	volatile int closable;
	char	*storeId;
	int		storeWeight;
	int		effectiveWeight;
	int		currentWeight;
	long	startTimestamp;
} esb_broker_t;


esb_broker_t * new_esb_broker_t(char * ipAndPort, void *ecli, void *clu);

void free_esb_broker_t(esb_broker_t *brk);

void esb_freeBrokerLater_callback(int sock, short which, void *arg);
void esb_free_broker_later(esb_broker_t *brk);

int brokerConnectServer(esb_broker_t * brk);

void notifyData(esb_broker_t *brk, long sessionId, char* body, char* data, int data_len);

void broker_write_callback(ESB_bufferevent_t *bufev, void *ctx);

void broker_read_callback(ESB_bufferevent_t *bufev, void *ctx);

void broker_event_callback(ESB_bufferevent_t *bufev, short events, void *ctx);

esb_string_t * broker_slice_frame(ESB_bufferevent_t *bufev);

int broker_subscribe_all_subject(esb_broker_t *brk);
int broker_send_subscribe_request(esb_broker_t *brk, esb_subject_t *sbj);

int broker_send_pushControl_request(esb_broker_t *brk, esb_subject_t *sbj, int pushCtl_type);

int broker_unSub_all_subject(esb_broker_t *brk);
int broker_send_unSub_request(esb_broker_t *brk, esb_subject_t *sbj);

int broker_getQueue_for_sbjs(esb_broker_t *brk);
int broker_send_getQueue_request(esb_broker_t *brk, esb_subject_t *sbj);

void esb_heartBeat_later(esb_broker_t *brk);
void esb_heartBeatLater_callback(int sock, short which, void *arg);
void broker_send_heartBeat_request(esb_broker_t * brk);

int broker_recycle_stub(esb_broker_t *brk, uint64_t opaque);
esb_request_stub_t * broker_get_free_stub_obj(esb_broker_t *brk, uint64_t opaque, uint8_t cmd_type);
void broker_insert_stub_toRecord(esb_broker_t *brk, esb_request_stub_t *req_stub);

void broker_pullMsg_for_queue(esb_broker_t *brk, esb_subject_t *sbj,
                              uint32_t queue_id, uint64_t offset, uint32_t flag);

int cleanUp_broker_req_stub(esb_broker_t *brk, int force_rm);

void check_broker_req_timeout(esb_broker_t *brk);

int asyncSendMsg(esb_broker_t *brk, esb_send_op_t *sendOp);

int syncSendMsg(esb_broker_t *brk, esb_send_op_t *sendOp);

void setBrkUnwritable(esb_broker_t *broker);
void broken_commit_offset_for_queue(esb_broker_t *brk,esb_queue_t* queue, esb_subject_t *sbj,uint32_t flag);

int iswarmup(esb_broker_t *brk);
int warmupWeight(esb_broker_t *brk);
void onInvokeFailed(esb_broker_t *brk);
void onInvokeSuccess(esb_broker_t *brk);
int isLimitPub(esb_broker_t *brk);
int getEffectiveWeight(esb_broker_t *brk);
#endif
