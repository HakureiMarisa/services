/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <inttypes.h>
#include "esbcli_thread.h"

#include "hash.h"

#ifndef _ESBCLI_SUBJECT_H
#define _ESBCLI_SUBJECT_H

#define ESB_SBJ_CMD_TYPE_PUSH -1
#define ESB_SBJ_CMD_TYPE_PULL  1

typedef struct esb_subject_s {
	char       obj_map_key[30];
	/** -1推送模式, 1拉取模式 */
	int8_t     command_type;
	/** 主题ID */
	uint32_t   subject_id;
	/** 客户端ID */
	uint32_t   client_id;
	/** 订阅起始时间 */
	uint64_t   start_time;

	/** cluster 列表 */
	hash_t    *sbj_cluster_map;
	/** cluster 列表 */
	hash_t    *sbj_clu_idx_map;
	/** producer cluster 列表*/
	hash_t    *sbj_pro_cluster_map;
	/** cluster 数量 */
	int8_t     cluster_count;
	/** unSub 请求重试次数 */
	int8_t     unSub_req_retry_count;

	char	  *current_cluster_key;

	ESB_mutex_t clu_mutex;
} esb_subject_t;

esb_subject_t * new_esb_subject(int subject_id, int client_id, int sub_mode);
void free_esb_subject(esb_subject_t *sbj);

char * get_sbj_map_key_byArg(uint32_t subject_id);
char * get_sbj_map_key(esb_subject_t *sbj);

void add_cluster_tosbj(esb_subject_t *sbj, char *clu_key);
void del_cluster_fromsbj(esb_subject_t *sbj, char *clu_key);

void generate_sbj_clu_arr(esb_subject_t *sbj);

#endif
