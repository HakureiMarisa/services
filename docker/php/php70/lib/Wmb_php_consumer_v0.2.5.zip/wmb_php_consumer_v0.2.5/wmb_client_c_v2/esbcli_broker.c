/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <assert.h>
#include <errno.h>

#include "esbcli_broker.h"
#include "esbcli_event.h"
#include "esbclient.h"
#include "esbcli_pull.h"
#include "esbcli_util.h"
#include "esbcli_brokerDetect.h"
#include "esbcli_queue.h"
#include "esbcli_cluster.h"

esb_request_stub_t * new_esb_request_stub() {
	esb_request_stub_t *req_stub;

	req_stub = (esb_request_stub_t *)calloc(1, sizeof(esb_request_stub_t));
	assert(req_stub);
	return req_stub;
}

void free_esb_request_stub(esb_request_stub_t * req_stub) {
	if (req_stub == NULL) {
		return;
	}
	free(req_stub);
}

char * get_stub_map_key(esb_request_stub_t * req_stub) {
	sprintf(req_stub->obj_map_key, "%lu", req_stub->opaque);
	return req_stub->obj_map_key;
}

char * get_stub_map_key_byArg(uint64_t opaque) {
	char *map_key;
	map_key = (char*)calloc(1, 32);
	sprintf(map_key, "%lu", opaque);
	return map_key;
}

/**
 * [new_esb_broker_t 新建esb_broker_t对象]
 * @param  ipAndPort [形如 127.0.0.1:8080 的网络地址字符串]
 * @return           [esb_broker_t对象指针]
 */
esb_broker_t * new_esb_broker_t(char * ipAndPort, void *ecli, void *clu) {
	esb_broker_t *brk;
	esb_client_t * cli;
	char  *addr_cpy, *ip, *port, *storeId;

	brk = (esb_broker_t *)calloc(1, sizeof(esb_broker_t));
	assert(brk);

	/** 反向指针  赋值 */
	brk->esbcli = ecli;
	brk->my_cluster = clu;

	cli = (esb_client_t*)(brk->esbcli);

	/** 复制一份地址字符串，避免 strtok 破坏原有字符串*/
	addr_cpy = (char *)malloc(strlen(ipAndPort) + 1);
	assert(addr_cpy);
	memcpy(addr_cpy, ipAndPort, strlen(ipAndPort) + 1);

	/** 再保存一份地址字符串，作为brk的唯一标识 */
	brk->brk_ip_port_str = (char *)malloc(strlen(ipAndPort) + 1);
	assert(brk->brk_ip_port_str);
	memcpy(brk->brk_ip_port_str, ipAndPort, strlen(ipAndPort) + 1);

	ip = strtok(addr_cpy, ":");
	if (ip == NULL)
	{
		free(addr_cpy);
		free_esb_broker_t(brk);
		esb_set_error(ESB_ERR_BRK_ADDR);
		return NULL;
	}
	brk->broker_ip = (char *)malloc(strlen(ip) + 1);
	assert(brk->broker_ip);
	strcpy(brk->broker_ip, ip);

	port = strtok(NULL, ":");
	if (port == NULL)
	{
		free(addr_cpy);
		free_esb_broker_t(brk);
		esb_set_error(ESB_ERR_BRK_ADDR);
		return NULL;
	}
	brk->broker_port = atoi(port);

	storeId = strtok(NULL, ":");
	if (storeId != NULL) {
		brk->storeId = (char *)malloc(strlen(storeId) + 1);
		assert(brk->storeId);
		strcpy(brk->storeId, storeId);
	} else {
		brk->storeId = NULL;
	}
	free(addr_cpy);

	/** 初始化多个hash map */
	brk->brk_queue_map = hash_new();
	brk->brk_ersq = hash_new();
	brk->brk_ersq_free = hash_new();
	ESB_mutex_init(&brk->ersq_stub_mutex, NULL);

	brk->state = INIT;
	ESB_mutex_init(&brk->brk_check_mutex , NULL);

	ESB_mutex_init(&brk->conn_mutex, NULL);
	ESB_thread_cond_init(&brk->conn_cond);

	ESB_mutex_init(&brk->writable_mutex, NULL);
	brk->writable = WRITABLE;

	brk->iplong=ip2long(brk->broker_ip);
	brk->closable = CLOSABLE;

	brk->effectiveWeight = INIT_WEIGHT;
	return brk;
}

void free_esb_broker_t(esb_broker_t *brk) {
	esb_queue_t *q;
	esb_request_stub_t *req_stub;
	//esb_printf(ESB_PRINT_DEBUG, "[%s,%d:: broker is now freed, addr:%s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);

	/** 释放bufferevent句柄 */
	if ( brk->bev != NULL) {
		ESB_bufferevent_free(brk->bev);
	}
	if (brk->brk_ip_port_str != NULL) {
		free(brk->brk_ip_port_str);
	}
	if (brk->broker_ip != NULL) {
		free(brk->broker_ip);
	}
	/** 释放map */
	if (brk->brk_queue_map != NULL) {
		hash_each(brk->brk_queue_map, {
			q = (esb_queue_t*)val;
			free_esb_queue(q);
		});
		hash_free(brk->brk_queue_map);
	}
	if (brk->brk_ersq != NULL) {
		hash_each(brk->brk_ersq, {
			req_stub = (esb_request_stub_t*)val;
			free_esb_request_stub(req_stub);
		});
		hash_free(brk->brk_ersq);
	}
	if (brk->brk_ersq_free != NULL) {
		hash_each(brk->brk_ersq_free, {
			req_stub = (esb_request_stub_t*)val;
			free_esb_request_stub(req_stub);
		});
		hash_free(brk->brk_ersq_free);
	}
	ESB_mutex_destory(&brk->ersq_stub_mutex);

	if (brk->getQ_evtimer != NULL) {
		ESB_event_free(brk->getQ_evtimer);
	}
	if (brk->heartBeat_evtimer != NULL) {
		ESB_event_free(brk->heartBeat_evtimer);
	}
	if (brk->pushCtl_evtimer != NULL) {
		ESB_event_free(brk->pushCtl_evtimer);
	}
	if (brk->freeBrk_evtimer != NULL) {
		ESB_event_free(brk->freeBrk_evtimer);
	}
	if (&brk->brk_check_mutex != NULL) {
		ESB_mutex_destory(&brk->brk_check_mutex);
	}

	ESB_mutex_destory(&brk->conn_mutex);
	//free(&wd->mutex);
	ESB_thread_cond_destroy(&brk->conn_cond);
	free(brk);
}

void esb_freeBrokerLater_callback(int sock, short which, void *arg) {
	esb_broker_t *brk;

	brk = (esb_broker_t*)arg;
	//esb_printf(ESB_PRINT_DEBUG, "[%s,%d:: broker will be free now, addr:%s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
	free_esb_broker_t(brk);
}

/**
 * [esb_free_broker_later 用于延迟发起 free broker 操作；避免多线程访问esb_evbase所引起的死锁]
 * @param brk []
 */
void esb_free_broker_later(esb_broker_t *brk) {
	esb_client_t * cli;
	struct timeval tv;
	tv.tv_sec = 0;
	tv.tv_usec = 10;  // 10 usec -- 10微秒

	cli = (esb_client_t*)(brk->esbcli);

	if (brk->freeBrk_evtimer == NULL) {
		brk->freeBrk_evtimer = ESB_evtimer_new(cli->esb_evbase, esb_freeBrokerLater_callback, brk);
	}

	ESB_evtimer_add(brk->freeBrk_evtimer, &tv);
}


int brokerConnectServer(esb_broker_t * brk) {
	int status;
	struct sockaddr_in brk_addr;
	memset(&brk_addr, 0, sizeof(brk_addr));
	esb_client_t * cli;

	brk_addr.sin_family = AF_INET;
	brk_addr.sin_port = htons(brk->broker_port);
	status = inet_aton(brk->broker_ip, &brk_addr.sin_addr);
	if ( status == 0 ) //the server_ip is not valid value
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker address illegal %s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
		esb_set_error(ESB_ERR_BRK_ADDR);
		return ESB_ERR_BRK_ADDR;
	}

	cli = (esb_client_t*)(brk->esbcli);

	ESB_bufferevent_t * newbev = ESB_bufferevent_socket_new(cli->esb_evbase);
	/** 针对 broker 初始化 bufferevent 结构 */
	//newbev = ESB_bufferevent_socket_new(cli->esb_evbase);
	if ( newbev == NULL )
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_socket_new is NULL]\n", __FUNCTION__, __LINE__);
		esb_set_error(ESB_ERR_BRK_CONN);
		return ESB_ERR_BRK_CONN;
	} else {
		ESB_bufferevent_t * oldbev = brk->bev;
		brk->bev = newbev;
		if (oldbev != NULL) {
			ESB_bufferevent_free(oldbev);
		}
	}

	ESB_bufferevent_setcb(brk->bev,
	                      broker_read_callback,
	                      broker_write_callback,
	                      broker_event_callback,
	                      brk);

//	struct timeval tv = {0, 15000 * 1000}; // 默认设置10秒读写超时
//	ESB_bufferevent_set_timeouts(brk->bev, NULL, &tv);

	ESB_bufferevent_setwatermark(brk->bev, EV_WRITE, ESB_BRK_WRITE_LOW_WATER, ESB_BRK_WRITE_HIGH_WATER);

	status = ESB_bufferevent_socket_connect(brk->bev, (struct sockaddr *)&brk_addr, sizeof(brk_addr));
	if ( status == -1 ) // connect failed
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_socket_connect status = -1, brk:%s error: %s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, strerror(errno));
		//bufferevent_free(brk->bev);   //modify
		esb_set_error(ESB_ERR_BRK_CONN);
		return ESB_ERR_BRK_CONN;
	}
	esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> broker addr]%s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);

	// 启动事件循环
	ESB_mutex_lock(&cli->start_dispatch_mutex);
	if (cli->is_start_dispatch == 0) {
		status = esb_client_dispatch_start(cli);
		if (status < 0) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: esb_client_dispatch_start failed, status] %d\n", __FUNCTION__, __LINE__, status);
			esb_set_error(ESB_ERR_DISPATCH_START_FAILED);
			return ESB_ERR_DISPATCH_START_FAILED;
		} else {
			cli->is_start_dispatch = 1;
		}
	}
	ESB_mutex_unlock(&cli->start_dispatch_mutex);

	struct timespec *mytime = (struct timespec *)calloc(1, sizeof(struct timespec));
	getTimeSpec(2000, mytime);
	ESB_mutex_lock(&brk->conn_mutex);
	status = ESB_Thread_cond_timewait(&brk->conn_cond, &brk->conn_mutex, mytime);
	ESB_mutex_unlock(&brk->conn_mutex);
	free(mytime);
	if (status != 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_socket_connect status = %d, brk:%s ,connect timeout, error: %s]\n", __FUNCTION__, __LINE__, status, brk->brk_ip_port_str, strerror(errno));
		//bufferevent_free(brk->bev);  //modify
		esb_set_error(ESB_ERR_CONN_TIMEOUT);
		return ESB_ERR_CONN_TIMEOUT;
	}

	return 0;
}


/**
 * [broker_write_callback 事件驱动，write事件回调函数]
 * @param bufev []
 * @param ctx   []
 */
void broker_write_callback(ESB_bufferevent_t *bufev, void *ctx) {
	esb_broker_t *brk = (esb_broker_t *)ctx;

	if (brk->writable == UNWRITABLE) {
		ESB_mutex_lock(&brk->writable_mutex);
		if (brk->writable == UNWRITABLE) {
			brk->writable = WRITABLE;
		}
		ESB_mutex_unlock(&brk->writable_mutex);
	}
}


/**
 * [broker_read_callback 事件驱动，read事件回调函数]
 * @param bufev []
 * @param ctx   []
 */
void broker_read_callback(ESB_bufferevent_t *bufev, void *ctx) {
	esb_string_t *frame_byte;
	esb_broker_t *brk = (esb_broker_t *)ctx;
	esb_response_t resp;
	esb_getQueue_response_t *qresp;
	esb_pull_response_t  pullresp;
	esb_request_stub_t *req_stub;
	uint8_t command_type, protocol_type;
	char *ptr, *stub_key;
	esb_client_t * cli;
	esb_msg_t msg;
	char * msgbody;

	cli = (esb_client_t*)(brk->esbcli);

	while (1) {
		frame_byte = broker_slice_frame(bufev);
		if (frame_byte == NULL) {
			/** “剩余完整frame个数为零”，退出循环 */
			break;
		}
		if (frame_byte->len < RESPONSE_HEAD_LEN + sizeof(esb_delimiter.P_END_TAG))
		{
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: frame_byte->len < xxx]%d, error: %s\n", __FUNCTION__, __LINE__, frame_byte->len, strerror(errno));
			/** frame 长度小于header长度，数据异常 */
			/*连接探测处理*/
			free_esb_string_t(frame_byte);
			brokerStateCheck(brk);
			return;
		}

		ptr = frame_byte->str;
		command_type = (uint8_t)ptr[5];
		protocol_type = (uint8_t)ptr[6];

		if (protocol_type == PROTO_TYPE_MSG) {

			switch (command_type) {
			/** 推送的消息 */
			case MSG_CMD_TYPE_PUSH:
				/** qid=-1,代表着推送消息,不需要抛弃*/
				esb_msg_decode_andInsertLocalQ(cli,NULL,-1,frame_byte->str, 0, NULL);
				break;
			/** 对发送的ACK */
			case MSG_CMD_TYPE_ACK:
				memset(&msg, 0, frame_byte->len);
				esb_msg_fromBytes(&msg, frame_byte->str);
				uint64_t sessionId = msg.session_id;
				if (msg.em_payload != NULL) {
					msgbody = (char *)calloc(1, strlen(msg.em_payload) + 1);
					memcpy(msgbody, msg.em_payload, strlen(msg.em_payload));
					msgbody[strlen(msg.em_payload)] = '\0';
				}
				char* body = (char *)msg.em_payload;
				resetMsg_and_freePayload(&msg);
				notifyData(brk, sessionId, msgbody, frame_byte->str, frame_byte->len);
				if (msgbody != NULL) {
					free(msgbody);
				}
				break;
			/** server重启 */
			case MSG_CMD_TYPE_REBOOT:
				esb_printf(ESB_PRINT_NOTICE, "[%s,%d:: broker is rebooting %s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
				/*连接探测处理*/
				brokerStateCheck(brk);
				break;
			/** 无法识别的cmd_type */
			default:
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: CMD_TYPE unknown!]%d\n", __FUNCTION__, __LINE__, command_type);
				break;
			}

		} else if (protocol_type == PROTO_TYPE_RESP) {

			switch (command_type) {
			/** 处理 “拉取队列 ” 的响应 */
			case CMD_TYPE_GETQUEUE:
				qresp = getQueue_response_fromBytes(frame_byte);
				//printf("[broker_read_callback--> getQueue_resp-> totalLen:%d; version:%d; cmd_type:%d; proto_type:%d subject:%u; cli_id:%d; opaque:%d; flag:%d; status:%d]\n", qresp->base_resp.total_len, qresp->base_resp.version, qresp->base_resp.command_type, qresp->base_resp.protocol_type, qresp->base_resp.subject, qresp->base_resp.client_id, qresp->base_resp.opaque, qresp->base_resp.flag, qresp->base_resp.status);
				broker_recycle_stub(brk, qresp->base_resp.opaque);

				esb_getQueue_check_status(qresp, brk);

				free_esb_getQueue_response(qresp);

				break;

			/** 处理 “拉取消息” 的响应 */
			case CMD_TYPE_PULLREQ:

				memset((void*)&pullresp, 0, sizeof(pullresp));
				/** 解析返回结果，及多条消息，消息直接插入待处理链表 */
				esb_pull_response_fromBytes(&pullresp, frame_byte, brk);
				/** 记录当前offset */
				//printf("[broker_read_callback--> pullresp-> totalLen:%d; version:%d; cmd_type:%d; proto_type:%d subject:%u; cli_id:%d; opaque:%d; flag:%d; status:%d; queue_id:%d; next_offset:%d]\n", pullresp.base_resp.total_len, pullresp.base_resp.version, pullresp.base_resp.command_type, pullresp.base_resp.protocol_type, pullresp.base_resp.subject, pullresp.base_resp.client_id, pullresp.base_resp.opaque, pullresp.base_resp.flag, pullresp.base_resp.status, pullresp.queue_id, pullresp.next_offset);

				/** 根据resp的status，执行需要发起的下一步操作（再次pull请求、移除队列、等等） */
				esb_pull_check_status(&pullresp, brk);

				break;

			/** 处理 “取消订阅” 的响应 */
			case CMD_TYPE_UNSUB:
				esb_response_fromBytes(&resp, frame_byte);
				broker_recycle_stub(brk, resp.opaque);
				esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> CMD_TYPE_UNSUB received! broker:%s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
				brk->unsub_subject_count += 1;
				break;
			/** 处理 “推送控制” 的响应 */
			case CMD_TYPE_PUSHCTRL:
				esb_response_fromBytes(&resp, frame_byte);
				broker_recycle_stub(brk, resp.opaque);
				esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> CMD_TYPE_PUSHCTRL received! status:%u broker:%s]\n", __FUNCTION__, __LINE__, resp.status, brk->brk_ip_port_str);
				break;
			/** 处理心跳的响应 */
			case CMD_TYPE_HEARTBEAT:
				esb_heartBeat_resp_fromBytes(&resp, frame_byte);
				broker_recycle_stub(brk, resp.opaque);
				esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> CMD_TYPE_HEARTBEAT received! broker:%s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
				break;
			/** 处理commit_offset响应 */
			case CMD_TYPE_COMMIT_OFFSET:
				esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> CMD_TYPE_COMMIT_OFFSET received! broker:%s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
				break;
			default:
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: CMD_TYPE unknown!]%d\n", __FUNCTION__, __LINE__, command_type);
				break;
			}
		} else {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: protocol_type illegal.]%d  %d\n", __FUNCTION__, __LINE__, protocol_type, command_type);
		}
		free_esb_string_t(frame_byte);
	}

}

int broker_recycle_stub(esb_broker_t *brk, uint64_t opaque) {
	esb_request_stub_t *req_stub;
	char *stub_key;
	/** 从 map中查找 “request stub”请求存根 */
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	stub_key = get_stub_map_key_byArg(opaque);
	req_stub = hash_get(brk->brk_ersq, stub_key);
	if (req_stub == NULL) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d: req_stub no found]%s\n", __FUNCTION__, __LINE__, stub_key);		free(stub_key);
		ESB_mutex_unlock(&brk->ersq_stub_mutex);
		return -1;
	}
	hash_del(brk->brk_ersq, stub_key);
	free(stub_key);
	/** 插入broker所属的  空闲stub“存根” map */
	hash_set(brk->brk_ersq_free, get_stub_map_key(req_stub), req_stub);
	ESB_mutex_unlock(&brk->ersq_stub_mutex);
	return 0;
}

/**
 * [broker_slice_frame 从eventbuffer的字节流中，分割数据帧]
 * @param  bufev []
 * @return       []
 */
esb_string_t * broker_slice_frame(ESB_bufferevent_t *bufev) {
	size_t read_size;
	int buf_offset;
	esb_string_t * frame_byte;

	buf_offset = ESB_event_search_word(bufev, (void*)esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));
	if (buf_offset < 0) {
		/** buf 中未找到 “分隔符”，返回null，表示 “剩余完整frame个数为零” */
		return NULL;
	}

	frame_byte = new_esb_string_t(buf_offset + sizeof(esb_delimiter.P_END_TAG));
	read_size = bufferevent_read(bufev, frame_byte->str, frame_byte->len);

	if (read_size < frame_byte->len)
	{
		esb_printf(ESB_PRINT_ERROR, "[broker_slice_frame::  read_size < frame_byte->len]%d  %d\n", read_size, frame_byte->len);
		free_esb_string_t(frame_byte);
		return NULL;
	}

	return frame_byte;
}


/**
 * [broker_event_callback 事件驱动，各种其他事件回调函数]
 * @param bufev  []
 * @param events [当前所发生的事件类型]
 * @param ctx    [brk指针]
 */
void broker_event_callback(ESB_bufferevent_t *bufev, short events, void *ctx) {
	int status;
	esb_broker_t *brk = (esb_broker_t *)ctx;
	esb_client_t *ecli;

	ecli = (esb_client_t*)(brk->esbcli);

	if (events & ESB_BEV_EVENT_CONNECTED)
	{
		esb_printf(ESB_PRINT_NOTICE, "[%s,%d-->  ESB_BEV_EVENT_CONNECTED]\n", __FUNCTION__, __LINE__);
		ESB_mutex_lock(&brk->conn_mutex);
		ESB_thread_cond_signal(&brk->conn_cond);
		brk->state = NORMAL;
		ESB_mutex_unlock(&brk->conn_mutex);

		if (ecli->client_type == ESB_CLI_TYPE_COMSUMER) {
			/** 连接成功，为每个主题，发起订阅 */
			status = broker_subscribe_all_subject(brk);
			if (status < 0) {
				esb_printf(ESB_PRINT_ERROR, "[%s,%d:: broker_subscribe_all_subject failed]\n", __FUNCTION__, __LINE__);
				/*连接探测处理*/
				brokerStateCheck(brk);
				return;
			}
			/** 然后 发送 拉取队列请求; 对于push模式的subject，会自动跳过 */
			esb_get_qeue_later(brk);  // 延迟发送请求
			//status = broker_getQueue_for_sbjs(brk);
			//if (status < 0)
			//{
			//	esb_printf(ESB_PRINT_ERROR, "[%s,%d::  broker_getQueue_for_sbjs status = -1 subscr_str]\n", __FUNCTION__, __LINE__);
			//	return;
			//}
			broker_send_heartBeat_request(brk);
		}

		/** 开启 read */
		ESB_bufferevent_enable(bufev, EV_READ);
	}
	else if (events & ESB_BEV_EVENT_ERROR)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d::  ESB_BEV_EVENT_ERROR %s] %s , error: %s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, ESB_evutil_socket_error_to_string(ESB_EVUTIL_SOCKET_ERROR()), strerror(errno));
		/* 准备关闭broker对象及其链接 */
//		brk->broker_close_flag = 1;
//		brk->unSub_resp_rcv_flag = 1;

		/*连接探测处理*/
		brokerStateCheck(brk);
		return;
	}
	else if (events & ESB_BEV_EVENT_EOF)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d::  ESB_BEV_EVENT_EOF]%s, error: %s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, strerror(errno));
		/* 准备关闭broker对象及其链接 */
//		brk->broker_close_flag = 1;
//		brk->unSub_resp_rcv_flag = 1;

		/*连接探测处理*/
		brokerStateCheck(brk);
		return;
	}
	else if (events & ESB_BEV_EVENT_TIMEOUT)
	{
		esb_printf(ESB_PRINT_ERROR, "[%s,%d::  ESB_BEV_EVENT_TIMEOUT]%s\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
		/* 准备关闭broker对象及其链接 */
//		brk->broker_close_flag = 1;
//		brk->unSub_resp_rcv_flag = 1;

		/*连接探测处理*/
		brokerStateCheck(brk);
		return;
	}
}

/**
 * [broker_subscribe_all_subject 订阅所有主题]
 * @param  brk [description]
 * @return     [description]
 */
int broker_subscribe_all_subject(esb_broker_t *brk) {
	esb_string_t *subscr_str;
	esb_sbj_proto_t *sbj_proto_list;
	esb_client_t *ecli;
	esb_cluster_t *clu;
	int sbj_cnt, i, status;
	char *sbj_key;
	esb_subject_t *sbj;
	struct timeval tv;

	ecli = (esb_client_t*)(brk->esbcli);
	clu = (esb_cluster_t*)(brk->my_cluster);

	gettimeofday(&tv, NULL);

	sbj_cnt = hash_size(clu->clu_sbj_map);
	sbj_proto_list = (esb_sbj_proto_t*)calloc(sbj_cnt, sizeof(esb_sbj_proto_t));
	assert(sbj_proto_list);
	i = 0;
	hash_each(clu->clu_sbj_map, {
		sbj_key = key;
		sbj = (esb_subject_t*)hash_get(ecli->cli_sbj_map, sbj_key);
		if (sbj == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: subject obj no found %s]\n", __FUNCTION__, __LINE__, sbj_key);
			continue;
		}
		sbj_proto_list[i].version = SUB_CURR_VERSION;
		sbj_proto_list[i].command_type = sbj->command_type;
		sbj_proto_list[i].subject = sbj->subject_id;
		sbj_proto_list[i].client_id = sbj->client_id;
		sbj->start_time = (uint64_t)(tv.tv_sec * 1000) + (uint64_t)(tv.tv_usec / 1000);
		sbj_proto_list[i].start_time = sbj->start_time;
		i += 1;

		/** 记录当前brk订阅了几个sbj主题 */
		brk->subscribe_subject_count += 1;
	});
	/** 打包、发送 */
	subscr_str = pack_subscribe_subject_toByte(sbj_proto_list, i);
	status = ESB_bufferevent_write(brk->bev, subscr_str->str, subscr_str->len);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_write status = -1 subscr_str, error: %s]\n", __FUNCTION__, __LINE__,  strerror(errno));
	}

	free(sbj_proto_list);
	free_esb_string_t(subscr_str);
	return status;
}

int broker_send_subscribe_request(esb_broker_t *brk, esb_subject_t *sbj) {
	esb_string_t *subscr_str;
	esb_sbj_proto_t *sbj_proto_list;
	struct timeval tv;
	int status;

	sbj_proto_list = (esb_sbj_proto_t*)calloc(1, sizeof(esb_sbj_proto_t));
	assert(sbj_proto_list);

	sbj_proto_list[1].version = SUB_CURR_VERSION;
	sbj_proto_list[1].command_type = sbj->command_type;
	sbj_proto_list[1].subject = sbj->subject_id;
	sbj_proto_list[1].client_id = sbj->client_id;
	gettimeofday(&tv, NULL);
	sbj->start_time = (uint64_t)(tv.tv_sec * 1000) + (uint64_t)(tv.tv_usec / 1000);
	sbj_proto_list[1].start_time = sbj->start_time;
	/** 打包、发送 */
	subscr_str = pack_subscribe_subject_toByte(sbj_proto_list, 1);
	status = ESB_bufferevent_write(brk->bev, subscr_str->str, subscr_str->len);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_write status = -1 subscr_str, error: %s]\n", __FUNCTION__, __LINE__,  strerror(errno));
	}
	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> subscribe request %u]\n", __FUNCTION__, __LINE__, sbj->subject_id);

	free(sbj_proto_list);
	free_esb_string_t(subscr_str);
	return status;
}

/**
 * [broker_send_pushControl_request 对某个broker控制某个sbj主题的推送过程(暂停、启动)]
 * @param  brk          [description]
 * @param  sbj          [description]
 * @param  pushCtl_type [description]
 * @return              [description]
 */
int broker_send_pushControl_request(esb_broker_t *brk, esb_subject_t *sbj, int pushCtl_type) {
	esb_pushCtl_request_t *pushCtl_req;
	esb_string_t *pushCtl_str;
	esb_request_stub_t *req_stub;
	int status;

	/** 仅处理push“推送”模式的主题 */
	if (sbj->command_type != ESB_SBJ_CMD_TYPE_PUSH) {
		return 0;
	}
	if (brk->state != NORMAL) {
		return -1;
	}

	pushCtl_req = new_pushCtl_request(pushCtl_type, sbj->subject_id, sbj->client_id);
	pushCtl_req->base_request.opaque = esb_get_opaque((esb_client_t*)brk->esbcli);
	pushCtl_str = pushCtl_request_toBytes(pushCtl_req);

	esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> pushControl Send! broker:%s subject:%u pushCtl_type:%d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, sbj->subject_id, pushCtl_type);

	status = ESB_bufferevent_write(brk->bev, pushCtl_str->str, pushCtl_str->len);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_write status = -1 pushCtl_str, error: %s]\n", __FUNCTION__, __LINE__,  strerror(errno));
		free_esb_request((esb_request_t*)pushCtl_req);
		free_esb_string_t(pushCtl_str);
		brokerStateCheck(brk);
		return -1;
	}

	/** 记录 request 请求 “存根” */
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	req_stub = broker_get_free_stub_obj(brk, pushCtl_req->base_request.opaque,
	                                    pushCtl_req->base_request.command_type);
	req_stub->sbj_obj = sbj;
	req_stub->pushCtl_type = pushCtl_type;
	req_stub->send_status = status;
	broker_insert_stub_toRecord(brk, req_stub);
	ESB_mutex_unlock(&brk->ersq_stub_mutex);

	free_esb_request((esb_request_t*)pushCtl_req);
	free_esb_string_t(pushCtl_str);

	return status;
}

/**
 * [broker_unSub_all_subject 对某个broker取消订阅所有sbj主题]
 * @param  brk [description]
 * @return     [description]
 */
int broker_unSub_all_subject(esb_broker_t *brk) {
	esb_cluster_t *clu;
	char *sbj_key;
	esb_subject_t *sbj;
	esb_client_t *ecli;
	int ret;

	ecli = (esb_client_t*)(brk->esbcli);
	clu = (esb_cluster_t*)(brk->my_cluster);
	hash_each(clu->clu_sbj_map, {
		sbj_key = key;
		sbj = (esb_subject_t*)hash_get(ecli->cli_sbj_map, sbj_key);
		if (sbj == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: subject obj no found %s]\n", __FUNCTION__, __LINE__, sbj_key);
			continue;
		}
		ret = broker_send_unSub_request(brk, sbj);
		if (ret < 0)
			return ret;
	});

	return 0;
}

/**
 * [broker_send_unSub_request 对某个主题 取消订阅]
 * @param  brk [description]
 * @return     [description]
 */
int broker_send_unSub_request(esb_broker_t *brk, esb_subject_t *sbj) {
	esb_client_t *esbcli;
	esb_string_t *unSub_req_str;
	esb_request_t * unSub_req;
	int status;
	esb_request_stub_t *req_stub;

	esbcli = (esb_client_t*)brk->esbcli;

	/** 控制 unsub 重试次数 */
	if (sbj->unSub_req_retry_count >= 3) {
		return 0;
	}
	sbj->unSub_req_retry_count += 1;

	unSub_req = new_unSub_request(sbj->subject_id, sbj->client_id);
	unSub_req->opaque = esb_get_opaque(esbcli);
	unSub_req_str = esb_request_toBytes(unSub_req);

	status = ESB_bufferevent_write(brk->bev, unSub_req_str->str, unSub_req_str->len);
	free_esb_string_t(unSub_req_str);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[broker_send_unSub_request::  ESB_bufferevent_write status = -1 unSub_req_str, error: %s]\n", strerror(errno));
		/*连接探测处理*/
		brokerStateCheck(brk);
		free_esb_request(unSub_req);
		return -1;
	}

	/** 记录 request 请求 “存根” */
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	req_stub = broker_get_free_stub_obj(brk, unSub_req->opaque, unSub_req->command_type);
	req_stub->sbj_obj = sbj;
	req_stub->send_status = status;
	broker_insert_stub_toRecord(brk, req_stub);
	ESB_mutex_unlock(&brk->ersq_stub_mutex);

	/** unSub request对象 已经无用，释放之 */
	free_esb_request(unSub_req);

	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> send unSub request %u]\n", __FUNCTION__, __LINE__, sbj->subject_id);

	return 0;
}

/**
 * [broker_getQueue_for_sbjs 为每个“拉取”模式的sbj，执行拉取队列操作]
 * @param  brk [description]
 * @return     [description]
 */
int broker_getQueue_for_sbjs(esb_broker_t *brk) {
	esb_client_t *ecli;
	esb_cluster_t *clu;
	char *sbj_key;
	esb_subject_t *sbj;
	int ret;

	ecli = (esb_client_t*)(brk->esbcli);
	clu = (esb_cluster_t*)(brk->my_cluster);

	/** 设置定时器，用于触发下一次更新 */
	esb_get_qeue_later(brk);

	if (brk->state != NORMAL) {
		return -1;
	}

	hash_each(clu->clu_sbj_map, {
		sbj_key = key;
		sbj = (esb_subject_t*)hash_get(ecli->cli_sbj_map, sbj_key);
		if (sbj == NULL) {
			esb_printf(ESB_PRINT_ERROR, "[%s,%d:: subject obj no found %s]\n", __FUNCTION__, __LINE__, key);
			continue;
		}
		/** 跳过 “推送模式” 的主题；仅处理 “拉取模式” */
		if (sbj->command_type != ESB_SBJ_CMD_TYPE_PULL)
			continue;

		ret = broker_send_getQueue_request(brk, sbj);
		if (ret < 0) {
			return ret;
		}
	});

	return 0;
}

int broker_getQueue_for_sbj(esb_broker_t *brk, esb_subject_t *sbj) {
	int ret;

	/** 设置定时器，用于触发下一次更新 */
	esb_get_qeue_later(brk);

	if (brk->state != NORMAL) {
		return -1;
	}

	/** 跳过 “推送模式” 的主题；仅处理 “拉取模式” */
	if (sbj->command_type != ESB_SBJ_CMD_TYPE_PULL)
		return 0;

	ret = broker_send_getQueue_request(brk, sbj);
	if (ret < 0) {
		return ret;
	}
	return 0;
}

/**
 * [broker_send_getQueue_request 发送 拉取队列 请求]
 * @param  brk [description]
 * @param  sbj [description]
 * @return     [description]
 */
int broker_send_getQueue_request(esb_broker_t *brk, esb_subject_t *sbj) {
	esb_string_t *que_req_str;
	esb_client_t *esbcli;
	esb_request_t *getQueue_req;
	esb_request_stub_t *req_stub;
	int status;

	esbcli = (esb_client_t*)(brk->esbcli);

	getQueue_req = new_getQueue_request(sbj->subject_id, sbj->client_id);
	getQueue_req->opaque = esb_get_opaque(esbcli);

	que_req_str = esb_request_toBytes(getQueue_req);
	status = ESB_bufferevent_write(brk->bev, que_req_str->str, que_req_str->len);
	free_esb_string_t(que_req_str);

	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d::  ESB_bufferevent_write status = -1 que_req_str, error: %s]\n", __FUNCTION__, __LINE__,  strerror(errno));
		/*连接探测处理*/
		free_esb_request(getQueue_req);
		brokerStateCheck(brk);
		return -1;
	}
	/** 记录 request 请求 “存根” */
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	req_stub = broker_get_free_stub_obj(brk, getQueue_req->opaque, getQueue_req->command_type);
	req_stub->sbj_obj = sbj;
	req_stub->send_status = status;
	broker_insert_stub_toRecord(brk, req_stub);
	ESB_mutex_unlock(&brk->ersq_stub_mutex);

	free_esb_request(getQueue_req);
	return 0;
}

/**
 * [broker_pullMsg_for_queue 拉取消息]
 * @param brk      []
 * @param q        []
 * @param flag     []
 */
void broker_pullMsg_for_queue(esb_broker_t *brk, esb_subject_t *sbj,
                              uint32_t queue_id, uint64_t offset, uint32_t flag) {
	esb_string_t *pull_str;
	esb_request_stub_t *req_stub;
	/** 采用局部变量，减少动态内存申请压力 */
	esb_pull_request_t  pullreq;
	int status, pull_num;
	esb_client_t *esbcli;
	esb_queue_t *queue;
	struct timeval tv;
	char *q_key;

	if (queue_id == 0) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: queue id = 0]\n", __FUNCTION__, __LINE__);
		return;
	}

	/** 先从map找到queue对象 */
	q_key = get_queue_map_key_byArg(sbj->subject_id, queue_id);
	queue = (esb_queue_t*)hash_get(brk->brk_queue_map, q_key);
	free(q_key);
	if (queue == NULL || queue->has_removed == 1)
	{
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: queue not found or removed]sbj:%u|q_no:%u\n", __FUNCTION__, __LINE__, sbj->subject_id, queue_id);
		return;
	}
	if (brk->state != NORMAL) {
		/** 移除 queue 对象；避免后续queue空占 */
//		esb_pull_remove_queue(brk, queue);
//		printf("=====!!!esb_pull_remove_queue_into_abondan!!!===A====");
		esb_pull_remove_queue_into_abondan(brk, queue);
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: brk state != NORMAL, queue will be removed; broker:%s queue_id:%d brk_state:%d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, queue_id, brk->state);
		return;
	}
	gettimeofday(&tv, NULL);
	queue->pull_timestamp = tv.tv_sec;

	esbcli = (esb_client_t *)(brk->esbcli);


	if (GlobleExitFlag > 0 ||esbcli->consume_pause_flag==1|| esbcli->esbcli_close_flag > 0 || brk->broker_close_flag > 0||queue->abandon>0) {
		// 处于退出状态时，pull_num置0，表示 “仅提交offset，不再拉取”
		pull_num = 0;
		//zsj 已完成：修改计划 当提交的是最新的offset就 连提交offset都不用了
//		if(queue->consume_offset_commited>=queue->consume_offset){
//			return;
//		}
		//esb_printf(ESB_PRINT_WARNING, "[%s,%d:: Just_Commit_Offset, brk:%s--q_no:%d, consume_ack:%d, pull_offset:%d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, queue_id, queue->consume_offset, offset);
	} else {
		// 每次最大拉取个数
		pull_num = esbcli->u_conf.each_pull_max_msg_cnt;
	}
//	esb_printf(ESB_PRINT_WARNING,"拉取时提交---ip:%s--主题:%d,队列:%d,offset:%d \n",brk->brk_ip_port_str,sbj->subject_id,queue->queue_id,queue->consume_offset);

	new_pull_request(&pullreq, sbj->subject_id, sbj->client_id,
	                 queue_id, offset, pull_num, queue->consume_offset);
	pullreq.base_request.flag = flag;
	pullreq.base_request.opaque = esb_get_opaque(esbcli);
	pull_str = pull_request_toBytes(&pullreq);

	status = ESB_bufferevent_write(brk->bev, pull_str->str, pull_str->len);
	free_esb_string_t(pull_str);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_write failed, error: %s]\n", __FUNCTION__, __LINE__, strerror(errno));
		/*连接探测处理*/
		brokerStateCheck(brk);
		return;
	}

	//zsj 修改计划：更新提交的offset
	//	queue->consume_offset_commited= queue->consume_offset;

	/** 记录 request 请求 “存根” */
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	req_stub = broker_get_free_stub_obj(brk, pullreq.base_request.opaque,
	                                    pullreq.base_request.command_type);
	req_stub->sbj_obj = sbj;
	req_stub->queue_id = queue_id;
	req_stub->q = queue;
	req_stub->next_offset = offset;
	req_stub->send_status = status;
	broker_insert_stub_toRecord(brk, req_stub);
	ESB_mutex_unlock(&brk->ersq_stub_mutex);
}

esb_request_stub_t * broker_get_free_stub_obj(esb_broker_t *brk, uint64_t opaque, uint8_t cmd_type) {
	esb_request_stub_t *req_stub;
	struct timeval tv;

	if (hash_size(brk->brk_ersq_free) == 0)
	{
		req_stub = new_esb_request_stub();
	} else {
		char *tmp_key;
		/** 优先从  空闲 stub“存根” map 取空对象 */
		hash_each(brk->brk_ersq_free, {
			tmp_key = key;
			req_stub = (esb_request_stub_t*)val;
			break;
		});
		hash_del(brk->brk_ersq_free, tmp_key);
	}
	/** 初始化基本参数 */
	req_stub->brk = (void*)brk;
	req_stub->command_type = cmd_type;
	req_stub->opaque = opaque;
	gettimeofday(&tv, NULL);
	req_stub->timestamp = tv.tv_sec;
	return req_stub;
}

void broker_insert_stub_toRecord(esb_broker_t *brk, esb_request_stub_t *req_stub) {
	/** 插入broker所属的  stub“存根” map */
	hash_set(brk->brk_ersq, get_stub_map_key(req_stub), req_stub);
}


int cleanUp_broker_req_stub(esb_broker_t *brk, int force_rm) {
	esb_request_stub_t *req_stub;
	struct timeval tv;
	uint64_t time_interval;
	uint64_t close_time_interval;

	esb_printf(ESB_PRINT_NOTICE, "[%s,%d--> try to cleanUp broker %s]%d\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, hash_size(brk->brk_ersq));

	gettimeofday(&tv, NULL);

	ESB_mutex_lock(&brk->ersq_stub_mutex);
	hash_each(brk->brk_ersq, {
		req_stub = (esb_request_stub_t*)val;
		time_interval = tv.tv_sec - req_stub->timestamp;
		close_time_interval = tv.tv_sec - brk->close_timestamp;
		if (force_rm == 1 || time_interval >= 10 || close_time_interval >= 10)
		{
			hash_del(brk->brk_ersq, key);
			free_esb_request_stub(req_stub);
		}
	});
	ESB_mutex_unlock(&brk->ersq_stub_mutex);

	/** 返回map剩余成员个数 */
	return hash_size(brk->brk_ersq);
}

void esb_heartBeatLater_callback(int sock, short which, void *arg) {
	esb_broker_t *brk = (esb_broker_t*)arg;
	broker_send_heartBeat_request(brk);
}

void esb_heartBeat_later(esb_broker_t *brk) {
	struct timeval tv;

	srand( (unsigned)time( NULL ) );

	tv.tv_sec = rand() % 4 + 2; // 2 ~ 6 sec
	//tv.tv_sec = 60; // 1 min
	tv.tv_usec = 0;
	esb_client_t * esbcli = (esb_client_t *)brk->esbcli;
	if (brk->heartBeat_evtimer == NULL) {
		brk->heartBeat_evtimer = ESB_evtimer_new(esbcli->esb_evbase, esb_heartBeatLater_callback, brk);
	}
	ESB_evtimer_add(brk->heartBeat_evtimer, &tv);
}

void broker_send_heartBeat_request(esb_broker_t * brk) {
	esb_client_t *esbcli;
	esb_string_t *hb_req_str;
	int status;
	esb_request_t *hb_req;
	esb_request_stub_t *req_stub;

	esbcli = (esb_client_t*)brk->esbcli;

	/** 设置下次heartBeat的定时器 */
	esb_heartBeat_later(brk);

	hb_req = new_heartBeat_request();
	hb_req->opaque = esb_get_opaque(esbcli);
	hb_req_str = heartBeat_request_toBytes(hb_req);

	status = ESB_bufferevent_write(brk->bev, hb_req_str->str, hb_req_str->len);
	free_esb_string_t(hb_req_str);
	if (status == -1) {
		esb_printf(ESB_PRINT_ERROR, "[%s,%d::  ESB_bufferevent_write status = -1 unSub_req_str, error: %s]\n", __FUNCTION__, __LINE__, strerror(errno));
		/*连接探测处理*/
		brokerStateCheck(brk);
		free_esb_request(hb_req);
		return -1;
	}

	/** 记录 request 请求 “存根” */
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	req_stub = broker_get_free_stub_obj(brk, hb_req->opaque, hb_req->command_type);
	req_stub->send_status = status;
	broker_insert_stub_toRecord(brk, req_stub);
	ESB_mutex_unlock(&brk->ersq_stub_mutex);

	esb_printf(ESB_PRINT_DEBUG, "[%s,%d--> send heartBeat request; opaque:%lu]\n", __FUNCTION__, __LINE__, hb_req->opaque);
	/** request对象 已经无用，释放之 */
	free_esb_request(hb_req);

	return 0;
}

void check_broker_req_timeout(esb_broker_t *brk) {
	esb_request_stub_t *req_stub;
	esb_client_t *esbcli;
	struct timeval tv;
	uint64_t time_interval;
	uint32_t sbj_id;
	char *map_key;
	int need_free_flag = 0;

	esbcli = (esb_client_t*)brk->esbcli;

	gettimeofday(&tv, NULL);
	ESB_mutex_lock(&brk->ersq_stub_mutex);
	hash_each(brk->brk_ersq, {
		map_key = key;
		req_stub = (esb_request_stub_t*)val;
		time_interval = tv.tv_sec - req_stub->timestamp;
		if (req_stub->sbj_obj != NULL) {
			sbj_id = req_stub->sbj_obj->subject_id;
		}
		need_free_flag = 0;
		/** 拉取pull 请求超时 */
		if (time_interval >= esbcli->u_conf.pull_request_timeout_sec && req_stub->command_type == CMD_TYPE_PULLREQ) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: pull request timeout, brk:%s sbj:%u queue_no:%d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, sbj_id, req_stub->queue_id);
			/** 重新发起拉取(延迟发起) */
			if (brk->broker_close_flag == 0) {
				esb_pull_msg_later(req_stub->q);
			}
			need_free_flag = 1;
		}
		/** 拉取队列getQueue 请求超时 */
		if (time_interval >= 5 && req_stub->command_type == CMD_TYPE_GETQUEUE) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: getQueue request timeout, brk:%s sbj:%u opaque:%lu]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, sbj_id, req_stub->opaque);
			need_free_flag = 1;
		}
		/** 推送控制 请求超时 */
		if (time_interval >= 5 && req_stub->command_type == CMD_TYPE_PUSHCTRL) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: pushCtl request timeout, brk:%s sbj:%u ctl_type:%d]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, sbj_id, req_stub->pushCtl_type);
			/** 重新发起 pushCtl 请求（延迟发起）*/
			esb_pushCtl_later(brk, req_stub);
			need_free_flag = 1;
		}
		/** 取消订阅 请求超时 */
		if (time_interval >= 5 && req_stub->command_type == CMD_TYPE_UNSUB) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: unSub request timeout, brk:%s sbj:%u]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str, sbj_id);
			/** 重新发起 unSub 请求*/
			broker_send_unSub_request(brk, req_stub->sbj_obj);
			need_free_flag = 1;
		}
		/** 心跳 请求超时 */
		if (time_interval >= 3 && req_stub->command_type == CMD_TYPE_HEARTBEAT) {
			esb_printf(ESB_PRINT_WARNING, "[%s,%d:: heartBeat request timeout, brk:%s]\n", __FUNCTION__, __LINE__, brk->brk_ip_port_str);
			need_free_flag = 1;
		}
		if (need_free_flag == 1) {
			/** 摘除，并释放“存根” */
			hash_del(brk->brk_ersq, map_key);
			free_esb_request_stub(req_stub);
		}
	});
	ESB_mutex_unlock(&brk->ersq_stub_mutex);

}

void registerRec(esb_broker_t *broker, long sessionId, convert_fun_ callback) {
	esb_client_t *esbcli =  (esb_client_t *)(broker->esbcli);
	window_data_t * wd = new_window_data(callback);

	char * key = get_hash_key(sessionId);
	wd->key_id = key;
	ESB_mutex_lock(&esbcli->wait_windows_mutex);
	hash_set(esbcli->wait_windows, wd->key_id, wd);
	ESB_mutex_unlock(&esbcli->wait_windows_mutex);
}

void unregisterRec(esb_broker_t *broker, long sessionId) {
	esb_client_t *esbcli =  (esb_client_t *)(broker->esbcli);
	window_data_t * wd = NULL;

	char * key = get_hash_key(sessionId);
	ESB_mutex_lock(&esbcli->wait_windows_mutex);
	wd = (window_data_t *)hash_get(esbcli->wait_windows, key);
	hash_del(esbcli->wait_windows, key);
	ESB_mutex_unlock(&esbcli->wait_windows_mutex);
	if (wd != NULL) {
		free_window_data(wd);
	}
	free(key);
}

void notifyData(esb_broker_t *broker, long sessionId, char* body, char* data, int data_len) {
	esb_client_t *esbcli =  (esb_client_t *)(broker->esbcli);
	window_data_t * wd = NULL;
	int status;

	char * key = get_hash_key(sessionId);
	wd = (window_data_t *)hash_get(esbcli->wait_windows, key);
	if (wd != NULL) {
		ESB_mutex_lock(&wd->mutex);
		wd->data = (char*)calloc(data_len, sizeof(char));
		memcpy(wd->data, data, data_len);
		wd->data_len = data_len;
		ESB_thread_cond_signal(&wd->cond);
		ESB_mutex_unlock(&wd->mutex);
	}

	// TODO CHECK
	if ((body != NULL) && (strlen(body) > 0)) {
		status = body[0];
		if (status == 0) {
			onInvokeSuccess(broker);
		} else {
			onInvokeFailed(broker);
		}
	}
	free(key);
}

int receiveData(esb_broker_t *broker, char* data, int *dataLen, long sessionId, int timeout) {
	int status;
	esb_client_t *esbcli =  (esb_client_t *)(broker->esbcli);

	if (sessionId < 0 || sessionId > MAX_SESSIONID) {
		status = -3;
	}
	window_data_t * wd  = NULL;
	char * key = get_hash_key(sessionId);
	wd = (window_data_t *)hash_get(esbcli->wait_windows, key);
	if (wd == NULL) {
		esb_printf(ESB_ERR_TIMEOUT, "[%s,%d:: wait_window::  send msg timeout]%d, %d\n", __FUNCTION__, __LINE__, sessionId, timeout);
		free(key);
		return -1;
	}
	if (wd->data == NULL) {
		int ret = waitone(wd, timeout);
		if (ret != 0) {
			printf("timeout code %d\n", ETIMEDOUT);
			esb_printf(ESB_ERR_TIMEOUT, "[%s,%d:: wait_window::  send msg timeout]%d, %d, %s\n", __FUNCTION__, __LINE__, sessionId, timeout, strerror(errno));
			free(key);
			unregisterRec(broker, sessionId);
			return ret;
		}
	}
	data = wd->data;
	*dataLen = wd->data_len;

	if (wd->callback_fun_ != NULL) {
		(*wd->callback_fun_)(data, NULL);
	}
	unregisterRec(broker, sessionId);
	free(key);
	return ESB_ERR_SUCCESS;
}

int asyncSendMsg(esb_broker_t *broker, esb_send_op_t *sendOp) {
	int status;
	struct timeval tv;
	int sessionID;
	esb_string_t *sendBytes;
	esb_msg_t *msg = sendOp->msg;

	gettimeofday(&tv, NULL);
	msg->timestamp = tv.tv_sec * 1000 + tv.tv_usec / 1000;
	msg->ip = (uint32_t) getlocalIp();
	sendBytes = esb_msg_toBytes(msg);

	if (ESB_bufferevent_get_outputbuf_length(broker->bev) > ESB_BRK_WRITE_HIGH_WATER) {
		setBrkUnwritable(broker);
	}

	status = ESB_bufferevent_write(broker->bev, sendBytes->str, sendBytes->len);
	if (status != 0) {
		esb_printf(ESB_ERR_BRK_SEND, "[%s,%d:: asyncSendMsg::  ESB_bufferevent_write status = -1, error: %s]\n", __FUNCTION__, __LINE__, strerror(errno));
		free_esb_string_t(sendBytes);
		/*连接探测处理*/
		brokerStateCheck(broker);
		return ESB_ERR_BRK_SEND;
	}

	free_esb_string_t(sendBytes);
	return ESB_ERR_SUCCESS;
}

int syncSendMsg(esb_broker_t *broker, esb_send_op_t *sendOp) {
	int status;
	struct timeval tv;
	long opaque;
	esb_string_t *sendBytes;
	esb_msg_t *msg = sendOp->msg;
	opaque = esb_get_opaque((esb_client_t *)broker->esbcli);
	if (opaque < 0 || opaque > MAX_SESSIONID) {
		esb_printf(ESB_ERR_BRK_SEND, "[%s,%d:: syncSendMsg::  opaque Id illegal.]\n", __FUNCTION__, __LINE__);
		return ESB_ERR_BRK_SEND;
	}
	gettimeofday(&tv, NULL);
	msg->timestamp = tv.tv_sec * 1000 + tv.tv_usec / 1000;
	msg->ip = (uint32_t) getlocalIp();
	msg->session_id = opaque;
	sendBytes = esb_msg_toBytes(msg);

	if (ESB_bufferevent_get_outputbuf_length(broker->bev) > ESB_BRK_WRITE_HIGH_WATER) {
		setBrkUnwritable(broker);
	}

	registerRec(broker, opaque, sendOp->send_cb);
	status = ESB_bufferevent_write(broker->bev, sendBytes->str, sendBytes->len);
	if (status != 0) {
		esb_printf(ESB_ERR_BRK_SEND, "[%s,%d:: syncSendMsg::  ESB_bufferevent_write status = -1, error: %s]\n", __FUNCTION__, __LINE__, strerror(errno));
		free_esb_string_t(sendBytes);
		/*连接探测处理*/
		brokerStateCheck(broker);
		return ESB_ERR_BRK_SEND;
	}

	char * data = NULL;
	int data_len = 0;
	status = receiveData(broker, data, &data_len, opaque, sendOp->timeout);

	if (status != ESB_ERR_SUCCESS) {
		esb_printf(ESB_ERR_BRK_SEND, "[%s,%d:: syncSendMsg::  receive data error,status: %d]\n", __FUNCTION__, __LINE__, status);
		free_esb_string_t(sendBytes);
		onInvokeFailed(broker);
		return ESB_ERR_TIMEOUT;
	}

	if ((data != NULL) && (data_len > 0)) {
		status = StreamToUint32(data, LITTLE_ENDIAN_ESB);
	}

	// TODO CHECK
	if (status == 0) {
		onInvokeSuccess(broker);
	} else {
		onInvokeFailed(broker);
		esb_printf(ESB_ERR_BRK_SEND, "[%s,%d:: syncSendMsg::  receive data error,status: %d]\n", __FUNCTION__, __LINE__, status);
					free_esb_string_t(sendBytes);
	}

	free_esb_string_t(sendBytes);
	return status;
}

void setBrkUnwritable(esb_broker_t *broker) {
	//printf("***************bufferevent send buffer length : %d\n", ESB_bufferevent_get_outputbuf_length(broker->bev));
	if (broker->writable == WRITABLE) {
		ESB_mutex_lock(&broker->writable_mutex);
		if (broker->writable == WRITABLE) {
			broker->writable = UNWRITABLE;
		}
		ESB_mutex_unlock(&broker->writable_mutex);
	}
}

/**
 * [broken_commit_offset_for_queue 提交消息offset]
 * @param brk      []
 * @param q        []
 * @param flag     [] 设置是否回溯消费
 */
void broken_commit_offset_for_queue(esb_broker_t *brk,esb_queue_t* queue, esb_subject_t *sbj,uint32_t flag) {

	esb_string_t *commit_str;
	esb_request_stub_t *req_stub;
	/** 采用局部变量，减少动态内存申请压力 */
	esb_commit_offset_request_t  commitreq;
	int status, pull_num;
	esb_client_t *esbcli=(esb_client_t*)brk->esbcli;
	if (queue == NULL){
	//	printf("提交失败B\n");
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: queue not found]sbj:%u|q_no:null\n", __FUNCTION__, __LINE__, sbj->subject_id);
		return;
	}
	
	if (queue->queue_id == 0) {
		//printf("提交失败A\n");
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: queue id = 0]\n", __FUNCTION__, __LINE__);
		return;
	}

	if (queue->has_removed == 1)
	{
	//	printf("提交失败C\n");
		esb_printf(ESB_PRINT_WARNING, "[%s,%d:: queue removed]sbj:%u|q_no:%u\n", __FUNCTION__, __LINE__, sbj->subject_id, queue->queue_id);
		return;
	}

//  测试通过之后，可以打开该注释，减少提交次数
//	if(queue->consume_offset_commited>=queue->consume_offset){
//		printf("提交失败E\n");
//		esb_printf(ESB_PRINT_ERROR, "无需提交--主题:%d,队列:%d,offset:%d \n",sbj->subject_id,queue->queue_id,queue->consume_offset_commited);
//		return;
//	}

	uint64_t commit_offset=queue->consume_offset;
	new_commit_offset_request(&commitreq, sbj->subject_id, sbj->client_id,queue->queue_id, commit_offset);
	commitreq.base_request.flag = flag;
	commitreq.base_request.opaque = esb_get_opaque(esbcli);
//	esb_printf(ESB_PRINT_ERROR, "主题:%d,队列:%d,offset:%d \n",sbj->subject_id,queue->queue_id,commitreq.consume_offset);
	//esb_printf(ESB_PRINT_WARNING,"主动提交-ip：%s----主题:%d,队列:%d,offset:%d \n",brk->brk_ip_port_str,sbj->subject_id,queue->queue_id,commitreq.consume_offset);
	commit_str = commit_offset_request_toBytes(&commitreq);

	status = ESB_bufferevent_write(brk->bev, commit_str->str, commit_str->len);

	free_esb_string_t(commit_str);
	if (status == -1) {
		//printf("提交失败D\n");
		esb_printf(ESB_PRINT_ERROR, "[%s,%d:: ESB_bufferevent_write failed, error: %s]\n", __FUNCTION__, __LINE__, strerror(errno));
		/*连接探测处理*/
		brokerStateCheck(brk);
		return;
	}

	//zsj 修改计划：更新提交的offset
	queue->consume_offset_commited= commit_offset;

//	/** 记录 request 请求 “存根” */
//	ESB_mutex_lock(&brk->ersq_stub_mutex);
//	req_stub = broker_get_free_stub_obj(brk, commitreq.base_request.opaque,
//			commitreq.base_request.command_type);
//	req_stub->sbj_obj = sbj;
//	req_stub->queue_id = queue->queue_id;
//	req_stub->q = queue;
//	//req_stub->next_offset = offset;
//	req_stub->send_status = status;
//	broker_insert_stub_toRecord(brk, req_stub);
//	ESB_mutex_unlock(&brk->ersq_stub_mutex);
}

int iswarmup(esb_broker_t *brk) {
	long warmup_period, currentTimestamp;

	currentTimestamp = get_currenttime();

	warmup_period = WARMUP_PERIOD;
	if ((currentTimestamp - (brk->startTimestamp)) <= warmup_period) {
		return 1;
	}

	return 0;
}

int warmupWeight(esb_broker_t *brk) {
	int weight, initweight;
	long uptime, warmup_period, currentTimestamp;

	currentTimestamp = get_currenttime();

	weight = initweight = INIT_WEIGHT;
	warmup_period = WARMUP_PERIOD;
	uptime = currentTimestamp - brk->startTimestamp;
	if (uptime < warmup_period) {
		weight = (int)(uptime * initweight/warmup_period);
		return weight < 1 ? 1 : (weight > initweight ? initweight : weight);
	}
	return weight;
}

void onInvokeFailed(esb_broker_t *brk) {
	long initweight;
	int max_failed_times;

	initweight = INIT_WEIGHT;
	max_failed_times = MAX_FAILED_TIMES;

	brk->effectiveWeight -= initweight/max_failed_times;
	if (brk->effectiveWeight < 1) {
		brk->effectiveWeight = 1;
	}
}

void onInvokeSuccess(esb_broker_t *brk) {
	long initweight;
	int max_failed_times;

	initweight = INIT_WEIGHT;
	max_failed_times = MAX_FAILED_TIMES;

	brk->effectiveWeight += initweight/max_failed_times;
	if (brk->effectiveWeight > initweight) {
		brk->effectiveWeight = initweight;
	}
}
int isLimitPub(esb_broker_t *brk) {
	long cutoffweight = CUTOFF_WEIGHT;
	return getEffectiveWeight(brk) < cutoffweight;
}

int getEffectiveWeight(esb_broker_t *brk) {
	int chgweight;

	if (brk->storeId != NULL) {
		chgweight = brk->storeWeight;
		return brk->effectiveWeight < chgweight ? brk->effectiveWeight : chgweight;
	}

	return brk->effectiveWeight;
}
