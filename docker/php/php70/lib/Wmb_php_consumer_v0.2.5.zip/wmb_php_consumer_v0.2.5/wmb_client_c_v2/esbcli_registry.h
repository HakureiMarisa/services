/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#ifndef _ESBCLI_REGISTRY_H
#define _ESBCLI_REGISTRY_H


#include "esbcli_protocol.h"
#include "esbcli_registryJSON.h"
#include "cJSON.h"


typedef struct esb_registry_s {
	char         *key_path;
	char         *key;
	char         *registry_ip;
	int           registry_port;
	char         *reg_port_string;

	struct addrinfo  *dns_res;
	int              reg_sock_fd;

	/** 反向指针，指向esb_client_t对象 */
	void         *esbcli;

	/** registry返回的json字符串 */
	char         *reg_conf_json_str;
	regConf_json_t   *reg_conf_obj;
	cJSON        *reg_json_root;
	int           conf_changed_flag;

} esb_registry_t;


int registrykeyInit(esb_registry_t *reg, char *key_path);
void registry_reset(esb_registry_t *reg);

int registryConnectServer(esb_registry_t *reg);

int registryReportVersion(esb_registry_t * reg);

int registryGetBrokerConf(esb_registry_t *reg);

esb_string_t * recvFrame(int sockfd);


#endif
