/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include "esbcli_queue.h"
#include "esbcli_broker.h"
#include "esbcli_event.h"
#include "esbcli_util.h"

esb_queue_t* new_esb_queue() {
	esb_queue_t *q;

	q = (esb_queue_t*)calloc(1, sizeof(esb_queue_t));
	return q;
}

/**
 * 调用该函数时，应确保参数q不会再被访问(msg->queue)
 */
void free_esb_queue(esb_queue_t *q) {
	if (q == NULL)
		return;
	if (q->queue_evtimer != NULL)
		ESB_event_free(q->queue_evtimer);
	//if (q->timer_stub != NULL)
	//	free_esb_request_stub((esb_request_stub_t*)(q->timer_stub));
	free(q);
}

char * get_queue_map_key_byArg(uint32_t subject_id, uint32_t queue_id) {
	char *map_key;

	map_key = (char*)calloc(1, 32);
	sprintf(map_key, "%u|%u", subject_id, queue_id);

	return map_key;
}

char * get_queue_map_key(esb_queue_t *q) {
	sprintf(q->obj_map_key, "%u|%u", q->subject_id, q->queue_id);
	return q->obj_map_key;
}

void get_abondan_queue_map_key(esb_queue_t *q, esb_broker_t *brk) {
	sprintf(q->obj_abondan_map_key, "%u|%u|%u",brk->iplong, q->subject_id,q->queue_id);
}

void get_queue_index_key_byArg(char *keyBuf, esb_queue_t *q) {
	sprintf(keyBuf, "%p", q);
}

char * get_queue_index_key(esb_queue_t *q) {
	get_queue_index_key_byArg(q->glb_index_key, q);
	return q->glb_index_key;
}

