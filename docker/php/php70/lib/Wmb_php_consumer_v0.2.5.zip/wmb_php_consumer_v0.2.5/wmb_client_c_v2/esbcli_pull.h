/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */
#ifndef _ESBCLI_PULL_H
#define _ESBCLI_PULL_H


#include "esbcli_protocol.h"
#include "esbcli_broker.h"

void esb_pull_response_fromBytes(esb_pull_response_t *pullresp,
                                 esb_string_t * buf,
                                 esb_broker_t * brk);

void esb_pull_check_status(esb_pull_response_t *pullresp, esb_broker_t *brk);

void esb_pullMsgLater_callback(int sock, short which, void *arg);

void esb_pull_msg_later(esb_queue_t *queue);

void esb_pull_msg_delay_nSec(esb_queue_t *queue);

void esb_getQueue_check_status(esb_getQueue_response_t *qresp,
                               esb_broker_t *brk);

void esb_pushCtlLater_callback(int sock, short which, void *arg);

void esb_pushCtl_later(esb_broker_t *brk, esb_request_stub_t *req_stub);

void esb_getQueueLater_callback(int sock, short which, void *arg);

void esb_get_qeue_later(esb_broker_t *brk);

//void esb_pull_remove_queue(esb_broker_t *brk, esb_queue_t *q);
//void esb_pull_remove_index_queue(esb_broker_t *brk, esb_queue_t *q);
char * get_obj_abondan_map_key(esb_broker_t *brk, esb_queue_t *q);
void esb_pull_remove_queue_into_abondan(esb_broker_t *brk, esb_queue_t *q);
void copy_queue(esb_queue_t *dest,esb_queue_t* src);
#endif
