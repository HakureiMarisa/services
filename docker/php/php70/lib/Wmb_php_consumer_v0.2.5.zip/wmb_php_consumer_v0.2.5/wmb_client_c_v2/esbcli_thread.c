/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */
#include "esbcli_thread.h"


int ESB_thread_create(ESB_thread_t *thread,
                      ESB_thread_attr_t *attr,
                      void * (*start_routine)(void *),
                      void * arg) {
	return pthread_create(thread, attr, start_routine, arg);
}

void ESB_thread_exit(void *rval_ptr) {
	pthread_exit(rval_ptr);
	return;
}

int ESB_thread_join(ESB_thread_t thread, void **retval) {
	return pthread_join(thread, retval);
}

int ESB_mutex_init(ESB_mutex_t *mutex, ESB_mutexattr_t *mutexattr) {
	return pthread_mutex_init(mutex, mutexattr);
}

int ESB_mutex_lock(ESB_mutex_t *mutex) {
	return pthread_mutex_lock(mutex);
}
int ESB_mutex_try_lock(ESB_mutex_t *mutex) {
	return pthread_mutex_trylock(mutex);
}

int ESB_mutex_unlock(ESB_mutex_t *mutex) {
	return pthread_mutex_unlock(mutex);
}

int ESB_mutex_destory(ESB_mutex_t *mutex) {
	return pthread_mutex_destroy(mutex);
}

int ESB_thread_cond_init(ESB_thread_cond_t *cond) {
	return pthread_cond_init(cond, NULL);
}

int ESB_thread_cond_wait(ESB_thread_cond_t *cond, ESB_mutex_t *mutex) {
	return pthread_cond_wait(cond, mutex);
}

int ESB_thread_cond_broadcast(ESB_thread_cond_t *cond) {
	return pthread_cond_broadcast(cond);
}

int ESB_thread_cond_destroy(ESB_thread_cond_t *cond) {
	return pthread_cond_destroy(cond);
}

int ESB_Thread_cond_timewait(ESB_thread_cond_t *cond, ESB_mutex_t *mutex, const struct timespec *abstime) {
	return pthread_cond_timedwait(cond, mutex, abstime);
}

int ESB_thread_cond_signal(ESB_thread_cond_t *cond) {
	return pthread_cond_signal(cond);
}

int ESB_thread_kill(ESB_thread_t thread, int sig) {
	return pthread_kill(thread, sig);
}

ESB_thread_t ESB_thread_self() {
	return pthread_self();
}