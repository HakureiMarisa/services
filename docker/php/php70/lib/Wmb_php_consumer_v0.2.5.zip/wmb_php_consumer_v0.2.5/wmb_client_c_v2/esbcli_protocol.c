/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "esbcli_protocol.h"
#include "byteConvert.h"
#include "esbcli_util.h"
#include "esbcli_queue.h"


delimiter_t esb_delimiter = {
	{18, 17, 13, 10, 9},
	{9, 10, 13, 17, 18}
};

uint64_t session_counter = 0;

esb_string_t *new_esb_string_t (int maxlen) {
	esb_string_t * result;
	result = (esb_string_t *)calloc(1, sizeof(esb_string_t));
	assert(result);
	result->str = (char *)calloc(1, maxlen);
	assert(result->str);
	result->len = maxlen;
	return result;
}

void free_esb_string_t(esb_string_t *target) {
	if (target == NULL)
		return;
	if (target->str != NULL)
		free(target->str);
	free(target);
}

uint64_t session_id_generator() {
	struct timeval tv;
	uint64_t tval, session;

	gettimeofday(&tv, NULL);
	tval = tv.tv_sec * 1000000 + tv.tv_usec;
	session_counter += 1;

	session = (tval << 16) + (session_counter & 0xffff);
	return session;
}

/*******************************
 * registry 相关方法
 *
 *******************************/

esb_registry_protocol_t *new_reg_protocol(uint8_t opaque, uint8_t msg_type, char *body) {
	esb_registry_protocol_t * proto;
	int body_len = 0;

	proto = (esb_registry_protocol_t *)calloc(1, sizeof(esb_registry_protocol_t));
	assert(proto);
	proto->version = 2; //新的注册中心配置
	proto->opaque = opaque;
	proto->msg_type = msg_type;
	proto->header_len = REG_HEAD_LEN;
	if (body != NULL && strlen(body) > 0)
	{
		body_len = strlen(body);
		proto->body = calloc(1, body_len);
		assert(proto->body);
		memcpy(proto->body, body, body_len);
	}
	proto->total_len = REG_HEAD_LEN + body_len;

	/** session id */
	proto->session_id = session_id_generator();

	return proto;
}

void free_reg_protocol(esb_registry_protocol_t * proto) {
	if (proto == NULL)
	{
		return;
	}
	/** body非空，则先释放body空间 */
	if ( (proto->total_len - proto->header_len) > 0 &&  proto->body != NULL) {
		free(proto->body);
	}

	free(proto);
}


esb_string_t * reg_protocol_to_bytes(esb_registry_protocol_t * proto) {
	esb_string_t * final_byte;
	int frame_len, body_len;
	char * ptr = NULL;

	frame_len = proto->total_len + sizeof(esb_delimiter.P_START_TAG) + sizeof(esb_delimiter.P_END_TAG);

	final_byte = new_esb_string_t(frame_len);

	ptr = final_byte->str;
	/** 首分割标记 */
	memcpy(ptr, esb_delimiter.P_START_TAG, sizeof(esb_delimiter.P_START_TAG));
	ptr += sizeof(esb_delimiter.P_START_TAG);

	/** frame长度，4字节 */
	Uint32ToStream(ptr, proto->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)proto->version;
	ptr += 1;
	/** 操作码 */
	ptr[0] = (char)proto->opaque;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)proto->msg_type;
	ptr += 1;
	/** session id */
	Uint64ToStream(ptr, proto->session_id, LITTLE_ENDIAN_ESB);
	ptr += 8;

	/** 数据body */
	body_len = proto->total_len - proto->header_len;
	if (body_len > 0) {
		memcpy(ptr, proto->body, body_len);
		ptr += body_len;
	}

	/** 尾分割标记 */
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));

	return final_byte;
}


esb_registry_protocol_t * reg_protocol_from_bytes(esb_string_t * buf) {
	esb_registry_protocol_t * proto;
	proto = new_reg_protocol(0, 0, NULL);
	char *ptr = buf->str;
	int body_len = 0;

	/**  */
	proto->total_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;

	/**  */
	proto->version = (uint8_t) * ptr;
	ptr += 1;
	proto->opaque = (uint8_t) * ptr;
	ptr += 1;
	proto->msg_type = (uint8_t) * ptr;
	ptr += 1;

	/**  */
	proto->session_id = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;

	body_len = proto->total_len - REG_HEAD_LEN;
	if (body_len > 0)
	{
		/** body 数据部分，多申请了1个字节，用于存一个字符串结尾符 \0 */
		proto->body = calloc(1, body_len + 1);
		assert(proto->body);
		memcpy(proto->body, ptr, body_len);
		/** 填上结尾\0 */
		ptr = (char *)proto->body + body_len;
		*ptr = '\0';
	}

	return proto;
}



/*******************************
 * subject 相关方法
 *
 *******************************/

esb_sbj_proto_t * new_esb_sbj_proto(int8_t sub_type, uint32_t subject, uint32_t client_id) {
	esb_sbj_proto_t * sbj;
	struct timeval tv;

	sbj = (esb_sbj_proto_t *)calloc(1, sizeof(esb_sbj_proto_t));
	assert(sbj);

	sbj->total_len = SUBJECT_HEAD_LEN;
	//sbj->version = 1;
	sbj->version = SUB_CURR_VERSION;
	sbj->command_type = sub_type;
	sbj->subject = subject;
	sbj->client_id = client_id;
	gettimeofday(&tv, NULL);
	sbj->start_time = tv.tv_sec;

	return sbj;
}

void free_esb_sbj_proto(esb_sbj_proto_t *sbj) {
	if (sbj == NULL)
	{
		return;
	}
	free(sbj);
}

esb_string_t * esb_sbj_proto_toByte(esb_sbj_proto_t *sbj) {
	esb_string_t * sbj_str;
	char * ptr;

	sbj_str = new_esb_string_t(SUBJECT_HEAD_LEN);
	sbj_str->len = SUBJECT_HEAD_LEN;
	/** 初始化 “游标” 指针 */
	ptr = sbj_str->str;

	Uint32ToStream(ptr, sbj->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)sbj->version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)sbj->command_type;
	ptr += 1;
	/** 主题 */
	Uint32ToStream(ptr, sbj->subject, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 客户端ID */
	Uint32ToStream(ptr, sbj->client_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 订阅消息的起始时间 [length:8] */
	Uint64ToStream(ptr, sbj->start_time, LITTLE_ENDIAN_ESB);
	//ptr += 8;

	return sbj_str;
}

esb_subscribe_protocol_t * new_esb_subscribe_protocol(int sbj_count) {
	esb_subscribe_protocol_t * subscr;

	subscr = (esb_subscribe_protocol_t *)calloc(1, sizeof(esb_subscribe_protocol_t));
	assert(subscr);
	subscr->total_len = SUBSCRI_HEAD_LEN + (sbj_count * SUBJECT_HEAD_LEN);
	//subscr->version = 1;
	subscr->version = 2; // 支持pull ack模式，此处version升级成2
	subscr->command_type = -1;
	subscr->protocol_type = PROTO_TYPE_SUBS;

	return subscr;
}

void free_esb_subscribe_protocol(esb_subscribe_protocol_t *subscr) {
	if (subscr == NULL)
		return;
	if (subscr->body != NULL)
		free(subscr->body);
	free(subscr);
}

esb_string_t * pack_subscribe_subject_toByte(esb_sbj_proto_t *sbj_list, int sbj_cnt) {
	esb_string_t *sbj_str;
	esb_string_t *subscr_str;
	esb_subscribe_protocol_t *ssp;
	char * ptr;
	int i;

	/** 创建buffer空间，容纳sbj_cnt个sbj */
	ssp = new_esb_subscribe_protocol(sbj_cnt);
	/** 为了在尾部加一个 “尾分隔符” ，故多申请 5 个字节 */
	subscr_str = new_esb_string_t(ssp->total_len + sizeof(esb_delimiter.P_END_TAG));
	subscr_str->len = ssp->total_len + sizeof(esb_delimiter.P_END_TAG);
	/** 初始化 “游标” 指针 */
	ptr = subscr_str->str;

	/** 总长度 */
	Uint32ToStream(ptr, ssp->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)ssp->version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)ssp->command_type;
	ptr += 1;
	/**  */
	ptr[0] = (char)ssp->protocol_type;
	ptr += 1;

	/** 写入body，每个subject字节串 */
	for (i = 0; i < sbj_cnt; ++i)
	{
		sbj_str = esb_sbj_proto_toByte(&sbj_list[i]);
		memcpy(ptr, sbj_str->str, sbj_str->len);
		ptr += sbj_str->len;
		free_esb_string_t(sbj_str);
	}

	/** 写入 “尾分隔符” ，结束一个数据帧frame*/
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));
	free_esb_subscribe_protocol(ssp);

	return subscr_str;
}


/**********************************
 *  request 相关方法
 *
 *********************************/

void init_esb_request(esb_request_t *req, uint32_t total_len, uint32_t command_type,
                      uint32_t subject_id, uint32_t client_id, uint64_t opaque, uint32_t flag) {
	req->total_len = total_len;
	req->version = CURR_PROTO_REQ_VERSION;
	req->command_type = command_type;
	req->protocol_type = PROTO_TYPE_REQ;
	req->subject = subject_id;
	req->client_id = client_id;
	req->opaque = opaque;
	req->flag = flag;
}

void free_esb_request(esb_request_t * req) {
	if (req == NULL)
		return;
	free(req);
}

esb_request_t * new_getQueue_request(uint32_t subject, uint32_t client_id) {
	esb_request_t *req;

	req = (esb_request_t *)calloc(1, sizeof(esb_request_t));
	assert(req);
	req->total_len = REQUEST_HEAD_LEN;
	req->version = CURR_PROTO_REQ_VERSION;
	req->command_type = CMD_TYPE_GETQUEUE;
	req->protocol_type = PROTO_TYPE_REQ;
	req->subject = subject;
	req->client_id = client_id;
	req->opaque = 0;
	req->flag = 0;

	return req;
}

esb_request_t * new_heartBeat_request() {
	esb_request_t *req;

	req = (esb_request_t *)calloc(1, sizeof(esb_request_t));
	assert(req);
	req->total_len = HEARTBEAT_REQ_HEAD_LEN;
	req->version = CURR_PROTO_REQ_VERSION;
	req->command_type = CMD_TYPE_HEARTBEAT;
	req->protocol_type = PROTO_TYPE_REQ;
	req->opaque = 0;
	return req;
}

esb_string_t * heartBeat_request_toBytes(esb_request_t *hbreq) {
	esb_string_t * req_str;
	char * ptr;

	/** 为了在尾部加一个 “尾分隔符” ，故多申请 5 个字节 */
	req_str = new_esb_string_t(hbreq->total_len + sizeof(esb_delimiter.P_END_TAG));
	/** 初始化 “游标” 指针 */
	ptr = req_str->str;

	/** 总长度 */
	Uint32ToStream(ptr, hbreq->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)hbreq->version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)hbreq->command_type;
	ptr += 1;
	/** 协议类型 */
	ptr[0] = (char)hbreq->protocol_type;
	ptr += 1;
	/** 请求序列号 */
	Uint64ToStream(ptr, hbreq->opaque, LITTLE_ENDIAN_ESB);
	ptr += 8;

	/** 写入 “尾分隔符” ，结束一个数据帧frame*/
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));

	return req_str;
}

esb_request_t * new_unSub_request(uint32_t subject, uint32_t client_id) {
	esb_request_t *req;

	req = (esb_request_t *)calloc(1, sizeof(esb_request_t));
	assert(req);
	req->total_len = REQUEST_HEAD_LEN;
	req->version = CURR_PROTO_REQ_VERSION;
	req->command_type = CMD_TYPE_UNSUB;
	req->protocol_type = PROTO_TYPE_REQ;
	req->subject = subject;
	req->client_id = client_id;
	req->opaque = 0;
	req->flag = 0;

	return req;
}

esb_string_t * esb_request_toBytes(esb_request_t *req) {
	esb_string_t * req_str;
	char * ptr;

	/** 为了在尾部加一个 “尾分隔符” ，故多申请 5 个字节 */
	req_str = new_esb_string_t(req->total_len + sizeof(esb_delimiter.P_END_TAG));
	req_str->len = req->total_len + sizeof(esb_delimiter.P_END_TAG);
	/** 初始化 “游标” 指针 */
	ptr = req_str->str;

	/** 总长度 */
	Uint32ToStream(ptr, req->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)req->version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)req->command_type;
	ptr += 1;
	/** 协议类型 */
	ptr[0] = (char)req->protocol_type;
	ptr += 1;
	/** 主题 id */
	Uint32ToStream(ptr, req->subject, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** client id */
	Uint32ToStream(ptr, req->client_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 请求序列号 */
	Uint64ToStream(ptr, req->opaque, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** flag */
	Uint32ToStream(ptr, req->flag, LITTLE_ENDIAN_ESB);
	ptr += 4;

	/** 写入 “尾分隔符” ，结束一个数据帧frame*/
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));

	return req_str;
}

void esb_request_fillBytes(esb_request_t *req, esb_string_t *req_str) {
	char * ptr;

	/** 初始化 “游标” 指针 */
	ptr = req_str->str;

	/** 总长度 */
	Uint32ToStream(ptr, req->total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)req->version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)req->command_type;
	ptr += 1;
	/** 协议类型 */
	ptr[0] = (char)req->protocol_type;
	ptr += 1;
	/** 主题 id */
	Uint32ToStream(ptr, req->subject, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** client id */
	Uint32ToStream(ptr, req->client_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 请求序列号 */
	Uint64ToStream(ptr, req->opaque, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** flag */
	Uint32ToStream(ptr, req->flag, LITTLE_ENDIAN_ESB);
	//ptr += 4;
}

void free_pull_request(esb_pull_request_t *pullreq) {
	if (pullreq != NULL)
		free(pullreq);
}

esb_pull_request_t * new_pull_request(esb_pull_request_t *pullreq, uint32_t subject,
                                      uint32_t client_id, uint32_t queue_id,
                                      uint64_t offset, uint32_t max_pull, uint64_t consume_ack) {
	//esb_pull_request_t * pullreq;
	if (pullreq == NULL)
	{
		pullreq = (esb_pull_request_t *)calloc(1, sizeof(esb_pull_request_t));
		assert(pullreq);
	} else {
		memset(pullreq, 0, sizeof(esb_pull_request_t));
	}

	//pullreq->base_request.total_len = REQUEST_HEAD_LEN + 4 + 8 + 4;
	pullreq->base_request.total_len = REQUEST_HEAD_LEN + 4 + 8 + 4 + 8;
	pullreq->base_request.version = CURR_PULL_REQ_VERSION;
	pullreq->base_request.command_type = CMD_TYPE_PULLREQ;
	pullreq->base_request.protocol_type = PROTO_TYPE_REQ;
	pullreq->base_request.subject = subject;
	pullreq->base_request.client_id = client_id;
	pullreq->base_request.opaque = 0;
	pullreq->base_request.flag = 0;
	pullreq->queue_id = queue_id;
	pullreq->next_offset = offset;
	pullreq->pull_num = max_pull;
	pullreq->consume_offset = consume_ack;

	return pullreq;
}

esb_string_t * pull_request_toBytes(esb_pull_request_t *pullreq) {
	esb_string_t * preq_str;
	char * ptr;

	/** 为了在尾部加一个 “尾分隔符” ，故多申请 5 个字节 */
	preq_str = new_esb_string_t(pullreq->base_request.total_len + sizeof(esb_delimiter.P_END_TAG));
	preq_str->len = pullreq->base_request.total_len + sizeof(esb_delimiter.P_END_TAG);
	/** 初始化 “游标” 指针 */
	ptr = preq_str->str;

	/** 总长度 */
	Uint32ToStream(ptr, pullreq->base_request.total_len, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 协议版本 */
	ptr[0] = (char)pullreq->base_request.version;
	ptr += 1;
	/** 消息类型 */
	ptr[0] = (char)pullreq->base_request.command_type;
	ptr += 1;
	/** 协议类型 */
	ptr[0] = (char)pullreq->base_request.protocol_type;
	ptr += 1;
	/** 主题 id */
	Uint32ToStream(ptr, pullreq->base_request.subject, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** client id */
	Uint32ToStream(ptr, pullreq->base_request.client_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 请求序列号 */
	Uint64ToStream(ptr, pullreq->base_request.opaque, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** flag */
	Uint32ToStream(ptr, pullreq->base_request.flag, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 拉取的队列id */
	Uint32ToStream(ptr, pullreq->queue_id, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 拉取的offset */
	Uint64ToStream(ptr, pullreq->next_offset, LITTLE_ENDIAN_ESB);
	ptr += 8;
	/** 本次拉取的最大消息数 */
	Uint32ToStream(ptr, pullreq->pull_num, LITTLE_ENDIAN_ESB);
	ptr += 4;
	/** 目前已经被消费处理的offset */
	if (pullreq->base_request.version >= 2) {
		Uint64ToStream(ptr, pullreq->consume_offset, LITTLE_ENDIAN_ESB);
		ptr += 8;
	}

	/** 写入 “尾分隔符” ，结束一个数据帧frame*/
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));

	return preq_str;
}

esb_pushCtl_request_t * new_pushCtl_request(int type, uint32_t subject_id, uint32_t client_id) {
	esb_pushCtl_request_t *pushctl_req;

	pushctl_req = (esb_pushCtl_request_t*)calloc(1, sizeof(esb_pushCtl_request_t));
	assert(pushctl_req);

	init_esb_request(&pushctl_req->base_request,
	                 REQUEST_HEAD_LEN + 1, CMD_TYPE_PUSHCTRL,
	                 subject_id, client_id, 0, 0);

	pushctl_req->type = type;
	return pushctl_req;
}

esb_string_t * pushCtl_request_toBytes(esb_pushCtl_request_t *pushCtlReq) {
	esb_string_t * req_str;
	char * ptr;

	/** 为了在尾部加一个 “尾分隔符” ，故多申请 5 个字节 */
	req_str = new_esb_string_t(pushCtlReq->base_request.total_len + sizeof(esb_delimiter.P_END_TAG));
	req_str->len = pushCtlReq->base_request.total_len + sizeof(esb_delimiter.P_END_TAG);

	/** 填充 基础req结构 字节流*/
	esb_request_fillBytes(&pushCtlReq->base_request, req_str);

	ptr = req_str->str + REQUEST_HEAD_LEN;
	/** 控制类型（停止or开始） */
	ptr[0] = (char)pushCtlReq->type;
	ptr += 1;
	/** 写入 “尾分隔符” ，结束一个数据帧frame*/
	memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));

	return req_str;
}


/**********************************
 *  response 相关方法
 *
 *********************************/

void esb_response_fromBytes(esb_response_t * resp, esb_string_t * buf) {
	char * ptr;

	if (buf->len < RESPONSE_HEAD_LEN)
	{
		// error, what to do?
		return;
	}

	ptr = buf->str;
	resp->total_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	resp->version = (uint8_t) * ptr;
	ptr += 1;
	resp->command_type = (uint8_t) * ptr;
	ptr += 1;
	resp->protocol_type = (uint8_t) * ptr;
	ptr += 1;
	resp->subject = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	resp->client_id = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	resp->opaque = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;
	resp->flag = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	resp->status = (uint8_t) * ptr;

	return;
}

void esb_heartBeat_resp_fromBytes(esb_response_t * resp, esb_string_t * buf) {
	char * ptr;

	ptr = buf->str;
	resp->total_len = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
	ptr += 4;
	resp->version = (uint8_t) * ptr;
	ptr += 1;
	resp->command_type = (uint8_t) * ptr;
	ptr += 1;
	resp->protocol_type = (uint8_t) * ptr;
	ptr += 1;
	ptr += 4;
	ptr += 4;
	resp->opaque = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
	ptr += 8;

	return;
}

esb_getQueue_response_t * new_esb_getQueue_response() {
	esb_getQueue_response_t * qresp;

	qresp = (esb_getQueue_response_t *)calloc(1, sizeof(esb_getQueue_response_t));
	assert(qresp);

	return qresp;
}

void free_esb_getQueue_response(esb_getQueue_response_t * qresp) {
	if (qresp->queues != NULL) {
		int i;
		for (i = 0; i < qresp->q_count; ++i) {
			if (qresp->queues[i] != NULL)
				free_esb_queue(qresp->queues[i]);
		}
		free(qresp->queues);
	}
	free(qresp);
}

esb_getQueue_response_t * getQueue_response_fromBytes(esb_string_t * buf) {
	char * ptr;
	int  body_len, i;
	uint32_t max_queue_id = 0, index;
	esb_getQueue_response_t * qresp;
	esb_queue_t * queue_tmp_list;

	qresp = new_esb_getQueue_response();

	esb_response_fromBytes(&qresp->base_resp, buf);

	/** 解析queue列表 */
	body_len = qresp->base_resp.total_len - RESPONSE_HEAD_LEN;
	if ( body_len <= 0 || (body_len % 12) != 0 ) {
		esb_printf(ESB_PRINT_NOTICE, "[getQueue_response_fromBytes:: body_len <= 0 or body_len % 12 != 0]%d\n", body_len);
		return qresp;
	}
	qresp->q_count = body_len / 12;
	qresp->queues = (esb_queue_t**)calloc(qresp->q_count, sizeof(esb_queue_t*));
	assert(qresp->queues);
	ptr = buf->str;
	ptr += RESPONSE_HEAD_LEN;
	for (i = 0; i < qresp->q_count; ++i)
	{
		qresp->queues[i] = new_esb_queue();
		qresp->queues[i]->abandon=0;
		qresp->queues[i]->subject_id = qresp->base_resp.subject;
		qresp->queues[i]->queue_id = StreamToUint32(ptr, LITTLE_ENDIAN_ESB);
		ptr += 4;
		qresp->queues[i]->offset = StreamToUint64(ptr, LITTLE_ENDIAN_ESB);
		// q的消费ACK值，初始状态赋值，如果是>0的值，会被server当做合法数据处理（有可能会导致offset错乱）
		qresp->queues[i]->consume_offset = -1;
		ptr += 8;
	}

	return qresp;
}




esb_commit_offset_request_t * new_commit_offset_request(esb_commit_offset_request_t *commitreq, uint32_t subject,uint32_t client_id, uint32_t queue_id,uint64_t consume_ack) {

	if (commitreq == NULL)
	{
		commitreq = (esb_pull_request_t *)calloc(1, sizeof(esb_pull_request_t));
		assert(commitreq);
	} else {
		memset(commitreq, 0, sizeof(esb_commit_offset_request_t));
	}

	commitreq->base_request.total_len = REQUEST_HEAD_LEN + 4 + 8;
	commitreq->base_request.version = CURR_PROTO_REQ_VERSION;
	commitreq->base_request.command_type = CMD_TYPE_COMMIT_OFFSET;
	commitreq->base_request.protocol_type = PROTO_TYPE_REQ;

	commitreq->base_request.subject = subject;
	commitreq->base_request.client_id = client_id;
	commitreq->base_request.opaque = 0;
	commitreq->base_request.flag = 0;
	commitreq->queue_id = queue_id;
	commitreq->consume_offset = consume_ack;

	return commitreq;
}

esb_string_t * commit_offset_request_toBytes(esb_commit_offset_request_t *commitreq){
	esb_string_t * preq_str;
		char * ptr;

		/** 为了在尾部加一个 “尾分隔符” ，故多申请 5 个字节 */
		preq_str = new_esb_string_t(commitreq->base_request.total_len + sizeof(esb_delimiter.P_END_TAG));
		preq_str->len = commitreq->base_request.total_len + sizeof(esb_delimiter.P_END_TAG);
		/** 初始化 “游标” 指针 */
		ptr = preq_str->str;

		/** 总长度 */
		Uint32ToStream(ptr, commitreq->base_request.total_len, LITTLE_ENDIAN_ESB);
		ptr += 4;
		/** 协议版本 */
		ptr[0] = (char)commitreq->base_request.version;
		ptr += 1;
		/** 消息类型 */
		ptr[0] = (char)commitreq->base_request.command_type;
		ptr += 1;
		/** 协议类型 */
		ptr[0] = (char)commitreq->base_request.protocol_type;
		ptr += 1;
		/** 主题 id */
		Uint32ToStream(ptr, commitreq->base_request.subject, LITTLE_ENDIAN_ESB);
		ptr += 4;
		/** client id */
		Uint32ToStream(ptr, commitreq->base_request.client_id, LITTLE_ENDIAN_ESB);
		ptr += 4;
		/** 请求序列号 */
		Uint64ToStream(ptr, commitreq->base_request.opaque, LITTLE_ENDIAN_ESB);
		ptr += 8;
		/** flag */
		Uint32ToStream(ptr, commitreq->base_request.flag, LITTLE_ENDIAN_ESB);
		ptr += 4;
		/** 拉取的队列id */
		Uint32ToStream(ptr, commitreq->queue_id, LITTLE_ENDIAN_ESB);
		ptr += 4;
		/** 消费ack */
		Uint64ToStream(ptr, commitreq->consume_offset, LITTLE_ENDIAN_ESB);
		ptr += 8;

		/** 写入 “尾分隔符” ，结束一个数据帧frame*/
		memcpy(ptr, esb_delimiter.P_END_TAG, sizeof(esb_delimiter.P_END_TAG));
		//printf("[==pull_request==] version:%d sbj:%d consume_offset:%d\n", pullreq->base_request.version, pullreq->base_request.subject, pullreq->consume_offset);
		return preq_str;
}
