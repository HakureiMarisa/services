/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <string.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include "../esbclient.h"
#include "../esbcli_msg.h"
#include <pthread.h>
pthread_mutex_t mutex;
int total=0;
int retry_total=0;
#include <time.h>
esb_client_t *esbcli;
char* getDateTime();

char* getDateTime()
{
    static char nowtime[20];
    time_t rawtime;
    struct tm* ltime;
    time(&rawtime);
    ltime = localtime(&rawtime);
    strftime(nowtime, 20, "%Y-%m-%d %H:%M:%S", ltime);
    return nowtime;
}
void esb_consume_msg(esb_msg_t *msg, void *ext_arg) {
	char *msg_body;

	if (msg == NULL)
	{
		printf("\n[msg ptr is NULL]\n");
		return;
	}

	msg_body = (char*)malloc(msg->payload_len + 1);
	msg_body[msg->payload_len] = '\0';
	memcpy(msg_body, msg->em_payload, msg->payload_len);

	pthread_mutex_lock(&mutex);//锁定互斥锁
	if(total%1000>=0){
		total=total+1;
		char* nowtime = getDateTime();
		printf("\n%s--,编号:%d,-----内容:%s\n", nowtime,total,
			   msg_body);	
	}else{
		total=total+1;
		char* nowtime = getDateTime();
                printf("\n%s--,编号:%d---[receive one msg, msg_id:%d]\n", nowtime,total,msg->message_id);
	}
	if(total%5==8){
		retry_total++;
		char* nowtime = getDateTime();
		printf("\n%s--,编号:%d---[receive one msg, subject:%d, msg_id:%d msg_len:%d]--内容:%s-----重试消费:%d！！！！\n", nowtime,total,msg->subject, msg->message_id, msg->payload_len, msg_body,retry_total);
		esb_client_reConsumeByCustomDelay(msg,2);
	}
		
	pthread_mutex_unlock(&mutex);//打开互斥锁
	usleep(20000);
	free(msg_body);

}

void main(int argc, char const *argv[])
{

	pthread_mutex_init(&mutex,NULL);
	char *key_path;
//	esb_client_t *esbcli;
	int result;

	key_path = (char*)argv[1];

	printf("[process id is %d]\n ", getpid());

	esb_client_set_logPrintLevel(ESB_PRINT_DEBUG);


	esbcli = esb_client_new(key_path);


	result = esb_add_consume_subject(esbcli, 100475, 1, ESB_SBJ_CMD_TYPE_PULL);
	if (result < 0) {
		printf("\n add subject failed, result is:%d\n", result);
	}

	result = esb_client_comsumer_loop(esbcli, &esb_consume_msg, ESB_ENABLE_MULTI_THREAD_CONSUME);
	esb_client_destroy(esbcli);
	printf("\n comsumer stop, result is:%d\n", result);
}
