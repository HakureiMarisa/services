/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <string.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

#include "../esbclient.h"
#include "../esbcli_msg.h"

void esb_consume_msg(esb_msg_t *msg, void *ext_arg) {
	char *msg_body;

	if (msg == NULL)
	{
		printf("\n[msg ptr is NULL]\n");
		return;
	}

	msg_body = (char*)malloc(msg->payload_len + 1);
	assert(msg_body);
	msg_body[msg->payload_len] = '\0';
	memcpy(msg_body, msg->em_payload, msg->payload_len);

usleep(1000 * 100);
	printf("?");
	//printf("\n[receive one msg, subject:%d, msg_id:%lu msg_len:%d]\n%s\n",
	//       msg->subject, msg->message_id, msg->payload_len, msg_body);

	free(msg_body);
}

void main(int argc, char const *argv[])
{
	char *key_path;
	esb_client_t *esbcli;
	int result;

	key_path = (char*)argv[1];

	printf("[process id is %d]\n", getpid());

	//esb_client_set_logPrintLevel(ESB_PRINT_WARNING);
	//esb_client_set_logPrintLevel(ESB_PRINT_NOTICE);
	esb_client_set_logPrintLevel(ESB_PRINT_DEBUG);


	esbcli = esb_client_new(key_path);

	result = esb_add_consume_subject(esbcli, 130081, 1, ESB_SBJ_CMD_TYPE_PULL);
	if (result < 0) {
		printf("\n add subject 130081 failed, result is:%d, %s\n", result, esb_get_error_info(result));
	}

	esbcli->u_conf.worker_thread_count = 6;
	sprintf(esbcli->u_conf.external_lang_str, "C");
	sprintf(esbcli->u_conf.external_lang_version, "0.2.0");

	result = esb_client_comsumer_loop(esbcli, &esb_consume_msg, ESB_ENABLE_MULTI_THREAD_CONSUME);

	esb_client_destroy(esbcli);

	printf("\n comsumer stop, result is:%d\n", result);

}
