/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <string.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

#include "../esbclient.h"
#include "../esbcli_msg.h"

void main(int argc, char const *argv[])
{
	char *key_path;
	esb_client_t *esbcli;
	int result;
	esb_msg_t *my_msg;
	char *msg_body;

	key_path = (char*)argv[1];

	//esb_client_set_logPrintLevel(ESB_PRINT_WARNING);
	esb_client_set_logPrintLevel(ESB_PRINT_NOTICE);
	//esb_client_set_logPrintLevel(ESB_PRINT_DEBUG);

	esbcli = esb_client_new(key_path);

	result = esb_add_consume_subject(esbcli, 123456, 2, ESB_SBJ_CMD_TYPE_PULL);
	if (result < 0) {
		printf("\n add subject failed, result is:%d\n", result);
	}
	result = esb_add_consume_subject(esbcli, 121212, 2, ESB_SBJ_CMD_TYPE_PULL);
	if (result < 0) {
		printf("\n add subject failed, result is:%d\n", result);
	}

	result = esb_client_consume_autonomy_start(esbcli, 0);
	if (result < 0) {
		printf("\n start consume failed, result is:%d\n", result);
	}

	my_msg = (esb_msg_t*)malloc(sizeof(esb_msg_t));
	while (1) {
		result = esb_localQueue_consume_autonomy(esbcli, my_msg);
		if (result == ESB_RET_QUEUE_EMPTY) {
			printf("\n QUEUE_EMPTY ; ready to break\n");
			break;
		}

		if (result < 0 || my_msg->payload_len == 0) {
			printf("\n localQueue consume failed, result is:%d\n", result);
			continue;
		}

		msg_body = (char*)malloc(my_msg->payload_len + 1);
		msg_body[my_msg->payload_len] = '\0';
		memcpy(msg_body, my_msg->em_payload, my_msg->payload_len);
		printf("\n[receive one msg, subject:%d, msg_id:%d msg_len:%d]\n%s\n",
		       my_msg->subject, my_msg->message_id, my_msg->payload_len, msg_body);
		free(msg_body);
	}

	//esb_client_destroy(esbcli);
	esb_client_close_callback(esbcli);

	printf("\n comsumer stop\n");

}
