/**
 * @file
 * @brief
 *
 * @auth 58ganji - Chen Peng
 */

#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "../hash.h"


void main(int argc, char const *argv[])
{
	hash_t *hash = hash_new();

	int i;
	char *my_key;
	for (i = 0; i < 100; ++i)
	{
		my_key = (char*)calloc(1, 30);
		sprintf(my_key, "%d", i + 2000);
		hash_set(hash, my_key, "foo");
	}

	printf("B size: %d\n", hash_size(hash));

	hash_each(hash, {
		printf("%s: %s\n", key, (char *) val);
		hash_del(hash, key);
	});

	printf("A size: %d\n", hash_size(hash));

	hash_free(hash);
}