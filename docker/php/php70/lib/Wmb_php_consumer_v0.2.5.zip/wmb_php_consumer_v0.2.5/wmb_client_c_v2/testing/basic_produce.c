#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "../esbcli_msg.h"
#include "../esbclient.h"
#include "../esbcli_util.h"

void main(int argc, char const *argv[]) {
	char *key_path, *errinfo;
	//char msg_body[];
	esb_client_t *esbcli;
	int result, coreno;

	key_path = (char*) argv[1];

	esb_client_set_logPrintLevel(ESB_PRINT_DEBUG);

	coreno = sysconf(_SC_NPROCESSORS_ONLN);
	printf("[sys core number:%d]\n", coreno);

	esbcli = esb_client_new(key_path);

	esb_client_produce_init(esbcli, 1);

	sleep(5);
	struct timeval tv_start, tv_end;
	gettimeofday(&tv_start, NULL);
	long start_time = tv_start.tv_sec * 1000 + tv_start.tv_usec / 1000;
	int i, t = 0, count = 5000;
	int total=0;
			time_t rawtime;
			struct tm * timeinfo;
	while(1) {
//	for (i = 0; i < count; i++) {
		total++;
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );
//		printf ( "当前系统时间: %s", asctime (timeinfo) );
		char msg_body_src[] = "-------------------------";
		sprintf(msg_body_src, "消息:%d-产生时间--%s--",total, asctime (timeinfo));

		char* msg_body = (char *) calloc(1, strlen(msg_body_src) + 1);
		memcpy(msg_body, msg_body_src, strlen(msg_body_src));
		msg_body[strlen(msg_body_src)] = '\0';
		esb_msg_t* msg = new_msg(esbcli, 100393, msg_body, strlen(msg_body),
				NULL, 0);
		setDelayLevel_enum(msg, DELAY_10S);
		delProperty(msg, PROPERTY_DELAY_LEVEL);
		setDelayLevel_enum(msg, DELAY_10S);
		setKeys(msg, "zhuangshaojing");
		setDelayLevel_enum(msg, DELAY_20S);
		result = esb_client_syncSend(esbcli, msg);
//		free_esb_msg(msg);
		//esb_client_asyncSend(esbcli, msg);
//		break;
//	}
//		usleep(1000);
//		t++;
//		if(total>5000){break;}
	}
	gettimeofday(&tv_end, NULL);
	long end_time = tv_end.tv_sec * 1000 + tv_end.tv_usec / 1000;
	printf("send over, count : %d, time : %d\n", count,
			(end_time - start_time));

	esb_client_close_callback(esbcli);
	errinfo = esb_get_error_info(esb_get_globle_error_code());

	printf("\n send result is:%d   str:%s\n", result, errinfo);

}
