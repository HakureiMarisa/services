#    本手册详述了安装步骤，及所需命令。
######################
# 1、安装libevent
######################

yum install openssl openssl-devel    #(先确保依赖的库已安装，如openssl，包括但不限于)

tar zxvf libevent-X.X.X-stable.tar.gz
cd libevent-X.X.X-stable/
./configure
make
sudo make install
cd ../

######################
# 2、安装wmb c客户端
######################

cd wmb_client_c_v2/
make
sudo make install
cd ../

######################
# 3、安装wmb php客户端（php扩展）
######################
# 注意：phpize php-config 两个可执行文件的路径，请酌情选择

cd wmb_client_php_v2/
phpize           
./configure --with-php-config=/usr/bin/php-config  #(php安装路径可能不同，请酌情选择路径)
make
sudo make install

######################
# 4、在php.ini添加扩展配置（请找到具体ini文件路径，手动添加）
######################

extension=esb_client.so